import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async redirects() {
    return [
      { source: "/contact", destination: "/a-propos#contact", permanent: true },
    ];
  },
};

export default nextConfig;
