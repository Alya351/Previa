"use client";

/**
 * Motifs de fond PREVIA — reproduction vectorielle des vagues fluides
 * (référence fournie) dans la palette stricte : bleu #009EE3 + blanc.
 * Responsive (slice), dérive très lente, net à toute taille.
 */
export default function WaveBackdrop() {
  return (
    <div className="wb-root" aria-hidden>
      <svg
        className="wb-svg"
        viewBox="0 0 1440 900"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <radialGradient id="wbBg" cx="50%" cy="40%" r="75%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="55%" stopColor="#f1f9fe" />
            <stop offset="100%" stopColor="#e4f2fb" />
          </radialGradient>
          <linearGradient id="wbTop" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#33b3e9" />
            <stop offset="100%" stopColor="#8fd6f3" />
          </linearGradient>
          <linearGradient id="wbB1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#c3e7f9" />
            <stop offset="100%" stopColor="#e8f6fd" />
          </linearGradient>
          <linearGradient id="wbB2" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#54bfed" />
            <stop offset="100%" stopColor="#93d8f4" />
          </linearGradient>
          <linearGradient id="wbB3" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#009ee3" />
            <stop offset="100%" stopColor="#37b4ea" />
          </linearGradient>
          <radialGradient id="wbGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Fond lumineux */}
        <rect x="0" y="0" width="1440" height="900" fill="url(#wbBg)" />

        {/* Vagues supérieures */}
        <g className="wb-top">
          <path
            d="M0,0 H1440 V150 C1150,275 880,235 600,170 C390,122 190,140 0,205 Z"
            fill="url(#wbTop)"
            opacity="0.92"
          />
          <path
            d="M0,216 C210,150 405,132 600,182 C880,252 1150,292 1440,166"
            fill="none"
            stroke="#ffffff"
            strokeWidth="2.4"
            strokeLinecap="round"
            opacity="0.7"
          />
          <path
            d="M0,250 C240,190 430,175 620,220 C900,286 1160,326 1440,210"
            fill="none"
            stroke="#ffffff"
            strokeWidth="1.4"
            strokeLinecap="round"
            opacity="0.35"
          />
        </g>

        {/* Vagues inférieures + halo lumineux */}
        <g className="wb-bottom">
          <path
            d="M0,900 H1440 V648 C1160,712 900,668 610,706 C380,736 180,724 0,700 Z"
            fill="url(#wbB1)"
          />
          <path
            d="M0,900 H1440 V726 C1180,672 915,738 640,766 C405,790 200,784 0,748 Z"
            fill="url(#wbB2)"
            opacity="0.92"
          />
          <path
            d="M0,900 H1440 V824 C1150,782 895,834 615,850 C380,864 190,858 0,836 Z"
            fill="url(#wbB3)"
          />
          <ellipse cx="612" cy="792" rx="380" ry="120" fill="url(#wbGlow)" />
          <path
            d="M0,742 C210,706 405,744 640,760 C915,779 1180,714 1440,742"
            fill="none"
            stroke="#ffffff"
            strokeWidth="2.2"
            strokeLinecap="round"
            opacity="0.6"
          />
          <path
            d="M0,832 C205,812 400,844 615,846 C895,849 1150,806 1440,832"
            fill="none"
            stroke="#ffffff"
            strokeWidth="1.6"
            strokeLinecap="round"
            opacity="0.4"
          />
        </g>
      </svg>

      <style>{`
        .wb-root { position: absolute; inset: 0; z-index: 0; overflow: hidden; }
        .wb-svg { width: 100%; height: 100%; display: block; }
        .wb-top { animation: wbTop 15s ease-in-out infinite alternate; transform-box: view-box; transform-origin: center; }
        .wb-bottom { animation: wbBottom 17s ease-in-out infinite alternate; transform-box: view-box; transform-origin: center; }
        @keyframes wbTop { from { transform: translateY(0) } to { transform: translateY(-10px) } }
        @keyframes wbBottom { from { transform: translateY(0) } to { transform: translateY(9px) } }
        @media (prefers-reduced-motion: reduce) {
          .wb-top, .wb-bottom { animation: none; }
        }
      `}</style>
    </div>
  );
}
