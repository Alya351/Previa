"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import WaveBackdrop from "./WaveBackdrop";

/* Palette stricte issue du logo */
const BLUE = "#009ee3";

/* Position de la tête du suricate DANS le logo (en % du cadre) */
const HEAD_LEFT = 65.99;
const HEAD_TOP = 4.65;
const HEAD_W = 33.98;
/* Décalage du cadre pour centrer la tête pendant la phase de scan */
const SCAN_SHIFT = "-32.98%";

type SplashScreenProps = {
  onFinish?: () => void;
  duration?: number;
};

/* RNG déterministe (évite tout mismatch SSR/CSR) */
function makeRng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}

type Particle = {
  x: number;
  y: number;
  size: number;
  delay: number;
  duration: number;
  drift: number;
};

export default function SplashScreen({
  onFinish,
  duration = 6300,
}: SplashScreenProps) {
  const reduce = useReducedMotion();
  const [exiting, setExiting] = useState(false);

  const particles = useMemo<Particle[]>(() => {
    const rng = makeRng(20240917);
    return Array.from({ length: 14 }, () => ({
      x: 6 + rng() * 88,
      y: 8 + rng() * 84,
      size: 2 + rng() * 2.4,
      delay: rng() * 1.2,
      duration: 3 + rng() * 2.5,
      drift: -6 + rng() * 12,
    }));
  }, []);

  useEffect(() => {
    if (reduce) {
      const t = window.setTimeout(() => onFinish?.(), 1800);
      return () => window.clearTimeout(t);
    }
    const tSweep = window.setTimeout(
      () => setExiting(true),
      Math.max(0, duration - 900)
    );
    const tEnd = window.setTimeout(() => onFinish?.(), duration);
    return () => {
      window.clearTimeout(tSweep);
      window.clearTimeout(tEnd);
    };
  }, [duration, onFinish, reduce]);

  /* --- Accessibilité : mouvement réduit --- */
  if (reduce) {
    return (
      <div className="splash-root">
        <WaveBackdrop />
        <div className="splash-center">
          <div className="splash-frame" style={{ transform: "none" }}>
            <img
              src="/logo-previa.png"
              alt="Previa"
              className="splash-logo"
              draggable={false}
            />
          </div>
          <p className="splash-signature">
            Surveillance intelligente.{" "}
            <span className="splash-signature-accent">
              Anticipation renforcée.
            </span>
          </p>
        </div>
        <SplashStyles />
      </div>
    );
  }

  return (
    <motion.div
      className="splash-root"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.03, filter: "blur(6px)" }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Motifs de fond */}
      <WaveBackdrop />

      {/* Halo doux derrière le logo */}
      <motion.div
        className="splash-glow"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: [0, 0.8, 0.6], scale: 1 }}
        transition={{ duration: 2.6, ease: "easeOut", delay: 0.4 }}
      />

      {/* Particules */}
      <div className="splash-particles" aria-hidden>
        {particles.map((p, i) => (
          <motion.span
            key={i}
            className="splash-particle"
            style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.size, height: p.size }}
            initial={{ opacity: 0, y: 0 }}
            animate={{ opacity: [0, 0.5, 0.18, 0.45], y: [0, p.drift, 0] }}
            transition={{
              duration: p.duration,
              delay: 0.3 + p.delay,
              repeat: Infinity,
              repeatType: "mirror",
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      {/* Ligne de scan horizontale d'ouverture */}
      <motion.div
        className="splash-scan-h"
        initial={{ top: "-6%", opacity: 0 }}
        animate={{ top: ["-6%", "106%"], opacity: [0, 0.85, 0.85, 0] }}
        transition={{ duration: 1.6, delay: 0.3, ease: "easeInOut" }}
        aria-hidden
      />

      <div className="splash-center">
        {/* Cadre : décalé pendant le scan pour centrer la tête, puis recentré */}
        <motion.div
          className="splash-frame"
          initial={{ x: SCAN_SHIFT }}
          animate={{ x: [SCAN_SHIFT, SCAN_SHIFT, "0%"] }}
          transition={{
            duration: 3.4,
            times: [0, 0.69, 1],
            ease: [0.22, 1, 0.36, 1],
          }}
        >
          {/* Logo complet — se compose autour de la tête (flou -> net) */}
          <motion.img
            src="/logo-previa.png"
            alt="Previa"
            className="splash-logo"
            draggable={false}
            initial={{ opacity: 0, scale: 0.94, filter: "blur(14px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
            transition={{ duration: 1.0, delay: 2.35, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Tête du suricate — phase 0 : apparaît, regarde G/D, se stabilise */}
          <motion.img
            src="/meerkat-head.png"
            alt=""
            aria-hidden
            className="splash-head"
            draggable={false}
            style={{
              left: `${HEAD_LEFT}%`,
              top: `${HEAD_TOP}%`,
              width: `${HEAD_W}%`,
              transformOrigin: "48% 82%",
            }}
            initial={{ opacity: 0, scale: 0.9, rotate: 0 }}
            animate={{
              opacity: [0, 1, 1, 1, 1, 1],
              scale: [0.9, 1, 1, 1, 1, 1],
              rotate: [0, 0, -9, 8, -3, 0],
            }}
            transition={{
              duration: 2.15,
              delay: 0.15,
              times: [0, 0.14, 0.4, 0.66, 0.86, 1],
              ease: "easeInOut",
            }}
          />

          {/* Ligne lumineuse verticale de révélation */}
          <motion.div
            className="splash-reveal"
            initial={{ left: "-8%", opacity: 0 }}
            animate={{ left: ["-8%", "108%"], opacity: [0, 1, 1, 0] }}
            transition={{ duration: 0.9, delay: 2.45, ease: "easeInOut" }}
            aria-hidden
          />

          {/* Réticule de détection (coins) */}
          <div className="splash-reticle" aria-hidden>
            {(["tl", "tr", "br", "bl"] as const).map((pos, i) => (
              <motion.span
                key={pos}
                className={`splash-reticle-c splash-reticle-${pos}`}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 0.85, scale: 1 }}
                transition={{ duration: 0.5, delay: 3.5 + i * 0.08, ease: "easeOut" }}
              />
            ))}
          </div>

          {/* Marqueurs de détection */}
          {[
            { x: "14%", y: "20%", d: 3.6 },
            { x: "82%", y: "30%", d: 3.75 },
            { x: "30%", y: "82%", d: 3.9 },
          ].map((m, i) => (
            <motion.span
              key={i}
              className="splash-marker"
              style={{ left: m.x, top: m.y }}
              initial={{ opacity: 0, scale: 0.4 }}
              animate={{ opacity: [0, 1, 0.6], scale: 1 }}
              transition={{ duration: 0.8, delay: m.d, ease: "easeOut" }}
            >
              <span className="splash-marker-dot" />
              <motion.span
                className="splash-marker-ring"
                initial={{ opacity: 0.7, scale: 0.6 }}
                animate={{ opacity: 0, scale: 2.4 }}
                transition={{ duration: 1.8, delay: m.d, repeat: Infinity, ease: "easeOut" }}
              />
            </motion.span>
          ))}

          {/* Croix de visée qui scanne (phase 0) */}
          <motion.div
            className="splash-gaze"
            aria-hidden
            initial={{ opacity: 0, left: "66%", top: "30%" }}
            animate={{
              opacity: [0, 0.9, 0.9, 0.9, 0],
              left: ["66%", "44%", "94%", "80%", "80%"],
              top: ["30%", "42%", "26%", "34%", "34%"],
            }}
            transition={{
              duration: 1.5,
              delay: 0.6,
              times: [0, 0.3, 0.62, 0.85, 1],
              ease: "easeInOut",
            }}
          >
            <span className="splash-gaze-h" />
            <span className="splash-gaze-v" />
            <span className="splash-gaze-ring" />
          </motion.div>

          {/* Verrouillage de cible (phase 0) */}
          <motion.div
            className="splash-lock"
            aria-hidden
            style={{ left: "80%", top: "34%" }}
            initial={{ opacity: 0, scale: 1.8 }}
            animate={{ opacity: [0, 1, 1, 0], scale: [1.8, 1, 1, 1.35] }}
            transition={{ duration: 1.0, delay: 1.85, times: [0, 0.4, 0.72, 1], ease: "easeOut" }}
          >
            <span className="splash-lock-c splash-lock-tl" />
            <span className="splash-lock-c splash-lock-tr" />
            <span className="splash-lock-c splash-lock-br" />
            <span className="splash-lock-c splash-lock-bl" />
          </motion.div>
          <motion.span
            className="splash-lock-flash"
            aria-hidden
            style={{ left: "80%", top: "34%" }}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: [0, 0.9, 0], scale: [0.5, 2.2, 2.7] }}
            transition={{ duration: 0.75, delay: 2.15, ease: "easeOut" }}
          />
        </motion.div>

        {/* Signature */}
        <motion.p
          className="splash-signature"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 4.5, ease: [0.22, 1, 0.36, 1] }}
        >
          Surveillance intelligente.{" "}
          <span className="splash-signature-accent">Anticipation renforcée.</span>
        </motion.p>
      </div>

      {/* Trajectoire d'analyse */}
      <svg className="splash-trajectory" viewBox="0 0 100 100" aria-hidden>
        <motion.path
          d="M8 78 C 30 62, 44 40, 60 34 S 88 26, 94 18"
          fill="none"
          stroke={BLUE}
          strokeWidth={0.25}
          strokeDasharray="1.4 2.2"
          vectorEffect="non-scaling-stroke"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: [0, 0.5, 0] }}
          transition={{ duration: 1.4, delay: 3.6, ease: "easeInOut" }}
        />
      </svg>
      <motion.span
        className="splash-tdot"
        aria-hidden
        initial={{ opacity: 0, left: "8%", top: "78%" }}
        animate={{
          opacity: [0, 1, 1, 0],
          left: ["8%", "44%", "74%", "94%"],
          top: ["78%", "40%", "28%", "18%"],
        }}
        transition={{ duration: 1.4, delay: 3.6, ease: "easeInOut" }}
      />

      {/* Balayage lumineux de transition */}
      {exiting && (
        <motion.div
          className="splash-sweep"
          initial={{ left: "-30%", opacity: 0 }}
          animate={{ left: ["-30%", "130%"], opacity: [0, 0.9, 0] }}
          transition={{ duration: 0.85, ease: "easeInOut" }}
          aria-hidden
        />
      )}

      <SplashStyles />
    </motion.div>
  );
}

function SplashStyles() {
  return (
    <style>{`
      .splash-root {
        position: fixed;
        inset: 0;
        z-index: 50;
        overflow: hidden;
        background: #ffffff;
        display: grid;
        place-items: center;
      }
      .splash-center {
        position: relative;
        z-index: 3;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: clamp(22px, 4.5vh, 44px);
        padding: 24px;
      }
      .splash-frame {
        position: relative;
        width: clamp(230px, 58vw, 540px);
        display: grid;
        place-items: center;
      }
      .splash-logo {
        width: 100%;
        height: auto;
        display: block;
        user-select: none;
        -webkit-user-drag: none;
      }
      .splash-head {
        position: absolute;
        height: auto;
        display: block;
        pointer-events: none;
        user-select: none;
        -webkit-user-drag: none;
        will-change: transform;
      }
      .splash-reticle {
        position: absolute;
        inset: -14% -9%;
        width: 118%;
        height: 128%;
        pointer-events: none;
      }
      .splash-reticle-c {
        position: absolute;
        width: clamp(12px, 3vw, 20px);
        height: clamp(12px, 3vw, 20px);
        border: 1.6px solid ${BLUE};
        filter: drop-shadow(0 0 4px rgba(0,158,227,0.45));
      }
      .splash-reticle-tl { left: 0; top: 0; border-right: none; border-bottom: none; }
      .splash-reticle-tr { right: 0; top: 0; border-left: none; border-bottom: none; }
      .splash-reticle-br { right: 0; bottom: 0; border-left: none; border-top: none; }
      .splash-reticle-bl { left: 0; bottom: 0; border-right: none; border-top: none; }
      .splash-reveal {
        position: absolute;
        top: -6%;
        height: 112%;
        width: 12px;
        transform: translateX(-50%);
        background: linear-gradient(to bottom, transparent, rgba(0,158,227,0.85), transparent);
        filter: blur(2px);
        pointer-events: none;
      }
      .splash-marker {
        position: absolute;
        width: 0; height: 0;
        transform: translate(-50%, -50%);
        pointer-events: none;
      }
      .splash-marker-dot {
        position: absolute; left: 50%; top: 50%;
        width: 5px; height: 5px;
        transform: translate(-50%, -50%);
        border-radius: 50%;
        background: ${BLUE};
        box-shadow: 0 0 8px rgba(0,158,227,0.7);
      }
      .splash-marker-ring {
        position: absolute; left: 50%; top: 50%;
        width: 22px; height: 22px;
        transform: translate(-50%, -50%);
        border-radius: 50%;
        border: 1px solid rgba(0,158,227,0.6);
      }
      /* Croix de visée */
      .splash-gaze {
        position: absolute;
        width: 46px; height: 46px;
        transform: translate(-50%, -50%);
        pointer-events: none;
      }
      .splash-gaze-h, .splash-gaze-v {
        position: absolute; left: 50%; top: 50%;
        background: ${BLUE};
        box-shadow: 0 0 6px rgba(0,158,227,0.6);
      }
      .splash-gaze-h { width: 46px; height: 1.5px; transform: translate(-50%, -50%); }
      .splash-gaze-v { width: 1.5px; height: 46px; transform: translate(-50%, -50%); }
      .splash-gaze-ring {
        position: absolute; left: 50%; top: 50%;
        width: 16px; height: 16px;
        transform: translate(-50%, -50%);
        border-radius: 50%;
        border: 1.5px solid ${BLUE};
      }
      /* Verrouillage de cible */
      .splash-lock {
        position: absolute;
        width: 54px; height: 54px;
        transform: translate(-50%, -50%);
        pointer-events: none;
      }
      .splash-lock-c {
        position: absolute;
        width: 14px; height: 14px;
        border: 2px solid ${BLUE};
      }
      .splash-lock-tl { left: 0; top: 0; border-right: none; border-bottom: none; }
      .splash-lock-tr { right: 0; top: 0; border-left: none; border-bottom: none; }
      .splash-lock-br { right: 0; bottom: 0; border-left: none; border-top: none; }
      .splash-lock-bl { left: 0; bottom: 0; border-right: none; border-top: none; }
      .splash-lock-flash {
        position: absolute;
        width: 40px; height: 40px;
        transform: translate(-50%, -50%);
        border-radius: 50%;
        border: 1.5px solid ${BLUE};
        pointer-events: none;
      }
      .splash-signature {
        margin: 0;
        text-align: center;
        font-family: var(--font-open-sans), Arial, sans-serif;
        font-weight: 400;
        color: #33414d;
        font-size: clamp(0.82rem, 2.3vw, 1.06rem);
        letter-spacing: 0.06em;
        line-height: 1.5;
      }
      .splash-signature-accent { color: ${BLUE}; font-weight: 600; }
      .splash-glow {
        position: absolute;
        z-index: 1;
        width: min(720px, 80vw);
        height: min(720px, 80vw);
        border-radius: 50%;
        background: radial-gradient(circle, rgba(0,158,227,0.12) 0%, rgba(0,158,227,0.05) 42%, transparent 70%);
        filter: blur(6px);
      }
      .splash-particles { position: absolute; inset: 0; z-index: 2; pointer-events: none; }
      .splash-particle {
        position: absolute; border-radius: 50%;
        background: ${BLUE};
        box-shadow: 0 0 6px rgba(0,158,227,0.5);
      }
      .splash-scan-h {
        position: absolute; left: 0; z-index: 2;
        width: 100%; height: 2px;
        background: linear-gradient(90deg, transparent, rgba(0,158,227,0.85) 50%, transparent);
        box-shadow: 0 0 14px rgba(0,158,227,0.55);
        pointer-events: none;
      }
      .splash-trajectory { position: absolute; inset: 0; z-index: 2; width: 100%; height: 100%; pointer-events: none; }
      .splash-tdot {
        position: absolute; z-index: 2;
        width: 6px; height: 6px; border-radius: 50%;
        background: ${BLUE};
        box-shadow: 0 0 8px rgba(0,158,227,0.7);
        transform: translate(-50%, -50%);
        pointer-events: none;
      }
      .splash-sweep {
        position: absolute; top: 0; z-index: 4;
        width: 26%; height: 100%;
        background: linear-gradient(90deg, transparent, rgba(0,158,227,0.14), rgba(255,255,255,0.85), rgba(0,158,227,0.14), transparent);
        filter: blur(2px);
        pointer-events: none;
      }
    `}</style>
  );
}
