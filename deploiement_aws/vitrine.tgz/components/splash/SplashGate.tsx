"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { AnimatePresence } from "motion/react";
import SplashScreen from "./SplashScreen";
import { warmPlans } from "@/lib/plansCache";

export default function SplashGate({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isAdminArea = pathname?.startsWith("/prevadm");
  const [showSplash, setShowSplash] = useState(!isAdminArea);
  const isFirstMount = useRef(true);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      // Au (re)chargement, on affiche toujours le splash depuis le haut de la
      // page : on désactive la restauration native du navigateur (qui sinon
      // remet la page à l'ancienne position de scroll derrière le splash) et
      // on force le scroll en haut avant que le contenu ne redevienne visible.
      try {
        if ("scrollRestoration" in window.history) {
          window.history.scrollRestoration = "manual";
        }
      } catch {}
      window.scrollTo(0, 0);
      warmPlans(); // réveille l'API (Render) pendant que le visiteur découvre le site
    }
  }, [pathname]);

  const handleFinish = () => {
    // Le splash n'altère jamais l'adresse : un lien direct (ex. /offres) reste sur sa page.
    setShowSplash(false);
  };

  return (
    <>
      <div aria-hidden={showSplash} style={showSplash ? { pointerEvents: "none" } : undefined}>
        {children}
      </div>
      <AnimatePresence>
        {showSplash && (
          <SplashScreen key="splash" onFinish={handleFinish} duration={6300} />
        )}
      </AnimatePresence>
    </>
  );
}
