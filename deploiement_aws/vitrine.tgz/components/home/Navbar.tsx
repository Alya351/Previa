"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import Logo from "./Logo";
import LangSwitch from "./LangSwitch";
import ThemeToggle from "./ThemeToggle";
import AccountMenu, { type AccountMenuAction } from "./AccountMenu";
import EditProfileModal from "./EditProfileModal";
import NotificationBell from "./NotificationBell";
import { SITE_LINKS, ESPACE_LINK, ABONNEMENT_LINK } from "./navLinks";
import { IconMenu, IconClose, IconLogOut, IconEdit, IconGrid, IconRefreshCw } from "./icons";
import { useAuthUser, clearAuthUser } from "@/lib/auth";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const pathname = usePathname();
  const authUser = useAuthUser();
  const router = useRouter();
  const links = SITE_LINKS;
  // Même menu que dans l'espace client.
  const accountExtraActions: AccountMenuAction[] = [
    {
      icon: <IconGrid width={16} height={16} />,
      label: ESPACE_LINK.label,
      onClick: () => router.push(ESPACE_LINK.href),
    },
    {
      icon: <IconRefreshCw width={16} height={16} />,
      label: ABONNEMENT_LINK.label,
      onClick: () => router.push(ABONNEMENT_LINK.href),
    },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Se déconnecter ne navigue jamais : on reste sur la page en cours, qui se
  // met à jour toute seule (ex: /code-amorcage bascule côté public).
  const handleLogout = () => clearAuthUser();


  return (
    <header className={`nav ${scrolled ? "scrolled" : ""}`}>
      <div className="container">
        <motion.div
          className="nav-pill"
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="nav-row">
            <motion.div
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.05 }}
            >
              <Link href="/" className="nav-logo" aria-label="Previa — accueil">
                <Logo height={28} />
              </Link>
            </motion.div>

            <nav className="nav-desktop-only">
              <ul className="nav-links">
                {links.map((l, i) => (
                  <motion.li
                    key={l.label}
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.15 + i * 0.06 }}
                  >
                    <Link
                      href={l.href}
                      className={`nav-link ${pathname === l.href ? "is-active" : ""}`}
                      aria-current={pathname === l.href ? "page" : undefined}
                    >
                      {l.label}
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </nav>

            <div className="nav-actions">
              <span className="nav-desktop-only">
                <LangSwitch />
              </span>
              <ThemeToggle />

              {authUser && <NotificationBell userEmail={authUser.email} />}

              {authUser ? (
                <motion.div
                  className="nav-desktop-only"
                  initial={{ opacity: 0, scale: 0.94 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.62 }}
                >
                  <AccountMenu user={authUser} onLogout={handleLogout} extraActions={accountExtraActions} />
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.94 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.62 }}
                  className="nav-desktop-only"
                >
                  <Link href="/connexion" className="btn btn-primary nav-cta">
                    Connexion
                  </Link>
                </motion.div>
              )}

              <button
                className="icon-btn hamburger"
                aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
                aria-expanded={open}
                onClick={() => setOpen((v) => !v)}
              >
                {open ? <IconClose width={20} height={20} /> : <IconMenu width={20} height={20} />}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {open && (
              <motion.div
                className="mobile-menu"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              >
                <div className="mobile-menu-inner">
                  {links.map((l) => (
                    <Link
                      key={l.label}
                      href={l.href}
                      className={`mobile-link ${pathname === l.href ? "is-active" : ""}`}
                      aria-current={pathname === l.href ? "page" : undefined}
                      onClick={() => setOpen(false)}
                    >
                      {l.label}
                    </Link>
                  ))}
                  <div className="mobile-actions">
                    <LangSwitch />
                    {!authUser && (
                      <Link
                        href="/connexion"
                        className="btn btn-primary"
                        style={{ flex: 1 }}
                        onClick={() => setOpen(false)}
                      >
                        Connexion
                      </Link>
                    )}
                  </div>
                  {authUser && (
                    <div className="mobile-account">
                      {accountExtraActions.map((action) => (
                        <button
                          key={action.label}
                          type="button"
                          className="mobile-account-edit"
                          onClick={() => {
                            setOpen(false);
                            action.onClick();
                          }}
                        >
                          {action.icon}
                          {action.label}
                        </button>
                      ))}
                      <button type="button" className="btn btn-secondary" onClick={handleLogout}>
                        <IconLogOut width={16} height={16} />
                        Se déconnecter
                      </button>
                      <button
                        type="button"
                        className="mobile-account-edit"
                        onClick={() => {
                          setOpen(false);
                          setEditOpen(true);
                        }}
                      >
                        <IconEdit width={16} height={16} />
                        Modifier mon compte
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {authUser && <EditProfileModal open={editOpen} onClose={() => setEditOpen(false)} user={authUser} />}
    </header>
  );
}
