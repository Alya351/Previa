"use client";

import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "motion/react";
import { IconClose } from "./icons";
import { useMounted } from "./useMounted";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Enveloppe ouverte avec sa lettre (aux couleurs de Previa). */
function EnvelopeArt() {
  return (
    <svg className="nd-art" viewBox="0 0 150 128" aria-hidden="true">
      <rect className="nd-art-sheet" x="38" y="6" width="74" height="66" rx="5" />
      <rect className="nd-art-ink" x="46" y="15" width="22" height="11" rx="2" />
      <rect className="nd-art-line" x="74" y="15" width="30" height="3" rx="1.5" />
      <rect className="nd-art-line" x="74" y="21" width="30" height="3" rx="1.5" />
      <rect className="nd-art-line" x="46" y="33" width="58" height="3" rx="1.5" />
      <rect className="nd-art-line" x="46" y="40" width="58" height="3" rx="1.5" />
      <rect className="nd-art-line" x="46" y="47" width="58" height="3" rx="1.5" />
      <rect className="nd-art-line" x="46" y="54" width="40" height="3" rx="1.5" />
      <rect className="nd-art-back" x="14" y="48" width="122" height="68" rx="5" />
      <polygon className="nd-art-flap" points="14,50 75,94 136,50 136,111 14,111" />
      <polygon className="nd-art-fold" points="14,111 75,72 136,111" />
      <rect className="nd-art-floor" x="12" y="121" width="126" height="3" rx="1.5" />
    </svg>
  );
}

/**
 * Fenêtre de détails d'une notification (modèle « Email Confirmation » : carte blanche,
 * enveloppe, titre centré, texte, séparateur et ligne d'aide).
 * Rendue dans <body> : la barre du site a un backdrop-filter qui rognerait un élément `fixed`.
 */
export default function NotificationDetail({
  open,
  onClose,
  title,
  when,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  /** Jour et heure, sous le titre. */
  when?: string;
  children: ReactNode;
  /** Ligne d'aide sous le séparateur (ex. « Rien reçu ? Contactez-nous »). */
  footer?: ReactNode;
}) {
  const mounted = useMounted();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!mounted) return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="nd-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
        >
          <motion.div
            className="nd-card"
            role="dialog"
            aria-modal="true"
            aria-label={title}
            initial={{ opacity: 0, scale: 0.95, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 10 }}
            transition={{ duration: 0.28, ease: EASE }}
            onClick={(e) => e.stopPropagation()}
          >
            <button type="button" className="nd-close" aria-label="Fermer" onClick={onClose}>
              <IconClose width={20} height={20} />
            </button>

            <EnvelopeArt />
            <h3 className="nd-title">{title}</h3>
            {when && <p className="nd-when">{when}</p>}
            <div className="nd-body">{children}</div>

            {footer && <div className="nd-footer">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
