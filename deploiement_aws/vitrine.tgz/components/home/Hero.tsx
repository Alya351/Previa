"use client";

import { useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import HeroCarousel from "./HeroCarousel";
import VideoModal from "./VideoModal";

const HOME_VIDEO_SRC = "/video-accueil.mp4";

export default function Hero() {
  const reduce = useReducedMotion();
  const [videoOpen, setVideoOpen] = useState(false);

  const scrollToNext = () =>
    document
      .getElementById("pourquoi")
      ?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });

  return (
    <section className="hero">
      <div className="container">
        <motion.div
          className="hero-block"
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        >
          {/* Image unique qui défile horizontalement */}
          <HeroCarousel />

          {/* Contenu au premier plan */}
          <div className="hero-content">
            <motion.h1
              className="hero-title"
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
            >
              <span className="hero-line-1">Analyse. Anticipation.</span>
              <span className="hero-line-2 accent">Action.</span>
            </motion.h1>

            <motion.p
              className="hero-sub"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.68 }}
            >
              La vidéosurveillance intelligente par analyse
              <br />
              comportementale vidéo.
            </motion.p>

            <motion.div
              className="hero-actions"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.86 }}
            >
              <button className="btn btn-primary shimmer-hover" onClick={scrollToNext}>
                Découvrir Previa
              </button>
              <button
                className="btn btn-secondary hero-video-btn shimmer-hover"
                onClick={() => setVideoOpen(true)}
              >
                Voir la vidéo
              </button>
            </motion.div>
          </div>
        </motion.div>
      </div>

      <VideoModal open={videoOpen} onClose={() => setVideoOpen(false)} src={HOME_VIDEO_SRC} />
    </section>
  );
}
