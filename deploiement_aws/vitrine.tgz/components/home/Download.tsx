"use client";

import { useState } from "react";
import Link from "next/link";
import Reveal from "./Reveal";
import { SceneArt } from "./scenes";
import { IconMonitor, IconPhone } from "./icons";

function DownloadVisual() {
  const [failed, setFailed] = useState(false);

  if (!failed) {
    return (
      <div className="download-image">
        <img
          src="/scenes/telechargement.jpg"
          alt="Plateforme et application Previa"
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
          draggable={false}
        />
      </div>
    );
  }

  // Repli : mockups appareils stylisés
  return (
    <>
      <div className="device-web">
        <div className="device-bar">
          <i />
          <i />
          <i />
        </div>
        <div style={{ position: "absolute", inset: "26px 0 0" }}>
          <SceneArt env="entreprise" />
        </div>
      </div>
      <div className="device-phone">
        <div style={{ position: "absolute", inset: 0 }}>
          <SceneArt env="residence" />
        </div>
      </div>
    </>
  );
}

export default function Download() {
  return (
    <section id="telechargement" className="section">
      <div className="container">
        <div className="download-block">
          {/* titre d'étiquette centré sur toute la largeur du bloc */}
          <Reveal className="download-eyebrow-row">
            <span className="eyebrow">Téléchargement</span>
          </Reveal>

          <Reveal>
            <h2 className="h2">
              <span>Previa</span>, où que vous soyez.
            </h2>
            <p className="lead">
              Une expérience unifiée sur mobile et sur le web, pensée pour rester
              simple.
            </p>

            <div className="download-platforms">
              <div className="platform">
                <span className="platform-icon">
                  <IconPhone width={22} height={22} />
                </span>
                <span className="platform-text">
                  <span className="platform-name">Mobile</span>
                  <span className="platform-desc">Application Previa</span>
                </span>
              </div>
              <div className="platform">
                <span className="platform-icon">
                  <IconMonitor width={22} height={22} />
                </span>
                <span className="platform-text">
                  <span className="platform-name">Web</span>
                  <span className="platform-desc">Plateforme Previa</span>
                </span>
              </div>
            </div>

            <div className="download-cta-row">
              <Link href="/telechargement" className="btn btn-primary download-cta">
                Télécharger Previa
              </Link>
            </div>
          </Reveal>

          <Reveal delay={0.15} className="download-visual">
            <DownloadVisual />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
