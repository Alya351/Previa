"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { motion, useAnimation, useInView, useReducedMotion } from "motion/react";
import Reveal from "./Reveal";
import {
  IconIntelligence,
  IconProactive,
  IconReactive,
  IconSurveillance,
} from "./icons";

type CardKey = "intelligence" | "proactivite" | "reactivite" | "surveillance";

const CARDS: { key: CardKey; icon: typeof IconIntelligence; title: string; text: string }[] = [
  {
    key: "intelligence",
    icon: IconIntelligence,
    title: "Intelligence",
    text: "Analyse intelligente des comportements.",
  },
  {
    key: "proactivite",
    icon: IconProactive,
    title: "Proactivité",
    text: "Identifie les situations inhabituelles.",
  },
  {
    key: "reactivite",
    icon: IconReactive,
    title: "Réactivité",
    text: "Permet des alertes pertinentes.",
  },
  {
    key: "surveillance",
    icon: IconSurveillance,
    title: "Surveillance continue",
    text: "Une surveillance permanente.",
  },
];

// Étape à laquelle chaque carte doit apparaître (voir minutage ci-dessous).
const STAGE_TO_CARD: Record<number, CardKey> = {
  1: "intelligence",
  3: "proactivite",
  5: "reactivite",
  7: "surveillance",
};
const CARD_DURATION = 0.5; // opacity/y/scale, identique pour les 4 cartes
const CARD_EASE = [0.22, 1, 0.36, 1] as const;

// Minutage : carte (500ms) + pause (250ms) + flèche (800ms), répété 4 fois (~6.2s).
const STAGE_DELAYS = [750, 800, 750, 800, 750, 800, 750, 800]; // durée de chaque étape 1→8
const ARROW_DURATION = 800;

type Point = { x: number; y: number };
type Rect = { x: number; y: number; w: number; h: number };
type Dir = { x: number; y: number };

const GAP = 10; // distance entre la pointe/le départ de la flèche et le bord de la carte

function edgePoint(r: Rect, side: "left" | "right" | "top" | "bottom", inset: number): Point {
  switch (side) {
    case "left":
      return { x: r.x - inset, y: r.y + r.h / 2 };
    case "right":
      return { x: r.x + r.w + inset, y: r.y + r.h / 2 };
    case "top":
      return { x: r.x + r.w / 2, y: r.y - inset };
    case "bottom":
      return { x: r.x + r.w / 2, y: r.y + r.h + inset };
  }
}

/** Point lumineux qui trace une flèche entre deux cartes, sans jamais les traverser. */
function Connector({
  start,
  end,
  dir,
  active,
  reduce,
}: {
  start: Point | null;
  end: Point | null;
  dir: Dir;
  active: boolean;
  reduce: boolean;
}) {
  const [progress, setProgress] = useState(reduce ? 1 : 0);
  const startedRef = useRef(false);
  const rafRef = useRef(0);

  // Une fois lancée, l'animation va jusqu'au bout : elle ne doit pas être
  // interrompue quand `active` redevient faux (passage à l'étape suivante).
  useEffect(() => {
    if (reduce || !active || startedRef.current) return;
    startedRef.current = true;

    const t0 = performance.now();
    const ease = (t: number) => 1 - Math.pow(1 - t, 3);
    const tick = (now: number) => {
      const t = Math.min(1, (now - t0) / ARROW_DURATION);
      setProgress(ease(t));
      if (t < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  }, [active, reduce]);

  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  if (!start || !end) return null;

  const length = Math.hypot(end.x - start.x, end.y - start.y);
  const dashoffset = length * (1 - progress);
  const dotX = start.x + (end.x - start.x) * progress;
  const dotY = start.y + (end.y - start.y) * progress;
  const perp = { x: -dir.y, y: dir.x };
  const arrowOpacity = Math.max(0, Math.min(1, (progress - 0.85) / 0.15));
  const b1 = { x: end.x - dir.x * 9 + perp.x * 4, y: end.y - dir.y * 9 + perp.y * 4 };
  const b2 = { x: end.x - dir.x * 9 - perp.x * 4, y: end.y - dir.y * 9 - perp.y * 4 };
  const trail1 = { x: dotX - dir.x * 9, y: dotY - dir.y * 9 };
  const trail2 = { x: dotX - dir.x * 18, y: dotY - dir.y * 18 };
  const showDot = !reduce && progress > 0 && progress < 1;

  return (
    <g>
      <line
        x1={start.x}
        y1={start.y}
        x2={end.x}
        y2={end.y}
        stroke="rgba(0, 158, 227, 0.65)"
        strokeWidth={2}
        strokeLinecap="round"
        strokeDasharray={length}
        strokeDashoffset={dashoffset}
      />
      {showDot && (
        <>
          <circle cx={dotX} cy={dotY} r={6} fill="rgba(0, 158, 227, 0.22)" />
          <circle cx={trail1.x} cy={trail1.y} r={2.8} fill="rgba(0, 158, 227, 0.45)" />
          <circle cx={trail2.x} cy={trail2.y} r={1.9} fill="rgba(0, 158, 227, 0.26)" />
          <circle cx={dotX} cy={dotY} r={3.4} fill="var(--previa-blue)" />
        </>
      )}
      <polygon
        points={`${end.x},${end.y} ${b1.x},${b1.y} ${b2.x},${b2.y}`}
        fill="var(--previa-blue)"
        opacity={arrowOpacity}
      />
    </g>
  );
}

export default function WhyPrevia() {
  const reduce = !!useReducedMotion();
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Record<CardKey, HTMLDivElement | null>>({
    intelligence: null,
    proactivite: null,
    reactivite: null,
    surveillance: null,
  });

  const [rects, setRects] = useState<Record<CardKey, Rect> | null>(null);
  const [isStacked, setIsStacked] = useState(false);
  const [stage, setStage] = useState(0);
  const startedRef = useRef(false);

  // Un contrôleur d'animation par carte : piloté impérativement (plus fiable
  // qu'un prop `animate` dérivé d'un état partagé pour plusieurs cartes).
  const controlsIntelligence = useAnimation();
  const controlsProactivite = useAnimation();
  const controlsReactivite = useAnimation();
  const controlsSurveillance = useAnimation();
  const cardControls: Record<CardKey, ReturnType<typeof useAnimation>> = {
    intelligence: controlsIntelligence,
    proactivite: controlsProactivite,
    reactivite: controlsReactivite,
    surveillance: controlsSurveillance,
  };

  const inView = useInView(containerRef, { once: true, amount: 0.4 });

  // Détecte le passage en disposition empilée (mobile). Écoute aussi le
  // redimensionnement de la fenêtre en secours (certains outils/navigateurs
  // ne déclenchent pas toujours l'évènement "change" du MediaQueryList).
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 560px)");
    const apply = () => setIsStacked(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    window.addEventListener("resize", apply);
    return () => {
      mq.removeEventListener("change", apply);
      window.removeEventListener("resize", apply);
    };
  }, []);

  // Mesure la position des 4 cartes, relativement au conteneur.
  useLayoutEffect(() => {
    const measure = () => {
      const container = containerRef.current;
      if (!container) return;
      const cRect = container.getBoundingClientRect();
      const next = {} as Record<CardKey, Rect>;
      (Object.keys(cardRefs.current) as CardKey[]).forEach((key) => {
        const el = cardRefs.current[key];
        if (!el) return;
        const r = el.getBoundingClientRect();
        next[key] = { x: r.left - cRect.left, y: r.top - cRect.top, w: r.width, h: r.height };
      });
      setRects(next);
    };

    measure();
    const ro = new ResizeObserver(measure);
    if (containerRef.current) ro.observe(containerRef.current);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [isStacked]);

  // Déclenche la construction progressive une seule fois, à l'entrée dans le viewport.
  useEffect(() => {
    if (!inView || startedRef.current) return;
    startedRef.current = true;

    if (reduce) {
      (Object.keys(cardControls) as CardKey[]).forEach((key) => {
        cardControls[key].set({ opacity: 1, y: 0, scale: 1 });
      });
      // eslint-disable-next-line react-hooks/set-state-in-effect -- réaction directe à l'entrée dans le viewport
      setStage(8);
      return;
    }

    const timers: ReturnType<typeof setTimeout>[] = [];
    const runStep = (step: number) => {
      setStage(step);
      const cardKey = STAGE_TO_CARD[step];
      if (cardKey) {
        cardControls[cardKey].start({
          opacity: 1,
          y: 0,
          scale: 1,
          transition: { duration: CARD_DURATION, ease: CARD_EASE },
        });
      }
    };
    runStep(1);
    let elapsed = 0;
    STAGE_DELAYS.forEach((delay, idx) => {
      elapsed += delay;
      timers.push(setTimeout(() => runStep(idx + 2), elapsed));
    });

    return () => {
      timers.forEach(clearTimeout);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- cardControls est stable (useAnimation), inutile en dépendance
  }, [inView, reduce]);

  // Géométrie des connexions : boucle carrée sur desktop/tablette, flux vertical sur mobile.
  let connectors: { start: Point | null; end: Point | null; dir: Dir; stage: number }[] = [];
  if (rects) {
    if (!isStacked) {
      const { intelligence: tl, proactivite: tr, reactivite: br, surveillance: bl } = rects;
      connectors = [
        { start: edgePoint(tl, "right", GAP), end: edgePoint(tr, "left", GAP), dir: { x: 1, y: 0 }, stage: 2 },
        { start: edgePoint(tr, "bottom", GAP), end: edgePoint(br, "top", GAP), dir: { x: 0, y: 1 }, stage: 4 },
        { start: edgePoint(br, "left", GAP), end: edgePoint(bl, "right", GAP), dir: { x: -1, y: 0 }, stage: 6 },
        { start: edgePoint(bl, "top", GAP), end: edgePoint(tl, "bottom", GAP), dir: { x: 0, y: -1 }, stage: 8 },
      ];
    } else {
      const order: CardKey[] = ["intelligence", "proactivite", "reactivite", "surveillance"];
      connectors = order.slice(0, -1).map((key, idx) => {
        const from = rects[key];
        const to = rects[order[idx + 1]];
        return {
          start: edgePoint(from, "bottom", GAP),
          end: edgePoint(to, "top", GAP),
          dir: { x: 0, y: 1 },
          stage: [2, 4, 6][idx],
        };
      });
    }
  }

  return (
    <section id="pourquoi" className="section">
      <div className="container">
        <Reveal className="section-head">
          <span className="eyebrow">Pourquoi Previa</span>
          <h2 className="h2">Une surveillance qui comprend.</h2>
          <p className="lead">
            Previa ne se contente pas d&apos;observer : elle analyse, anticipe et
            alerte, pour une sécurité réellement intelligente.
          </p>
          <span className="section-rule" aria-hidden />
        </Reveal>

        <div className="why-grid" ref={containerRef}>
          <svg className="why-grid-svg" aria-hidden="true">
            {rects &&
              connectors.map((c, idx) => (
                <Connector
                  key={idx}
                  start={c.start}
                  end={c.end}
                  dir={c.dir}
                  reduce={reduce}
                  active={stage >= c.stage}
                />
              ))}
          </svg>

          {CARDS.map((c) => {
            const Icon = c.icon;
            return (
              <div
                key={c.key}
                className={`why-slot why-slot-${c.key}`}
                ref={(el) => {
                  cardRefs.current[c.key] = el;
                }}
              >
                <motion.div
                  className="card"
                  initial={{ opacity: 0, y: 15, scale: 0.98 }}
                  animate={cardControls[c.key]}
                >
                  <span className="card-icon">
                    <Icon width={26} height={26} />
                  </span>
                  <h3 className="card-title">{c.title}</h3>
                  <p className="card-text">{c.text}</p>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
