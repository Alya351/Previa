"use client";

import { useEffect, useState } from "react";
import Modal from "./Modal";
import { IconEdit } from "./icons";
import { setAuthUser, readStoredToken, type AuthUser } from "@/lib/auth";
import { api, ApiError } from "@/lib/api";

export default function EditProfileModal({
  open,
  onClose,
  user,
}: {
  open: boolean;
  onClose: () => void;
  user: AuthUser;
}) {
  const [prenom, setPrenom] = useState(user.prenom ?? "");
  const [nom, setNom] = useState(user.nom ?? "");
  const [entreprise, setEntreprise] = useState(user.entreprise ?? "");
  const [status, setStatus] = useState<"idle" | "saving">("idle");
  const [error, setError] = useState<string | undefined>();

  // Le formulaire est monté avant que la session (async) ne soit résolue :
  // on resynchronise les champs à chaque ouverture du popup.
  useEffect(() => {
    if (open) {
      setPrenom(user.prenom ?? "");
      setNom(user.nom ?? "");
      setEntreprise(user.entreprise ?? "");
      setError(undefined);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (status === "saving") return;
    setError(undefined);

    const token = readStoredToken();
    if (!token) {
      setError("Session expirée. Veuillez vous reconnecter.");
      return;
    }

    setStatus("saving");
    try {
      const updated = await api.me.updateProfile(token, {
        prenom: prenom.trim(),
        nom: nom.trim(),
        entreprise: entreprise.trim(),
      });
      setAuthUser({
        ...user,
        prenom: updated.prenom,
        nom: updated.nom,
        entreprise: updated.entreprise ?? undefined,
        name: `${updated.prenom} ${updated.nom}`.trim() || updated.email,
      });
      setStatus("idle");
      onClose();
    } catch (err) {
      setStatus("idle");
      setError(err instanceof ApiError ? err.message : "Échec de la mise à jour du profil.");
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      icon={<IconEdit width={20} height={20} />}
      title="Modifier mon compte"
      subtitle="Mettez à jour vos informations personnelles."
    >
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {error && <div className="pv-modal-error">{error}</div>}

        <div className="pv-modal-field">
          <label htmlFor="edit-prenom">Prénom</label>
          <input
            id="edit-prenom"
            className="es-input"
            style={{ width: "100%" }}
            value={prenom}
            onChange={(e) => setPrenom(e.target.value)}
            required
          />
        </div>

        <div className="pv-modal-field">
          <label htmlFor="edit-nom">Nom</label>
          <input
            id="edit-nom"
            className="es-input"
            style={{ width: "100%" }}
            value={nom}
            onChange={(e) => setNom(e.target.value)}
            required
          />
        </div>

        <div className="pv-modal-field">
          <label htmlFor="edit-entreprise">Entreprise</label>
          <input
            id="edit-entreprise"
            className="es-input"
            style={{ width: "100%" }}
            value={entreprise}
            onChange={(e) => setEntreprise(e.target.value)}
            placeholder="Optionnel"
          />
        </div>

        <div className="pv-modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Annuler
          </button>
          <button type="submit" className="btn btn-primary" disabled={status === "saving"}>
            {status === "saving" ? "Enregistrement..." : "Enregistrer"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
