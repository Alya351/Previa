"use client";

import { motion } from "motion/react";
import Reveal from "./Reveal";
import { SceneImage, type EnvKey } from "./scenes";

const DOMAINS: { name: string; env: EnvKey }[] = [
  { name: "Sites sensibles", env: "site-sensible" },
  { name: "Établissements", env: "etablissement" },
  { name: "Entreprises", env: "entreprise" },
  { name: "Résidences", env: "residence" },
  { name: "Institutions", env: "institution" },
];

export default function Domains() {
  return (
    <section id="domaines" className="section">
      <div className="container">
        <Reveal className="section-head">
          <span className="eyebrow">Domaines d&apos;utilisation</span>
          <h2 className="h2">Previa s&apos;adapte à vos environnements.</h2>
          <p className="lead">
            D&apos;un bureau à un site sensible, Previa observe et analyse chaque
            contexte avec la même exigence.
          </p>
          <span className="section-rule" aria-hidden />
        </Reveal>

        <div className="domains-grid">
          {DOMAINS.map((d, i) => (
            <motion.article
              key={d.name}
              className="domain"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="domain-visual">
                <SceneImage env={d.env} alt={d.name} />
              </div>
              <div className="domain-label">
                <h3 className="domain-name">{d.name}</h3>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
