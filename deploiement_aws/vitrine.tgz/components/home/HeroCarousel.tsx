"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ENVIRONMENTS, SceneImage } from "./scenes";

const slide = {
  enter: { x: "100%", opacity: 0 },
  center: { x: "0%", opacity: 1 },
  exit: { x: "-100%", opacity: 0 },
};

export default function HeroCarousel({ interval = 4600 }: { interval?: number }) {
  const reduce = useReducedMotion();
  // Compteur strictement croissant : garantit une clé unique à chaque slide,
  // sinon AnimatePresence réutilise une clé déjà sortie et l'animation
  // d'entrée casse au retour sur le même environnement (slide blanc).
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (reduce) return;
    const id = window.setInterval(() => setStep((v) => v + 1), interval);
    return () => window.clearInterval(id);
  }, [interval, reduce]);

  const env = ENVIRONMENTS[step % ENVIRONMENTS.length];

  return (
    <div className="hero-carousel" aria-hidden>
      <AnimatePresence initial={false} mode="sync">
        <motion.div
          key={step}
          className="hero-slide"
          variants={reduce ? undefined : slide}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { duration: 1.1, ease: [0.5, 0, 0.2, 1] },
            opacity: { duration: 1.1 },
          }}
        >
          <SceneImage env={env.key} />
        </motion.div>
      </AnimatePresence>

      {/* Voile pour la lisibilité du texte (adapté au thème) */}
      <div className="hero-veil" />

      {/* Habillage supervision discret */}
      <div className="hero-cam shimmer-hover">
        <span className="hero-rec">
          <i /> LIVE
        </span>
        <AnimatePresence mode="wait">
          <motion.span
            key={step}
            className="hero-cam-label"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.5 }}
          >
            {env.label}
          </motion.span>
        </AnimatePresence>
      </div>
    </div>
  );
}
