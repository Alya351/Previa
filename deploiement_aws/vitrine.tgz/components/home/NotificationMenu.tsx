"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { IconMail } from "./icons";
import NotificationDetail from "./NotificationDetail";

const EASE = [0.22, 1, 0.36, 1] as const;

export type NotifItem = {
  id: string;
  type: string;
  kind: "info" | "success" | "danger";
  title: string;
  text: string;
  /** Date ISO d'origine (pour afficher le jour et l'heure dans la fenêtre de détails). */
  at: string;
  read: boolean;
  link: string | null;
};

/** Corps de la fenêtre de détails, selon le type de notification. */
function detailBody(n: NotifItem, email?: string): ReactNode {
  if (n.type === "reponse") {
    return (
      <div className="nd-lines">
        <p>
          L&apos;équipe Previa vous a répondu par e-mail
          {email ? (
            <>
              {" "}
              à <strong className="nd-accent">{email}</strong>
            </>
          ) : null}
          .
        </p>
        <p>Ouvrez ce message pour lire la réponse.</p>
      </div>
    );
  }
  if (n.type === "code_disponible") {
    return (
      <>
        <p>{n.text}</p>
        <p>
          Pour votre sécurité, le code ne s&apos;affiche qu&apos;après la saisie d&apos;un code de vérification (OTP)
          envoyé par e-mail.
        </p>
      </>
    );
  }
  return <p>{n.text}</p>;
}

function actionLabel(n: NotifItem): string {
  return n.type === "code_disponible" ? "Accéder à mon code" : "Ouvrir mon espace";
}

/** Le panneau ne montre qu'une phrase (comme chez le superadmin) ; le détail complet est dans la fenêtre au clic. */
function firstSentence(text: string): string {
  const m = text.match(/^[\s\S]*?[.!?](?=\s+[A-ZÀ-ÖØ-Þ]|$)/);
  return (m ? m[0] : text).trim();
}

function formatShort(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" });
}

function formatWhen(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString("fr-FR", { dateStyle: "long", timeStyle: "short" });
}

/**
 * Enveloppe + panneau de notifications du client (même habillage que celui du superadmin).
 * Un clic sur une notification ouvre une petite fenêtre avec plus de détails.
 * L'ouverture du panneau marque tout comme lu, comme chez le superadmin.
 */
export default function NotificationMenu({
  items,
  userEmail,
  onMarkAllRead,
  onMarkRead,
}: {
  items: NotifItem[];
  userEmail?: string;
  onMarkAllRead: () => void;
  onMarkRead: (id: string) => void;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState<NotifItem | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", onDown);
    return () => window.removeEventListener("mousedown", onDown);
  }, []);

  const unread = items.filter((n) => !n.read).length;

  const toggle = () => {
    if (!open && unread > 0) onMarkAllRead();
    setOpen((v) => !v);
  };

  const openDetail = (n: NotifItem) => {
    if (!n.read) onMarkRead(n.id);
    setOpen(false);
    setDetail(n);
  };

  const goTo = (path: string) => {
    setDetail(null);
    router.push(path);
  };

  const follow = (n: NotifItem) => {
    setDetail(null);
    if (!n.link) return;
    router.push(n.link);
    // Le lien « ?otp=1 » ouvre directement l'étape du code de vérification (OTP).
    if (n.link.includes("otp=1")) window.dispatchEvent(new Event("previa-open-otp"));
  };

  return (
    <>
      <div className="es-notif" ref={ref}>
        <button
          type="button"
          className="icon-btn es-notif-btn"
          aria-label="Messages et notifications"
          aria-expanded={open}
          onClick={toggle}
        >
          <IconMail width={18} height={18} />
          {unread > 0 && <span className="es-notif-dot">{unread}</span>}
        </button>

        <AnimatePresence>
          {open && (
            <motion.div
              className="es-panel es-notif-panel"
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.2, ease: EASE }}
            >
              <span className="es-panel-title">Notifications</span>
              <div className="es-notif-list">
                {items.length === 0 && <p className="es-notif-empty">Aucune notification.</p>}
                {items.slice(0, 6).map((n) => {
                  const tone = n.kind === "danger" ? "danger" : "success";
                  return (
                    <div
                      key={n.id}
                      className={`es-notif-item es-notif-item--${tone} is-link`}
                      role="button"
                      tabIndex={0}
                      onClick={() => openDetail(n)}
                      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && openDetail(n)}
                    >
                      <span className={`es-notif-icon es-notif-icon--${tone}`} aria-hidden />
                      <div>
                        <p className="es-notif-item-title">{n.title}</p>
                        <p className="es-notif-item-text">{firstSentence(n.text)}</p>
                        <span className="es-notif-item-date">{formatShort(n.at)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <NotificationDetail
        open={!!detail}
        onClose={() => setDetail(null)}
        title={detail?.title ?? ""}
        when={detail ? formatWhen(detail.at) : undefined}
        footer={
          detail?.type === "reponse" ? (
            <>
              Vous n&apos;avez rien reçu ?{" "}
              <button type="button" className="nd-link" onClick={() => goTo("/a-propos#contact")}>
                Contactez-nous
              </button>
            </>
          ) : detail?.link ? (
            <button type="button" className="nd-link" onClick={() => follow(detail)}>
              {actionLabel(detail)}
            </button>
          ) : undefined
        }
      >
        {detail && detailBody(detail, userEmail)}
      </NotificationDetail>
    </>
  );
}
