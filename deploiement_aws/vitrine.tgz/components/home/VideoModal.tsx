"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import { IconClose, IconPlay } from "./icons";

/**
 * Modal vidéo élégante. Architecture prête à recevoir soit une vidéo
 * embarquée (prop `src`), soit une redirection externe (à configurer).
 */
export default function VideoModal({
  open,
  onClose,
  src,
}: {
  open: boolean;
  onClose: () => void;
  src?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="modal-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          onClick={onClose}
        >
          <motion.div
            className="modal"
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            onClick={(e) => e.stopPropagation()}
          >
            <button className="modal-close" onClick={onClose} aria-label="Fermer">
              <IconClose width={18} height={18} />
            </button>
            {src ? (
              <video
                src={src}
                controls
                autoPlay
                playsInline
                style={{ width: "100%", height: "100%", objectFit: "contain", background: "#000" }}
              />
            ) : (
              <div className="modal-placeholder">
                <span
                  style={{
                    display: "inline-flex",
                    width: 60,
                    height: 60,
                    borderRadius: 999,
                    border: "1px solid rgba(255,255,255,0.25)",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "var(--previa-blue)",
                  }}
                >
                  <IconPlay width={26} height={26} />
                </span>
                <span>La vidéo de présentation Previa sera intégrée ici.</span>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
