"use client";

import { motion } from "motion/react";
import Navbar from "./Navbar";
import Hero from "./Hero";
import WhyPrevia from "./WhyPrevia";
import Domains from "./Domains";
import FinalCta from "./FinalCta";
import Footer from "./Footer";

export default function HomePage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Navbar />
      <main>
        <Hero />
        <WhyPrevia />
        <Domains />
        <FinalCta />
      </main>
      <Footer />
    </motion.div>
  );
}
