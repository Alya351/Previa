"use client";

import { useTheme } from "next-themes";
import { useMounted } from "./useMounted";

/** Logo Previa avec variante claire/sombre (suricate blanc sur fond sombre). */
export default function Logo({ height = 30 }: { height?: number }) {
  const { resolvedTheme } = useTheme();
  const mounted = useMounted();
  const src =
    mounted && resolvedTheme === "dark"
      ? "/logo-previa-dark.png"
      : "/logo-previa.png";
  return (
    <img
      src={src}
      alt="Previa"
      style={{ height, width: "auto", display: "block" }}
      draggable={false}
    />
  );
}
