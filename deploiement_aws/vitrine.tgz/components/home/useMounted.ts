"use client";

import { useEffect, useState } from "react";

/** true après le premier montage client (évite les mismatches SSR pour thème, etc.) */
export function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}
