"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ENVIRONMENTS, SceneArt, type EnvKey } from "./scenes";

type SceneTileProps = {
  /** Environnements parcourus par la tuile (ordre = cycle). */
  sequence?: EnvKey[];
  /** Décalage de départ pour désynchroniser les tuiles. */
  start?: number;
  /** Durée d'affichage d'un environnement (ms). */
  interval?: number;
  showScan?: boolean;
};

const ALL = ENVIRONMENTS.map((e) => e.key);

export default function SceneTile({
  sequence = ALL,
  start = 0,
  interval = 4200,
  showScan = true,
}: SceneTileProps) {
  const reduce = useReducedMotion();
  const [i, setI] = useState(start % sequence.length);

  useEffect(() => {
    if (reduce) return;
    const id = window.setInterval(
      () => setI((v) => (v + 1) % sequence.length),
      interval
    );
    return () => window.clearInterval(id);
  }, [interval, sequence.length, reduce]);

  const env = sequence[i];
  const label = ENVIRONMENTS.find((e) => e.key === env)?.label ?? "";

  return (
    <div className="scene-inner" style={{ background: "var(--bg-soft)" }}>
      <div className="scene-frames">
        <AnimatePresence mode="sync">
          <motion.div
            key={env}
            className="scene-frame"
            initial={{ opacity: 0, scale: reduce ? 1 : 1.06 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: reduce ? 1 : 0.99 }}
            transition={{ opacity: { duration: 1.4 }, scale: { duration: interval / 1000 + 1.4, ease: "linear" } }}
          >
            <SceneArt env={env} />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Habillage supervision */}
      <span className="scene-corner sc-tl" />
      <span className="scene-corner sc-tr" />
      <span className="scene-corner sc-br" />
      <span className="scene-corner sc-bl" />

      {showScan && !reduce && (
        <motion.span
          className="scene-scan"
          initial={{ top: "8%", opacity: 0 }}
          animate={{ top: ["8%", "92%"], opacity: [0, 0.8, 0] }}
          transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut", repeatDelay: 1.2 }}
        />
      )}

      {/* Boîte de détection */}
      {!reduce && (
        <motion.span
          className="scene-corner"
          style={{ left: "54%", top: "48%", width: 26, height: 26, borderColor: "var(--previa-blue)", borderStyle: "solid", borderWidth: 1.5 }}
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: [0, 0.9, 0.9, 0], scale: [0.7, 1, 1, 1.2] }}
          transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut", repeatDelay: 0.6 }}
        />
      )}

      <div className="scene-chrome">
        <div className="scene-top">
          <span className="scene-rec">
            <i /> REC
          </span>
          <span style={{ opacity: 0.85, fontVariantNumeric: "tabular-nums" }}>
            CAM {String((i % 8) + 1).padStart(2, "0")}
          </span>
        </div>
        <AnimatePresence mode="wait">
          <motion.span
            key={label}
            className="scene-label"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.5 }}
          >
            {label}
          </motion.span>
        </AnimatePresence>
      </div>
    </div>
  );
}
