"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import Logo from "./Logo";
import { IconFacebook, IconWhatsApp, IconTikTok } from "./icons";

const NAV_LINKS = [
  { label: "Accueil", href: "/" },
  { label: "Solution", href: "/solution" },
  { label: "Offres", href: "/offres" },
  { label: "À propos", href: "/a-propos" },
];

const SOCIALS = [
  { label: "Previa sur Facebook", href: "https://facebook.com", Icon: IconFacebook },
  { label: "Contact Previa sur WhatsApp", href: "https://whatsapp.com", Icon: IconWhatsApp },
  { label: "Previa sur TikTok", href: "https://tiktok.com", Icon: IconTikTok },
];

export default function Footer() {
  const year = new Date().getFullYear();
  const pathname = usePathname();

  return (
    <footer className="ftr">
      <div className="container ftr-inner">
        {/* Emblème : médaillon du logo à cheval sur la séparation de fond */}
        <a
          href="#top"
          className="ftr-emblem"
          aria-label="Retour en haut de la page"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <Logo height={29} />
        </a>

        {/* Navigation filetée */}
        <nav className="ftr-nav" aria-label="Navigation du pied de page">
          {NAV_LINKS.map(({ label, href }) => (
            <Link key={href} href={href} className={pathname === href ? "is-active" : undefined}>
              {label}
            </Link>
          ))}
        </nav>

        {/* Deux colonnes séparées par un filet vertical */}
        <div className="ftr-cols">
          <div className="ftr-col">
            <h3>Contact</h3>
            <div className="ftr-col-list">
              <Link href="/a-propos#equipe">L&apos;équipe</Link>
              <Link href="/connexion">Espace client</Link>
              <Link href="/a-propos#faq">FAQ</Link>
            </div>
          </div>
          <div className="ftr-col">
            <h3>Informations</h3>
            <div className="ftr-col-list">
              <Link href="/a-propos">À propos de Previa</Link>
              <Link href="/solution">Notre solution</Link>
              <Link href="/a-propos#contact">Nous écrire</Link>
            </div>
          </div>
        </div>

        {/* Réseaux */}
        <div className="ftr-connect">
          <div className="ftr-social">
            {SOCIALS.map(({ label, href, Icon }) => (
              <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}>
                <Icon width={20} height={20} />
              </a>
            ))}
          </div>
        </div>

        <div className="ftr-bottom">
          <Link href="/mentions-legales" className="ftr-legal ftr-legal--left">
            Mentions légales
          </Link>
          <p className="ftr-copy">&copy; {year} Previa. Tous droits réservés.</p>
          <Link href="/confidentialite" className="ftr-legal ftr-legal--right">
            Politique de confidentialité
          </Link>
        </div>
      </div>
    </footer>
  );
}
