"use client";

import type { ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { IconClose } from "./icons";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function Modal({
  open,
  onClose,
  icon,
  title,
  subtitle,
  children,
  maxWidth = 420,
}: {
  open: boolean;
  onClose: () => void;
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  children: ReactNode;
  maxWidth?: number;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="pv-modal-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
        >
          <motion.div
            className="pv-modal"
            role="dialog"
            aria-modal="true"
            style={{ maxWidth }}
            initial={{ opacity: 0, scale: 0.94, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.28, ease: EASE }}
            onClick={(e) => e.stopPropagation()}
          >
            <button type="button" className="pv-modal-close" aria-label="Fermer" onClick={onClose}>
              <IconClose width={16} height={16} />
            </button>

            {icon && <span className="pv-modal-icon">{icon}</span>}
            <h3 className="pv-modal-title">{title}</h3>
            {subtitle && <p className="pv-modal-subtitle">{subtitle}</p>}

            <div className="pv-modal-body">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
