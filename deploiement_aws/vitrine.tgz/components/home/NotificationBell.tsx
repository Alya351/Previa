"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, type NotificationApi } from "@/lib/api";
import { readStoredToken } from "@/lib/auth";
import NotificationMenu, { type NotifItem } from "./NotificationMenu";

const REFRESH_MS = 30000;

const toItem = (n: NotificationApi): NotifItem => ({
  id: n.id,
  type: n.type,
  kind: n.titre.toLowerCase().includes("expir") ? "danger" : "success",
  title: n.titre,
  text: n.texte,
  at: n.date,
  read: n.lue,
  link: n.lien,
});

/**
 * Notifications du client connecté, pour les pages du site vitrine (l'espace client a les siennes).
 * Se met à jour seule : le client voit arriver, par exemple, « Réponse à votre demande de devis »
 * sans recharger la page.
 */
export default function NotificationBell({ userEmail }: { userEmail?: string }) {
  const [items, setItems] = useState<NotifItem[]>([]);
  const alive = useRef(true);

  const refresh = useCallback(async () => {
    const token = readStoredToken();
    if (!token) return;
    try {
      const res = await api.me.notifications(token);
      if (alive.current) setItems(res.notifications.map(toItem));
    } catch {
      /* silencieux : nouvel essai au prochain cycle */
    }
  }, []);

  useEffect(() => {
    alive.current = true;
    const first = window.setTimeout(() => void refresh(), 0);
    const id = window.setInterval(() => void refresh(), REFRESH_MS);
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      alive.current = false;
      window.clearTimeout(first);
      window.clearInterval(id);
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh]);

  const markAllRead = () => {
    const token = readStoredToken();
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    if (token) api.me.readAllNotifications(token).catch(() => {});
  };

  const markRead = (id: string) => {
    const token = readStoredToken();
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    if (token) api.me.readNotification(token, id).catch(() => {});
  };

  return <NotificationMenu items={items} userEmail={userEmail} onMarkAllRead={markAllRead} onMarkRead={markRead} />;
}
