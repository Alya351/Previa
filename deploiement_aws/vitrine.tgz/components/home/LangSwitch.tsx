"use client";

import { useLang } from "@/lib/i18n/LangProvider";

/** Sélecteur FR/EN : la langue est mémorisée et appliquée à tout le site. */
export default function LangSwitch() {
  const { lang, setLang } = useLang();
  return (
    <div className="pill-group" role="group" aria-label="Langue" data-no-translate>
      {(["fr", "en"] as const).map((l) => (
        <button
          key={l}
          type="button"
          className={`lang-btn ${lang === l ? "active" : ""}`}
          aria-pressed={lang === l}
          onClick={() => setLang(l)}
        >
          {l.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
