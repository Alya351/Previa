"use client";

import { useState } from "react";

/**
 * Environnements de surveillance.
 * - Si une vraie photo existe dans public/scenes/<key>.jpg, elle est utilisée.
 * - Sinon, repli automatique sur un line-art stylisé (SceneArt), dans la charte.
 */
const BLUE = "#009ee3";

export type EnvKey =
  | "entreprise"
  | "residence"
  | "etablissement"
  | "institution"
  | "site-sensible";

export const ENVIRONMENTS: { key: EnvKey; label: string }[] = [
  { key: "entreprise", label: "Entreprise" },
  { key: "residence", label: "Résidence" },
  { key: "etablissement", label: "Établissement" },
  { key: "institution", label: "Institution" },
  { key: "site-sensible", label: "Site sensible" },
];

function Floor() {
  return (
    <g stroke={BLUE} strokeOpacity={0.18} strokeWidth={1} fill="none">
      <path d="M0 150 L120 96 M320 150 L200 96" />
      <path d="M-20 176 L340 176 M0 200 L320 200" strokeOpacity={0.12} />
    </g>
  );
}

export function SceneArt({ env }: { env: EnvKey }) {
  return (
    <svg
      viewBox="0 0 320 200"
      preserveAspectRatio="xMidYMid slice"
      width="100%"
      height="100%"
      aria-hidden
    >
      <defs>
        <linearGradient id={`wash-${env}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={BLUE} stopOpacity="0.1" />
          <stop offset="100%" stopColor={BLUE} stopOpacity="0.03" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="320" height="200" fill={`url(#wash-${env})`} />
      <Floor />

      {env === "entreprise" && (
        <g stroke={BLUE} fill="none">
          <g strokeOpacity={0.4}>
            <rect x="36" y="34" width="80" height="50" rx="3" />
            <path d="M36 50h80M36 66h80M62 34v50M89 34v50" strokeOpacity={0.25} />
          </g>
          <rect x="150" y="60" width="120" height="30" rx="3" strokeOpacity={0.4} />
          <g strokeOpacity={0.6}>
            <rect x="188" y="98" width="30" height="34" rx="8" />
            <circle cx="203" cy="88" r="9" />
          </g>
        </g>
      )}

      {env === "residence" && (
        <g stroke={BLUE} fill="none">
          <g strokeOpacity={0.45}>
            <path d="M96 96 L150 58 L204 96" />
            <rect x="112" y="96" width="76" height="56" rx="2" />
            <rect x="140" y="118" width="20" height="34" rx="1" strokeOpacity={0.6} />
          </g>
          <path
            d="M24 168h12M52 168v-10M52 168h12M80 168v-10M232 168v-10M232 168h12M260 168v-10"
            strokeOpacity={0.22}
          />
        </g>
      )}

      {env === "etablissement" && (
        <g stroke={BLUE} fill="none">
          <g strokeOpacity={0.42}>
            <path d="M50 62 L160 40 L270 62" />
            <path d="M60 62v72M104 62v72M148 62v72M192 62v72M236 62v72" />
            <path d="M44 134h232M36 150h248M28 166h264" strokeOpacity={0.28} />
          </g>
        </g>
      )}

      {env === "institution" && (
        <g stroke={BLUE} fill="none">
          <g strokeOpacity={0.42}>
            <path d="M60 60 L160 30 L260 60 Z" />
            <path d="M74 60v78M108 60v78M152 60v78M196 60v78M230 60v78" />
            <path d="M50 138h220M44 154h232" strokeOpacity={0.3} />
          </g>
        </g>
      )}

      {env === "site-sensible" && (
        <g stroke={BLUE} fill="none">
          <g strokeOpacity={0.32}>
            <path d="M30 150v-60M70 150v-60M110 150v-60M210 150v-60M250 150v-60M290 150v-60" />
            <path d="M20 96h120M200 96h100" />
          </g>
          <g strokeOpacity={0.6}>
            <path d="M162 150 V70" />
            <rect x="150" y="52" width="24" height="14" rx="3" />
            <path d="M174 59 l12 -5" />
          </g>
        </g>
      )}
    </svg>
  );
}

/**
 * Affiche la vraie photo si disponible, sinon repli sur le line-art.
 * Déposer les fichiers dans public/scenes/<key>.jpg.
 */
export function SceneImage({
  env,
  alt = "",
  className,
}: {
  env: EnvKey;
  alt?: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);
  if (failed) return <SceneArt env={env} />;
  return (
    <img
      src={`/scenes/${env}.jpg`}
      alt={alt}
      className={className}
      loading="lazy"
      decoding="async"
      onError={() => setFailed(true)}
      draggable={false}
      style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
    />
  );
}
