"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import Reveal from "./Reveal";

export default function FinalCta() {
  const reduce = useReducedMotion();
  return (
    <section className="section" style={{ paddingTop: 0 }}>
      <div className="container">
        <div className="cta">
          {/* Formes graphiques subtiles (charte) */}
          {!reduce && (
            <>
              <motion.span
                className="cta-orbit"
                style={{ width: 420, height: 420, left: "50%", top: "-30%", x: "-50%" }}
                animate={{ rotate: 360 }}
                transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
              />
              <motion.span
                className="cta-orbit"
                style={{ width: 640, height: 640, left: "50%", top: "-60%", x: "-50%" }}
                animate={{ rotate: -360 }}
                transition={{ duration: 90, repeat: Infinity, ease: "linear" }}
              />
            </>
          )}

          <Reveal>
            <span className="eyebrow" style={{ justifyContent: "center" }}>
              Prêt à commencer
            </span>
            <motion.h2
              className="cta-title"
              style={{ maxWidth: "none", margin: "clamp(18px, 2.4vw, 28px) auto 0" }}
              initial={{ opacity: 0, scale: 0.96, y: 16 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            >
              Passez à une
              <br />
              surveillance intelligente.
            </motion.h2>
            <div className="cta-actions">
              {/* mène à la section « La solution Previa » de la page Solution */}
              <Link href="/solution#solution" className="btn btn-primary">
                Découvrir Previa
              </Link>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
