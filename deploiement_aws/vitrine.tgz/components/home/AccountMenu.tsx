"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { IconChevronDown, IconLogOut, IconEdit } from "./icons";
import { initialsOf, type AuthUser } from "@/lib/auth";
import EditProfileModal from "./EditProfileModal";

const EASE = [0.22, 1, 0.36, 1] as const;

export type AccountMenuAction = {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  disabled?: boolean;
};

export default function AccountMenu({
  user,
  onLogout,
  showName = false,
  extraActions = [],
}: {
  user: AuthUser;
  onLogout: () => void;
  showName?: boolean;
  extraActions?: AccountMenuAction[];
}) {
  const [open, setOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="es-user" ref={ref}>
      <button
        type="button"
        className="es-user-btn"
        onClick={() => setOpen((v) => !v)}
        aria-label="Menu du compte"
        aria-expanded={open}
      >
        <span className="es-avatar">{initialsOf(user.name)}</span>
        {showName && <span className="nav-desktop-only es-user-name">{user.name}</span>}
        <span className={showName ? "nav-desktop-only es-user-chevron" : "es-user-chevron"}>
          <IconChevronDown width={14} height={14} />
        </span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            className="es-panel es-user-panel"
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.2, ease: EASE }}
          >
            <div className="es-user-panel-head">
              <span className="es-avatar es-avatar--lg">{initialsOf(user.name)}</span>
              <div>
                <p className="es-user-panel-name">{user.name}</p>
                <p className="es-user-panel-email">{user.email}</p>
              </div>
            </div>

            <button
              type="button"
              className="es-user-panel-edit"
              onClick={() => {
                setOpen(false);
                setEditOpen(true);
              }}
            >
              <IconEdit width={16} height={16} />
              Modifier mon compte
            </button>

            {extraActions.map((action) => (
              <button
                key={action.label}
                type="button"
                className="es-user-panel-action"
                disabled={action.disabled}
                onClick={() => {
                  setOpen(false);
                  action.onClick();
                }}
              >
                {action.icon}
                {action.label}
              </button>
            ))}

            <button
              type="button"
              className="es-user-panel-logout"
              onClick={() => {
                setOpen(false);
                onLogout();
              }}
            >
              <IconLogOut width={16} height={16} />
              Se déconnecter
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <EditProfileModal open={editOpen} onClose={() => setEditOpen(false)} user={user} />
    </div>
  );
}
