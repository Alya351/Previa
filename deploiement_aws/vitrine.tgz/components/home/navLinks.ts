export const SITE_LINKS = [
  { label: "Accueil", href: "/" },
  { label: "Solution", href: "/solution" },
  { label: "Offres", href: "/offres" },
  { label: "À propos", href: "/a-propos" },
];

/** Lien affiché uniquement quand l'utilisateur est connecté (son espace : demande, paiement, code d'activation). */
export const ESPACE_LINK = { label: "Mon espace", href: "/code-amorcage" };

/** Accès direct à l'abonnement (suivi des tranches, renouvellement) — même page que l'espace. */
export const ABONNEMENT_LINK = { label: "Mon abonnement / Renouveler", href: "/code-amorcage" };
