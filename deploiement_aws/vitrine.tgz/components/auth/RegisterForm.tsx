"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { IconArrowRight, IconUser, IconMail } from "@/components/home/icons";
import { TextField, PasswordField } from "./fields";
import ConfirmCard from "./ConfirmCard";
import SocialAuth from "./SocialAuth";
import { setAuthSession } from "@/lib/auth";
import { api, ApiError } from "@/lib/api";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Errors = {
  nom?: string;
  prenom?: string;
  email?: string;
  password?: string;
  consent?: string;
  general?: string;
};

export default function RegisterForm({ onSwitch }: { onSwitch: () => void }) {
  const router = useRouter();
  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [consent, setConsent] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "confirm">("idle");

  const validate = () => {
    const next: Errors = {};
    if (nom.trim().length < 2) next.nom = "Veuillez indiquer votre nom.";
    if (prenom.trim().length < 2) next.prenom = "Veuillez indiquer votre prénom.";
    if (!EMAIL_RE.test(email)) next.email = "Adresse e-mail invalide.";
    if (password.length < 8) next.password = "8 caractères minimum.";
    if (!consent) next.consent = "Merci d'accepter les conditions.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate() || status !== "idle") return;
    setStatus("submitting");
    setErrors({});

    try {
      const res = await api.auth.register({
        prenom: prenom.trim(),
        nom: nom.trim(),
        email: email.trim(),
        mot_de_passe: password,
        consentement: consent,
      });

      if ("pendingEmail" in res) {
        setStatus("confirm"); // Supabase : un lien de confirmation vient d'être envoyé
        return;
      }
      setStatus("success");
      setAuthSession(res.compte, res.token);

      window.setTimeout(() => router.push("/code-amorcage"), 2200);
    } catch (err: any) {
      setStatus("idle");
      const msg =
        err instanceof ApiError
          ? err.message
          : "Échec de l'inscription. Veuillez réessayer.";
      setErrors({ general: msg });
    }
  };

  if (status === "success") {
    return (
      <ConfirmCard
        open
        title="Compte créé avec succès"
        text="Bienvenue sur Previa ! Vous allez être redirigé vers votre espace."
        cta="Continuer"
        onContinue={() => router.push("/code-amorcage")}
      />
    );
  }
  if (status === "confirm") {
    return (
      <ConfirmCard
        open
        text={
          <>
            <span>Un e-mail de confirmation vient d&apos;être envoyé</span>
            <span>à {email.trim()}</span>
          </>
        }
        cta="Compris"
        onContinue={() => window.location.reload()}
      />
    );
  }

  return (
    <form className="au-form" onSubmit={handleSubmit} noValidate>
      <div className="au-field-row-2">
        <TextField
          label="Prénom"
          placeholder="Awa"
          value={prenom}
          onChange={(val) => {
            setPrenom(val);
            if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
          }}
          onBlur={() =>
            prenom &&
            setErrors((s) => ({
              ...s,
              prenom: prenom.trim().length < 2 ? "Trop court." : undefined,
            }))
          }
          error={errors.prenom}
          success={prenom.trim().length >= 2}
          autoComplete="given-name"
          icon={<IconUser width={16} height={16} />}
        />
        <TextField
          label="Nom"
          placeholder="Ouédraogo"
          value={nom}
          onChange={(val) => {
            setNom(val);
            if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
          }}
          onBlur={() =>
            nom &&
            setErrors((s) => ({
              ...s,
              nom: nom.trim().length < 2 ? "Trop court." : undefined,
            }))
          }
          error={errors.nom}
          success={nom.trim().length >= 2}
          autoComplete="family-name"
        />
      </div>

      <TextField
        label="Adresse e-mail"
        type="email"
        placeholder="votre@email.com"
        value={email}
        onChange={(val) => {
          setEmail(val);
          if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
        }}
        onBlur={() =>
          email &&
          setErrors((s) => ({
            ...s,
            email: EMAIL_RE.test(email) ? undefined : "Adresse e-mail invalide.",
          }))
        }
        error={errors.email}
        success={EMAIL_RE.test(email)}
        autoComplete="email"
        icon={<IconMail width={16} height={16} />}
      />

      <PasswordField
        label="Mot de passe"
        value={password}
        onChange={(val) => {
          setPassword(val);
          if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
        }}
        error={errors.password}
        autoComplete="new-password"
      />

      <label className="au-remember au-consent">
        <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
        <span className="au-checkbox-box" aria-hidden />
        <span>
          J&apos;accepte les <Link href="/mentions-legales">conditions d&apos;utilisation</Link> et la{" "}
          <Link href="/confidentialite">politique de confidentialité</Link>
        </span>
      </label>
      {errors.consent && <p className="au-consent-error">{errors.consent}</p>}

      <button
        type="submit"
        className="btn btn-primary au-submit"
        disabled={status === "submitting"}
      >
        {status === "submitting" ? (
          <>
            <span className="au-spinner" aria-hidden />
            Création du compte...
          </>
        ) : (
          <>
            Créer mon compte
            <motion.span className="au-submit-arrow" aria-hidden>
              <IconArrowRight width={17} height={17} />
            </motion.span>
          </>
        )}
      </button>

      <SocialAuth />

      {errors.general ? (
        <motion.p
          className="au-switch-footer au-general-error"
          role="alert"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {errors.general}
        </motion.p>
      ) : (
        <p className="au-switch-footer">
          Déjà un compte ?{" "}
          <button type="button" className="au-link" onClick={onSwitch}>
            Se connecter
          </button>
        </p>
      )}
    </form>
  );
}
