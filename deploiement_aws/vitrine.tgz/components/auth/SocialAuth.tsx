"use client";

import { useState } from "react";
import { IconGoogle } from "@/components/home/icons";
import { api, ApiError } from "@/lib/api";

const errorStyle = { margin: "8px 0 0", fontSize: 12, textAlign: "center", color: "var(--danger, #d64545)" } as const;

/* Séparateur « Ou » + bouton Google pleine largeur */
export default function SocialAuth() {
  const [error, setError] = useState<string | null>(null);
  const start = async () => {
    setError(null);
    try {
      await api.auth.oauth("google");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Connexion impossible. Veuillez réessayer.");
    }
  };
  return (
    <div className="au-social-mini">
      <div className="au-divider au-divider--mini">
        <span />
        <span className="au-divider-text">Ou</span>
        <span />
      </div>
      <button type="button" className="au-google-btn" onClick={start}>
        <IconGoogle width={18} height={18} />
        Continuer avec Google
      </button>
      {error && <p role="alert" style={errorStyle}>{error}</p>}
    </div>
  );
}
