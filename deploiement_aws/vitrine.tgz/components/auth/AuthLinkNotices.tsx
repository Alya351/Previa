"use client";

import { useEffect, useState } from "react";
import Modal from "@/components/home/Modal";
import ConfirmCard from "./ConfirmCard";
import { IconCheck, IconAlertTriangle, IconLock } from "@/components/home/icons";
import { PasswordField } from "./fields";
import { api, ApiError } from "@/lib/api";
import { SUPABASE_ENABLED, clientAuth, pendingLink } from "@/lib/supabase";
import { bindClientSync, completeClientLogin } from "@/lib/auth";

type State =
  | { kind: "none" }
  | { kind: "verifying" }
  | { kind: "verified" }
  | { kind: "verify-error"; message: string }
  | { kind: "reset"; token: string }
  | { kind: "reset-done" };

function stripParams(...keys: string[]) {
  const url = new URL(window.location.href);
  keys.forEach((k) => url.searchParams.delete(k));
  window.history.replaceState({}, "", url.pathname + (url.search ? url.search : ""));
}

/** Gère les liens reçus par e-mail : ?verify=<jeton> (confirmation) et ?reset=<jeton> (nouveau mot de passe). */
export default function AuthLinkNotices() {
  const [state, setState] = useState<State>({ kind: "none" });
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (SUPABASE_ENABLED) {
      // Liens Supabase : le jeton arrive dans le fragment d'URL (#access_token=…&type=signup|recovery).
      bindClientSync();
      const link = pendingLink();
      if (link.kind === "error") {
        setState({ kind: "verify-error", message: link.error });
      } else if (link.kind === "signup" || link.kind === "email_change") {
        setState({ kind: "verifying" });
        void (async () => {
          const { data } = await clientAuth().auth.getSession();
          if (data.session && (await completeClientLogin(data.session.access_token))) {
            setState({ kind: "verified" });
          } else {
            setState({ kind: "verify-error", message: "Confirmation impossible. Connectez-vous avec votre adresse e-mail." });
          }
        })();
      } else if (link.kind === "recovery") {
        setState({ kind: "reset", token: "supabase" });
      }
      return;
    }
    const params = new URLSearchParams(window.location.search);
    const verify = params.get("verify");
    const reset = params.get("reset");
    if (verify) {
      setState({ kind: "verifying" });
      api.auth
        .verifyEmail(verify)
        .then(() => setState({ kind: "verified" }))
        .catch((err) =>
          setState({
            kind: "verify-error",
            message: err instanceof ApiError ? err.message : "Lien de confirmation invalide ou expiré.",
          })
        )
        .finally(() => stripParams("verify"));
    } else if (reset) {
      setState({ kind: "reset", token: reset });
    }
  }, []);

  const close = () => {
    // Session « récupération » ouverte par le lien : on la ferme si le mot de passe n'a pas été changé.
    if (SUPABASE_ENABLED && state.kind === "reset") void clientAuth().auth.signOut();
    setState({ kind: "none" });
  };
  const continueToSpace = () => {
    close();
    if (SUPABASE_ENABLED) window.location.assign("/code-amorcage");
  };

  const submitReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (state.kind !== "reset" || busy) return;
    setBusy(true);
    setError(undefined);
    try {
      await api.auth.resetPassword(state.token, password);
      stripParams("reset");
      setPassword("");
      setState({ kind: "reset-done" });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Lien invalide ou expiré.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <ConfirmCard
        open={state.kind === "verified"}
        title="Adresse e-mail confirmée"
        text="Vous pouvez maintenant souscrire un abonnement depuis votre espace."
        cta="Continuer"
        onContinue={continueToSpace}
      />

      <Modal
        open={state.kind === "verify-error"}
        onClose={close}
        icon={<IconAlertTriangle width={20} height={20} />}
        title="Confirmation impossible"
        subtitle={state.kind === "verify-error" ? state.message : ""}
        maxWidth={380}
      >
        <button type="button" className="btn btn-primary" onClick={close}>
          Fermer
        </button>
      </Modal>

      <Modal
        open={state.kind === "reset"}
        onClose={close}
        icon={<IconLock width={20} height={20} />}
        title="Nouveau mot de passe"
        subtitle="Choisissez un nouveau mot de passe (8 caractères minimum)."
        maxWidth={400}
      >
        <form onSubmit={submitReset} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {error && <div className="pv-modal-error">{error}</div>}
          <PasswordField
            label="Mot de passe"
            value={password}
            onChange={setPassword}
            autoComplete="new-password"
          />
          <div className="pv-modal-actions">
            <button type="button" className="btn btn-secondary" onClick={close}>
              Annuler
            </button>
            <button type="submit" className="btn btn-primary" disabled={busy || password.length < 8}>
              {busy ? "Enregistrement..." : "Enregistrer"}
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={state.kind === "reset-done"}
        onClose={close}
        icon={<IconCheck width={20} height={20} />}
        title="Mot de passe mis à jour"
        subtitle="Vous pouvez maintenant vous connecter avec votre nouveau mot de passe."
        maxWidth={380}
      >
        <button type="button" className="btn btn-primary" onClick={close}>
          Se connecter
        </button>
      </Modal>
    </>
  );
}
