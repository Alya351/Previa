"use client";

import { motion, useTransform, type MotionValue } from "motion/react";

type Props = {
  px: MotionValue<number>;
  py: MotionValue<number>;
};

export default function AuthBackground({ px, py }: Props) {
  const wave1X = useTransform(px, (v) => v * 1.4);
  const wave1Y = useTransform(py, (v) => v * 1.4);
  const wave2X = useTransform(px, (v) => v * -1.1);
  const wave2Y = useTransform(py, (v) => v * -1.1);
  const orbX = useTransform(px, (v) => v * 2.2);
  const orbY = useTransform(py, (v) => v * 2.2);

  return (
    <div className="au-bg" aria-hidden>
      <span className="au-bg-base" />
      <motion.span className="au-bg-wave au-bg-wave--top" style={{ x: wave1X, y: wave1Y }} />
      <motion.span className="au-bg-wave au-bg-wave--bottom" style={{ x: wave2X, y: wave2Y }} />
      <motion.span className="au-bg-orb au-bg-orb--1" style={{ x: orbX, y: orbY }} />
      <span className="au-bg-orb au-bg-orb--2" />
      <span className="au-bg-orb au-bg-orb--3" />
      <span className="au-bg-line au-bg-line--1" />
      <span className="au-bg-line au-bg-line--2" />
      <span className="au-bg-grain" />
    </div>
  );
}
