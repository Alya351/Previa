"use client";

import { motion, useReducedMotion } from "motion/react";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function AuthVisual() {
  const reduce = useReducedMotion();

  return (
    <motion.div
      className="au-logo-wrap"
      initial={{ opacity: 0, scale: reduce ? 1 : 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: EASE, delay: 0.05 }}
    >
      {!reduce && <span className="au-logo-glow" aria-hidden />}
      <span className="au-logo">
        <img src="/logo-previa.png" alt="Previa" className="au-logo-img" draggable={false} />
        {!reduce && <span className="au-logo-shine" aria-hidden />}
      </span>
    </motion.div>
  );
}
