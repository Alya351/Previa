"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { IconArrowRight, IconMail } from "@/components/home/icons";
import { TextField, PasswordField } from "./fields";
import ConfirmCard from "./ConfirmCard";
import { setAuthSession } from "@/lib/auth";
import { api, ApiError } from "@/lib/api";
import Modal from "@/components/home/Modal";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginForm({ onSwitch }: { onSwitch: () => void }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState<{ email?: string; password?: string; general?: string }>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const [next, setNext] = useState("/code-amorcage");
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotState, setForgotState] = useState<"idle" | "sending" | "sent">("idle");

  const sendForgot = async () => {
    if (!EMAIL_RE.test(forgotEmail) || forgotState === "sending") return;
    setForgotState("sending");
    try {
      await api.auth.forgotPassword(forgotEmail.trim());
    } catch {
      // Réponse volontairement identique : on ne révèle rien sur l'existence du compte.
    }
    setForgotState("sent");
  };

  const validate = () => {
    const next: typeof errors = {};
    if (!EMAIL_RE.test(email)) next.email = "Adresse e-mail invalide.";
    if (password.length < 1) next.password = "Le mot de passe est requis.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate() || status !== "idle") return;
    setStatus("submitting");
    setErrors({});

    try {
      const res = await api.auth.login(email.trim(), password);
      const target = res.compte.role === "admin" ? "/prevadm" : "/code-amorcage";
      setNext(target);
      setStatus("success");
      setAuthSession(res.compte, res.token);

      // Redirection automatique, le temps de voir la carte ; « Continuer » passe tout de suite.
      window.setTimeout(() => router.push(target), 2200);
    } catch (err: any) {
      setStatus("idle");
      const msg =
        err instanceof ApiError
          ? err.message
          : "Échec de la connexion. Vérifiez vos identifiants.";
      setErrors({ general: msg });
    }
  };

  if (status === "success") {
    return (
      <ConfirmCard
        open
        title="Connexion réussie"
        text="Bienvenue ! Vous allez être redirigé vers votre espace."
        cta="Continuer"
        onContinue={() => router.push(next)}
      />
    );
  }

  return (
    <form className="au-form" onSubmit={handleSubmit} noValidate>
      <TextField
        label="Adresse e-mail"
        type="email"
        placeholder="votre@email.com"
        value={email}
        onChange={(val) => {
          setEmail(val);
          if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
        }}
        onBlur={() =>
          email &&
          setErrors((s) => ({
            ...s,
            email: EMAIL_RE.test(email) ? undefined : "Adresse e-mail invalide.",
          }))
        }
        error={errors.email}
        success={EMAIL_RE.test(email)}
        autoComplete="email"
        icon={<IconMail width={16} height={16} />}
      />

      <PasswordField
        label="Mot de passe"
        value={password}
        onChange={(val) => {
          setPassword(val);
          if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
        }}
        error={errors.password}
        autoComplete="current-password"
      />

      <div className="au-forgot-row au-remember-row">
        <label className="au-remember">
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          <span className="au-checkbox-box" aria-hidden />
          Se souvenir de moi
        </label>
        <a
          href="#"
          className="au-link-muted"
          onClick={(e) => {
            e.preventDefault();
            setForgotEmail(email);
            setForgotState("idle");
            setForgotOpen(true);
          }}
        >
          Mot de passe oublié ?
        </a>
      </div>

      <button
        type="submit"
        className="btn btn-primary au-submit"
        disabled={status === "submitting"}
      >
        {status === "submitting" ? (
          <>
            <span className="au-spinner" aria-hidden />
            Connexion en cours...
          </>
        ) : (
          <>
            Se connecter
            <motion.span className="au-submit-arrow" aria-hidden>
              <IconArrowRight width={17} height={17} />
            </motion.span>
          </>
        )}
      </button>

      {errors.general ? (
        <motion.p
          className="au-switch-footer au-general-error"
          role="alert"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {errors.general}
        </motion.p>
      ) : (
        <p className="au-switch-footer">
          Vous n&apos;avez pas encore de compte ?{" "}
          <button type="button" className="au-link" onClick={onSwitch}>
            S&apos;inscrire
          </button>
        </p>
      )}

      <Modal
        open={forgotOpen}
        onClose={() => setForgotOpen(false)}
        icon={<IconMail width={20} height={20} />}
        title="Mot de passe oublié"
        subtitle={
          forgotState === "sent"
            ? "Si un compte existe pour cette adresse, un e-mail de réinitialisation vient de vous être envoyé."
            : "Saisissez votre adresse e-mail : nous vous enverrons un lien pour choisir un nouveau mot de passe."
        }
        maxWidth={400}
      >
        {forgotState === "sent" ? (
          <button type="button" className="btn btn-primary" onClick={() => setForgotOpen(false)}>
            Fermer
          </button>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <TextField
              label="Adresse e-mail"
              type="email"
              placeholder="votre@email.com"
              value={forgotEmail}
              onChange={setForgotEmail}
              autoComplete="email"
              icon={<IconMail width={16} height={16} />}
            />
            <div className="pv-modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setForgotOpen(false)}>
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                disabled={!EMAIL_RE.test(forgotEmail) || forgotState === "sending"}
                onClick={sendForgot}
              >
                {forgotState === "sending" ? "Envoi..." : "Envoyer le lien"}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </form>
  );
}
