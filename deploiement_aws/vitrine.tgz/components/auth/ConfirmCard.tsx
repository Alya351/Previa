"use client";

import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { IconCheck } from "@/components/home/icons";
import { useMounted } from "@/components/home/useMounted";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Confettis : position (%), taille (px), rotation de départ, délai (s). */
const CONFETTI = [
  { x: 8, y: 14, s: 12, r: 20, d: 0 },
  { x: 20, y: 6, s: 8, r: -35, d: 0.4 },
  { x: 30, y: 22, s: 10, r: 55, d: 0.9 },
  { x: 68, y: 10, s: 11, r: -20, d: 0.2 },
  { x: 82, y: 20, s: 9, r: 40, d: 0.7 },
  { x: 90, y: 8, s: 12, r: -50, d: 1.1 },
  { x: 14, y: 40, s: 7, r: 15, d: 1.3 },
  { x: 88, y: 42, s: 8, r: 70, d: 0.5 },
];

type Props = {
  open: boolean;
  title?: string;
  text: ReactNode;
  cta: string;
  onContinue: () => void;
};

/**
 * Carte de confirmation plein écran (fond flouté de la page de connexion conservé derrière).
 * Rendue dans <body> : la carte de connexion a un backdrop-filter, qui ferait d'elle le repère
 * des éléments `position: fixed` et rognerait le voile à ses propres bords.
 */
export default function ConfirmCard({ open, title, text, cta, onContinue }: Props) {
  const reduce = useReducedMotion();
  const mounted = useMounted();
  if (!mounted) return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="au-confirm"
          role="dialog"
          aria-modal="true"
          aria-label={title ?? "Confirmation"}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <motion.div
            className="au-confirm-card"
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.5, ease: EASE }}
          >
            <span className="au-confirm-glow" aria-hidden="true" />
            <div className="au-confirm-confetti" aria-hidden="true">
              {CONFETTI.map((c, i) => (
                <span
                  key={i}
                  className={reduce ? undefined : "is-anim"}
                  style={{
                    left: `${c.x}%`,
                    top: `${c.y}%`,
                    width: c.s,
                    height: c.s * 0.6,
                    transform: `rotate(${c.r}deg)`,
                    animationDelay: `${c.d}s`,
                  }}
                />
              ))}
            </div>

            <motion.span
              className="au-confirm-check"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 16, delay: 0.15 }}
            >
              <span>
                <IconCheck width={34} height={34} />
              </span>
            </motion.span>

            {title && <h2 className="au-confirm-title">{title}</h2>}
            <p className={`au-confirm-text${title ? "" : " is-solo"}`}>{text}</p>

            <button type="button" className="au-confirm-cta" onClick={onContinue}>
              {cta}
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
