"use client";

import { useEffect, useRef, useState, type ComponentType } from "react";
import Link from "next/link";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
} from "motion/react";
import ThemeToggle from "@/components/home/ThemeToggle";
import { IconHome } from "@/components/home/icons";
import AuthBackground from "./AuthBackground";
import AuthVisual from "./AuthVisual";
import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import AuthLinkNotices from "./AuthLinkNotices";

const EASE = [0.22, 1, 0.36, 1] as const;

type Mode = "login" | "register";

const DEFAULT_COPY: Record<Mode, { title: string; subtitle: string }> = {
  login: {
    title: "Bon retour.",
    subtitle: "Connectez-vous à votre espace Previa.",
  },
  register: {
    title: "Créez votre compte.",
    subtitle: "Rejoignez votre espace Previa.",
  },
};

type FormProps = { onSwitch: () => void };

type AuthPageProps = {
  copy?: Record<Mode, { title: string; subtitle: string }>;
  LoginFormComponent?: ComponentType<FormProps>;
  RegisterFormComponent?: ComponentType<FormProps>;
  /** false : pas d'onglet d'inscription (espace superadmin). */
  allowRegister?: boolean;
  backHref?: string;
  backLabel?: string;
  eyebrow?: string;
  /** Onglet affiché à l'ouverture (la page /inscription ouvre directement l'inscription). */
  initialMode?: Mode;
};

const contentVariants = {
  enter: (dir: number) => ({
    opacity: 0,
    x: dir >= 0 ? 44 : -44,
    scale: 0.94,
    filter: "blur(10px)",
  }),
  center: {
    opacity: 1,
    x: 0,
    scale: 1,
    filter: "blur(0px)",
    transition: {
      duration: 0.55,
      ease: EASE,
      delayChildren: 0.08,
      staggerChildren: 0.07,
    },
  },
  exit: (dir: number) => ({
    opacity: 0,
    x: dir >= 0 ? -44 : 44,
    scale: 0.94,
    filter: "blur(10px)",
    transition: { duration: 0.32, ease: EASE },
  }),
};

const contentVariantsReduced = {
  enter: { opacity: 0 },
  center: { opacity: 1, transition: { duration: 0.3, ease: EASE, staggerChildren: 0.05 } },
  exit: { opacity: 0, transition: { duration: 0.2, ease: EASE } },
};

const itemVariants = {
  enter: { opacity: 0, y: 16 },
  center: { opacity: 1, y: 0, transition: { duration: 0.42, ease: EASE } },
};

const itemVariantsReduced = {
  enter: { opacity: 0 },
  center: { opacity: 1, transition: { duration: 0.25, ease: EASE } },
};

export default function AuthPage({
  copy = DEFAULT_COPY,
  LoginFormComponent = LoginForm,
  RegisterFormComponent = RegisterForm,
  allowRegister = true,
  backHref = "/",
  backLabel = "Retour au site",
  eyebrow,
  initialMode = "login",
}: AuthPageProps = {}) {
  const [mode, setMode] = useState<Mode>(allowRegister ? initialMode : "login");
  const [direction, setDirection] = useState(0);
  const reduce = useReducedMotion();
  const shellRef = useRef<HTMLDivElement>(null);

  const switchMode = (next: Mode) => {
    if (next === mode) return;
    setDirection(next === "register" ? 1 : -1);
    setMode(next);
  };

  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const px = useSpring(rawX, { stiffness: 55, damping: 18, mass: 0.6 });
  const py = useSpring(rawY, { stiffness: 55, damping: 18, mass: 0.6 });
  const cardX = useTransform(px, (v) => v * 0.3);
  const cardY = useTransform(py, (v) => v * 0.3);

  useEffect(() => {
    if (reduce) return;
    const canParallax = window.matchMedia("(hover: hover) and (pointer: fine) and (min-width: 860px)");
    if (!canParallax.matches) return;

    const handleMove = (e: MouseEvent) => {
      const rect = shellRef.current?.getBoundingClientRect();
      if (!rect) return;
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const nx = (e.clientX - cx) / (rect.width / 2);
      const ny = (e.clientY - cy) / (rect.height / 2);
      rawX.set(Math.max(-1, Math.min(1, nx)) * 16);
      rawY.set(Math.max(-1, Math.min(1, ny)) * 16);
    };
    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, [reduce, rawX, rawY]);

  return (
    <div className="au-shell" ref={shellRef}>
      <AuthBackground px={px} py={py} />
      {allowRegister && <AuthLinkNotices />}

      <div className="au-topbar">
        <Link href={backHref} className="au-back">
          <span className="au-back-icon" aria-hidden>
            <IconHome width={15} height={15} />
          </span>
          <span className="au-back-text">{backLabel}</span>
        </Link>
        <ThemeToggle />
      </div>

      <motion.div
        className={`au-card ${eyebrow ? "au-card--admin" : "au-card--client"} au-card--${mode}`}
        layout
        style={reduce ? undefined : { x: cardX, y: cardY }}
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{
          opacity: { duration: 0.5, ease: EASE },
          scale: { duration: 0.5, ease: EASE },
          layout: { duration: 0.45, ease: EASE },
        }}
      >
        <span className="au-card-shine" aria-hidden />

        <div className="au-card-inner">
          <div className="au-header">
            <AuthVisual />
            {eyebrow && <span className="au-admin-eyebrow">{eyebrow}</span>}

            {allowRegister && (
            <motion.div
              className="au-switch"
              role="tablist"
              aria-label="Connexion ou inscription"
              initial={{ opacity: 0, y: reduce ? 0 : 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: EASE, delay: 0.18 }}
            >
              <button
                type="button"
                role="tab"
                aria-selected={mode === "login"}
                className={`au-switch-btn ${mode === "login" ? "is-active" : ""}`}
                onClick={() => switchMode("login")}
              >
                Connexion
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={mode === "register"}
                className={`au-switch-btn ${mode === "register" ? "is-active" : ""}`}
                onClick={() => switchMode("register")}
              >
                Inscription
              </button>
              <motion.span
                className="au-switch-thumb"
                animate={{ x: mode === "login" ? "0%" : "100%" }}
                transition={{ duration: 0.35, ease: EASE }}
              />
            </motion.div>
            )}
          </div>

          <AnimatePresence mode="popLayout" initial={false} custom={direction}>
            <motion.div
              key={mode}
              className="au-content"
              custom={direction}
              variants={reduce ? contentVariantsReduced : contentVariants}
              initial="enter"
              animate="center"
              exit="exit"
            >
              <motion.h1 className="au-title" variants={reduce ? itemVariantsReduced : itemVariants}>
                {copy[mode].title}
              </motion.h1>
              <motion.p className="au-subtitle" variants={reduce ? itemVariantsReduced : itemVariants}>
                {copy[mode].subtitle}
              </motion.p>

              <motion.div variants={reduce ? itemVariantsReduced : itemVariants}>
                {mode === "login" || !allowRegister ? (
                  <LoginFormComponent onSwitch={() => switchMode("register")} />
                ) : (
                  <RegisterFormComponent onSwitch={() => switchMode("login")} />
                )}
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
