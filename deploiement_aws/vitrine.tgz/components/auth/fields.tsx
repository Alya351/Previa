"use client";

import { useId, useState } from "react";
import { motion } from "motion/react";
import type { ReactNode } from "react";
import { IconEye, IconEyeOff, IconCheck, IconLock } from "@/components/home/icons";

type TextFieldProps = {
  label: string;
  type?: string;
  placeholder?: string;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  error?: string;
  success?: boolean;
  autoComplete?: string;
  icon?: ReactNode;
};

export function TextField({
  label,
  type = "text",
  placeholder,
  value,
  onChange,
  onBlur,
  error,
  success,
  autoComplete,
  icon,
}: TextFieldProps) {
  const id = useId();
  const state = error ? "error" : success ? "success" : "idle";

  return (
    <div className={`au-field au-field--${state}`}>
      <label htmlFor={id} className="au-label">
        {label}
      </label>
      <div className="au-input-wrap">
        {icon && (
          <span className="au-input-icon-left" aria-hidden>
            {icon}
          </span>
        )}
        <input
          id={id}
          type={type}
          className={`au-input ${icon ? "au-input--icon" : ""}`}
          placeholder={placeholder}
          value={value}
          autoComplete={autoComplete}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          aria-invalid={!!error}
        />
        {success && (
          <span className="au-input-icon au-input-icon--ok" aria-hidden>
            <IconCheck width={15} height={15} />
          </span>
        )}
      </div>
      {error && (
        <motion.span
          className="au-field-msg"
          initial={{ opacity: 0, x: -4 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
        >
          {error}
        </motion.span>
      )}
    </div>
  );
}

type PasswordFieldProps = {
  label: string;
  placeholder?: string;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  error?: string;
  success?: boolean;
  autoComplete?: string;
};

export function PasswordField({
  label,
  placeholder = "••••••••••",
  value,
  onChange,
  onBlur,
  error,
  success,
  autoComplete,
}: PasswordFieldProps) {
  const id = useId();
  const [visible, setVisible] = useState(false);
  const state = error ? "error" : success ? "success" : "idle";

  return (
    <div className={`au-field au-field--${state}`}>
      <label htmlFor={id} className="au-label">
        {label}
      </label>
      <div className="au-input-wrap">
        <span className="au-input-icon-left" aria-hidden>
          <IconLock width={16} height={16} />
        </span>
        <input
          id={id}
          type={visible ? "text" : "password"}
          className="au-input au-input--icon au-input--password"
          placeholder={placeholder}
          value={value}
          autoComplete={autoComplete}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          aria-invalid={!!error}
        />
        <button
          type="button"
          className="au-eye-btn"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? "Masquer le mot de passe" : "Afficher le mot de passe"}
        >
          <motion.span
            key={visible ? "on" : "off"}
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.18 }}
            style={{ display: "inline-flex" }}
          >
            {visible ? <IconEyeOff width={17} height={17} /> : <IconEye width={17} height={17} />}
          </motion.span>
        </button>
      </div>
      {error && (
        <motion.span
          className="au-field-msg"
          initial={{ opacity: 0, x: -4 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
        >
          {error}
        </motion.span>
      )}
    </div>
  );
}
