"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { readStoredToken, readStoredUser, useAuthUser } from "@/lib/auth";
import EspaceCodeAmorcagePage from "@/components/espace/EspaceCodeAmorcagePage";

/**
 * /code-amorcage est désormais l'espace du client connecté (demande, paiement, code d'activation).
 * Le contenu explicatif destiné aux visiteurs vit dans la page Offres (#activation) :
 * un visiteur qui arrive ici y est renvoyé.
 *
 * `useAuthUser` renvoie `null` aussi pendant la lecture de la session ; on tranche donc sur le
 * stockage local (jeton / utilisateur), et seulement une fois monté, pour ne jamais renvoyer
 * à tort un client connecté.
 */
export default function CodeAmorcageGate() {
  const authUser = useAuthUser();
  const router = useRouter();

  useEffect(() => {
    if (!authUser && !readStoredUser() && !readStoredToken()) {
      router.replace("/offres#activation");
    }
  }, [authUser, router]);

  if (!authUser) return null;
  return <EspaceCodeAmorcagePage />;
}
