"use client";

import Navbar from "@/components/home/Navbar";
import Footer from "@/components/home/Footer";
import SolutionHero from "./SolutionHero";
import ResponsePrevia from "./ResponsePrevia";
import HowItWorks from "./HowItWorks";
import Features from "./Features";
import GetPrevia from "./GetPrevia";
import Download from "@/components/home/Download";

export default function SolutionPage() {
  return (
    <>
      <Navbar />
      <main>
        <SolutionHero />
        <ResponsePrevia />
        <HowItWorks />
        <Features />
        <GetPrevia />
        <Download />
      </main>
      <Footer />
    </>
  );
}
