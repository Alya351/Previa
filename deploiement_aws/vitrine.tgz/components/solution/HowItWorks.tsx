"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { useInView, useReducedMotion } from "motion/react";
import Reveal from "@/components/home/Reveal";
import { IconIntelligence, IconSurveillance, IconPhone, IconCheck } from "@/components/home/icons";

/**
 * « Le trajet du signal » : trois cartes reliées par un fil lumineux.
 * À l'arrivée de la section, une impulsion part de la 1re carte, traverse le fil et
 * allume chaque étape à son passage ; chaque carte joue alors sa mini-scène en boucle.
 * La séquence se rejoue à chaque retour de la section à l'écran ; survoler ou toucher
 * une carte relance sa scène. Ensuite, une impulsion discrète continue de circuler.
 */

/* Cadre de caméra commun : décor de pièce, REC, repère de caméra */
function Frame({ label, children }: { label: string; children: ReactNode }) {
  return (
    <svg viewBox="0 0 240 140" className="sol-fl-svg" aria-hidden focusable="false">
      <g className="fl-room">
        <path d="M0 108h240" />
        <rect x="178" y="42" width="40" height="66" rx="3" />
        <path d="M184 62h28M184 82h28" />
        <rect x="26" y="40" width="34" height="26" rx="3" />
        <path d="M43 40v26M26 53h34" />
      </g>
      <circle className="fl-rec" cx="208" cy="28" r="3.5" />
      {label && (
        <text className="fl-cam" x="24" y="29">
          {label}
        </text>
      )}
      {children}
    </svg>
  );
}

function Person({ x, className }: { x: number; className?: string }) {
  return (
    <g className={className}>
      <circle cx={x} cy="62" r="11" />
      <path d={`M${x - 24} 118c0-28 11-40 24-40s24 12 24 40z`} />
    </g>
  );
}

function SceneAnalyse() {
  return (
    <Frame label="CAM 01">
      <g className="fl-walker">
        <Person x={96} className="fl-person" />
      </g>
      <g className="fl-keypoints">
        {[
          [96, 62],
          [78, 82],
          [114, 82],
          [96, 96],
          [86, 116],
          [106, 116],
        ].map(([cx, cy]) => (
          <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r="2.6" />
        ))}
      </g>
      <g className="fl-dots">
        {[44, 70, 96, 122, 148, 174, 200].map((cx, i) =>
          [44, 70, 96].map((cy) => <circle key={`${i}-${cy}`} cx={cx} cy={cy} r="1.6" />),
        )}
      </g>
      <rect className="fl-scan" x="24" y="34" width="192" height="3" rx="1.5" />
      <text className="fl-status" x="24" y="124">
        Analyse en cours
        <tspan className="fl-d1">.</tspan>
        <tspan className="fl-d2">.</tspan>
        <tspan className="fl-d3">.</tspan>
      </text>
    </Frame>
  );
}

function SceneComprendre() {
  return (
    <Frame label="">
      <Person x={76} className="fl-person fl-person--calm" />
      <rect className="fl-box fl-box--calm" x="48" y="46" width="56" height="76" rx="6" />
      <g className="fl-tag fl-tag--calm">
        <rect x="52" y="26" width="48" height="15" rx="7.5" />
        <text x="76" y="36.4" textAnchor="middle">
          Normal
        </text>
      </g>

      <Person x={166} className="fl-person fl-person--focus" />
      <g className="fl-skeleton">
        <path d="M166 74v22M166 80l-16 10M166 80l20-12M166 96l-10 20M166 96l12 20" />
      </g>
      <rect className="fl-box" x="136" y="46" width="60" height="76" rx="6" />
      <path className="fl-trail" d="M216 118C204 108 198 100 190 92" />
      <g className="fl-label">
        <rect x="120" y="22" width="100" height="17" rx="8.5" />
        <text x="170" y="33.8" textAnchor="middle">
          Inhabituel
        </text>
      </g>
    </Frame>
  );
}

function ScenePrevenir() {
  return (
    <svg viewBox="0 0 240 140" className="sol-fl-svg" aria-hidden focusable="false">
      <g className="fl-ripples">
        <circle cx="62" cy="68" r="14" />
        <circle cx="62" cy="68" r="14" />
        <circle cx="62" cy="68" r="14" />
      </g>
      <g className="fl-lamp">
        <path className="fl-bulb" d="M52 68a10 10 0 1 1 20 0c0 5-3 6-3 11H55c0-5-3-6-3-11z" />
        <path d="M56 87h12M58 93h8" />
        <path className="fl-rays" d="M62 42v-6M44 50l-4-4M80 50l4-4M36 68h-6M88 68h6" />
      </g>
      <g className="fl-phone">
        <rect x="140" y="12" width="70" height="116" rx="13" />
        <path d="M165 20h20" />
        <rect className="fl-feed" x="148" y="64" width="54" height="40" rx="5" />
        <circle className="fl-feed-dot" cx="175" cy="80" r="5" />
        <path className="fl-feed-dot" d="M163 102c0-8 5-12 12-12s12 4 12 12" />
      </g>
      <g className="fl-notif">
        <rect x="147" y="30" width="56" height="26" rx="7" />
        <circle cx="160" cy="43" r="5" />
        <path d="M169 40h24M169 46h16" />
      </g>
      <g className="fl-sent">
        <rect x="70" y="112" width="100" height="18" rx="9" />
        <text x="120" y="124.2" textAnchor="middle">
          Alerte envoyée ✓
        </text>
      </g>
    </svg>
  );
}

const STEPS = [
  {
    n: "01",
    title: "Analyser",
    text: "Previa analyse en continu les images de vos caméras grâce à son intelligence artificielle.",
    icon: IconIntelligence,
    scene: <SceneAnalyse />,
  },
  {
    n: "02",
    title: "Comprendre",
    text: "Elle repère les comportements et les situations inhabituels.",
    icon: IconSurveillance,
    scene: <SceneComprendre />,
  },
  {
    n: "03",
    title: "Prévenir",
    text: "Vous recevez une alerte sur votre téléphone, et une lampe ou une sirène peut se déclencher.",
    icon: IconPhone,
    scene: <ScenePrevenir />,
  },
];

export default function HowItWorks() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.25 });
  const [stepLit, setStepLit] = useState(0); // cartes allumées : 0..3
  const [segOn, setSegOn] = useState(0); // fils parcourus : 0..2
  const [replay, setReplay] = useState([0, 0, 0]); // relance d'une scène au survol / toucher

  useEffect(() => {
    if (reduce || !inView) return;
    const timers = [
      setTimeout(() => setStepLit(1), 200),
      setTimeout(() => setSegOn(1), 1100),
      setTimeout(() => setStepLit(2), 1900),
      setTimeout(() => setSegOn(2), 2800),
      setTimeout(() => setStepLit(3), 3600),
    ];
    return () => {
      timers.forEach(clearTimeout);
      setStepLit(0);
      setSegOn(0);
    };
  }, [inView, reduce]);

  const lit = reduce ? 3 : stepLit;
  const seg = reduce ? 2 : segOn;
  const bump = (i: number) => setReplay((r) => r.map((v, j) => (j === i ? v + 1 : v)));

  return (
    <section className="section sol-how">
      <div className="container">
        <Reveal className="section-head">
          <span className="eyebrow sol-eyebrow">Comment ça marche ?</span>
          <h2 className="sol-h2">Analyser, comprendre, prévenir.</h2>
          <p className="lead">Trois temps, simplement et sans jargon.</p>
          <span className="section-rule" aria-hidden />
        </Reveal>

        <div className={`sol-fl ${lit === 3 ? "is-done" : ""}`} ref={ref}>
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            return (
              <FlowItem key={s.n} last={i === STEPS.length - 1} segOn={seg > i}>
                <article
                  className={`sol-fl-card ${lit > i ? "is-lit" : ""}`}
                  onPointerEnter={() => lit > i && bump(i)}
                >
                  <div className="sol-fl-scene" key={replay[i]}>
                    {s.scene}
                  </div>
                  <div className="sol-fl-head">
                    <span className="sol-fl-icon">
                      <Icon width={22} height={22} />
                    </span>
                    <span className="sol-fl-n">{s.n}</span>
                  </div>
                  <h3 className="sol-fl-title">{s.title}</h3>
                  <p className="sol-fl-text">{s.text}</p>
                </article>
              </FlowItem>
            );
          })}
        </div>

        <p className={`sol-fl-closing ${lit === 3 ? "is-on" : ""}`}>
          <IconCheck width={18} height={18} />
          Vous n&apos;avez plus à fixer vos écrans : Previa s&apos;en charge.
        </p>
      </div>
    </section>
  );
}

/** Une carte suivie (sauf la dernière) du fil qui la relie à la suivante. */
function FlowItem({ children, last, segOn }: { children: ReactNode; last: boolean; segOn: boolean }) {
  return (
    <>
      {children}
      {!last && (
        <div className={`sol-fl-seg ${segOn ? "is-on" : ""}`} aria-hidden>
          <span className="sol-fl-seg-line" />
          <span className="sol-fl-seg-fill" />
          <span className="sol-fl-seg-dot" />
        </div>
      )}
    </>
  );
}
