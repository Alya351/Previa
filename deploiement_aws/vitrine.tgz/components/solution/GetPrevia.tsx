"use client";

import { useEffect, useRef, useState } from "react";
import type { MouseEvent, ReactNode } from "react";
import Link from "next/link";
import Reveal from "@/components/home/Reveal";

/* Icônes duotone sur mesure : trait dégradé + aplat translucide. */
const S = {
  fill: "none",
  stroke: "url(#sgGrad)",
  strokeWidth: 1.7,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

const Camera = () => (
  <svg viewBox="0 0 24 24" width="30" height="30" {...S} aria-hidden>
    <rect x="2.5" y="6.5" width="13" height="11" rx="3.2" fill="currentColor" fillOpacity="0.14" />
    <path d="M15.5 10.4 20.4 7.6a.6.6 0 0 1 .9.5v7.8a.6.6 0 0 1-.9.5l-4.9-2.8z" />
    <circle cx="7.2" cy="10.2" r="0.9" fill="url(#sgGrad)" stroke="none" />
  </svg>
);

const Account = () => (
  <svg viewBox="0 0 24 24" width="30" height="30" {...S} aria-hidden>
    <circle cx="9.5" cy="8" r="3.6" fill="currentColor" fillOpacity="0.14" />
    <path d="M2.8 19.5c.4-3.4 3.2-5.6 6.7-5.6 1.2 0 2.2.2 3.1.7" />
    <rect x="13" y="13.2" width="8.5" height="6.3" rx="1.8" fill="currentColor" fillOpacity="0.14" />
    <path d="M13 15.9h8.5" />
  </svg>
);

const Key = () => (
  <svg viewBox="0 0 24 24" width="30" height="30" {...S} aria-hidden>
    <circle cx="8" cy="15.5" r="4.6" fill="currentColor" fillOpacity="0.14" />
    <circle cx="8" cy="15.5" r="1.3" />
    <path d="M11.4 12.1 20 3.5M16.6 6.9l2.4 2.4M14.2 9.3l1.8 1.8" />
  </svg>
);

const Shield = () => (
  <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M12 2.8 19.4 5.6v5.6c0 4.5-3 8.1-7.4 10-4.4-1.9-7.4-5.5-7.4-10V5.6z" fill="currentColor" fillOpacity="0.18" />
    <path d="m8.6 12.2 2.4 2.4 4.5-4.7" />
  </svg>
);

type Step = {
  n: string;
  title: string;
  text: string;
  icon: ReactNode;
  href: string | null;
  cta: string | null;
};

const STEPS: Step[] = [
  {
    n: "01",
    title: "Choisissez votre offre",
    text: "Avec ou sans caméras : sélectionnez la formule qui vous convient.",
    icon: <Camera />,
    href: "/offres",
    cta: "Voir les offres",
  },
  {
    n: "02",
    title: "Créez votre compte et payez",
    text: "Réglez la première des trois tranches, directement depuis votre espace.",
    icon: <Account />,
    href: "/connexion",
    cta: "Créer mon compte",
  },
  {
    n: "03",
    title: "Recevez votre code d'activation",
    text: "C'est la clé personnelle qui active Previa chez vous. Nous vous prévenons dès qu'il est prêt.",
    icon: <Key />,
    href: "/code-amorcage",
    cta: "Mon espace",
  },
  {
    n: "04",
    title: "Activer Previa",
    text: "Saisissez votre code dans l'application : la surveillance démarre.",
    icon: <Shield />,
    href: process.env.NEXT_PUBLIC_APP_URL || "/code-amorcage",
    cta: "Activer Previa",
  },
];

/** Halo qui suit le curseur sur la carte. */
function spotlight(e: MouseEvent<HTMLElement>) {
  const r = e.currentTarget.getBoundingClientRect();
  e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
  e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
}

const BEAM_MS = 450;

export default function GetPrevia() {
  // étape survolée + trajet du faisceau entre deux étapes
  const [active, setActive] = useState<number | null>(null);
  const [beam, setBeam] = useState<{ id: number; from: number; to: number } | null>(null);
  const prev = useRef<number | null>(null);
  const seq = useRef(0);

  const enter = (i: number) => {
    const p = prev.current;
    prev.current = i;
    setActive(i);
    setBeam(p !== null && p !== i ? { id: ++seq.current, from: p, to: i } : null);
  };
  const leave = () => setActive(null);
  const gridRef = useRef<HTMLOListElement>(null);

  // Tablette / mobile : pas de survol, c'est le défilement qui allume les étapes.
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 980px)");
    const cards = gridRef.current?.querySelectorAll<HTMLElement>("[data-step]");
    if (!mq.matches || !cards) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting) enter(Number((en.target as HTMLElement).dataset.step));
        }
      },
      { rootMargin: "-42% 0px -42% 0px" },
    );
    cards.forEach((c) => io.observe(c));
    return () => io.disconnect();
  }, []);

  const reset = () => {
    prev.current = null;
    setActive(null);
    setBeam(null);
  };

  return (
    <section className="section sol-get">
      {/* dégradé partagé par les icônes */}
      <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden focusable="false">
        <defs>
          <linearGradient id="sgGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#38bdf8" />
            <stop offset="1" stopColor="#0072c6" />
          </linearGradient>
        </defs>
      </svg>

      <div className="container">
        <Reveal className="section-head">
          <span className="eyebrow sol-eyebrow">Comment obtenir Previa ?</span>
          <h2 className="sol-h2">Quatre étapes, du choix à la surveillance.</h2>
          <p className="lead">Tout se fait en ligne, à votre rythme.</p>
          <span className="section-rule" aria-hidden />
        </Reveal>

        <ol ref={gridRef} className="sol-get-grid" onMouseLeave={reset}>
          {STEPS.map((s, i) => {
            const body = (
              <>
                <span className="sol-get-icon">{s.icon}</span>
                <h3 className="sol-get-title">{s.title}</h3>
                <p className="sol-get-text">{s.text}</p>
                {s.cta && (
                  <span className="sol-get-cta">
                    <span className="sol-get-btn">{s.cta}</span>
                  </span>
                )}
              </>
            );
            return (
              <li key={s.n} className="sol-get-item">
                <Reveal delay={0.1 * i} y={26}>
                  <div className="sol-get-rail" aria-hidden>
                    <span
                      className={`sol-get-node${active === i ? " is-on" : active !== null && i < active ? " is-done" : ""}`}
                      style={{
                        transitionDelay:
                          active === i && beam && beam.to === i
                            ? `${Math.abs(beam.to - beam.from) * BEAM_MS}ms`
                            : "0ms",
                      }}
                    >
                      {s.n}
                    </span>
                    {i < STEPS.length - 1 && (
                      <span className={`sol-get-line${active !== null && i < active ? " is-filled" : ""}`}>
                        {beam && i >= Math.min(beam.from, beam.to) && i < Math.max(beam.from, beam.to) && (
                          <span
                            key={beam.id}
                            className={`sol-get-beam ${beam.to > beam.from ? "fwd" : "rev"}`}
                            style={{
                              animationDelay: `${
                                (beam.to > beam.from ? i - beam.from : beam.from - 1 - i) * BEAM_MS
                              }ms`,
                              animationDuration: `${BEAM_MS}ms`,
                            }}
                          />
                        )}
                      </span>
                    )}
                  </div>
                  {s.href ? (
                    <Link
                      href={s.href}
                      className={`sol-get-card is-link${active === i ? " is-lit" : ""}`}
                      data-step={i}
                      onMouseMove={spotlight}
                      onMouseEnter={() => enter(i)}
                      onMouseLeave={leave}
                      onFocus={() => enter(i)}
                      onBlur={leave}
                    >
                      {body}
                    </Link>
                  ) : (
                    <div
                      className={`sol-get-card is-link is-static${active === i ? " is-lit" : ""}`}
                      data-step={i}
                      onMouseMove={spotlight}
                      onMouseEnter={() => enter(i)}
                      onMouseLeave={leave}
                    >
                      {body}
                    </div>
                  )}
                </Reveal>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
