"use client";

import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { motion, useInView, useMotionValue, useReducedMotion, useScroll, useTransform } from "motion/react";
import Reveal from "@/components/home/Reveal";

/**
 * « Ce que vous gagnez » — six cartes vivantes.
 *  A : cascade d'entrée, icônes qui se dessinent puis jouent une micro-animation
 *      (rejouée au survol / toucher).
 *  B : halo bleu qui suit le curseur (ou voyage seul sur écran tactile) ; un clic / toucher
 *      agrandit la carte, comme dans « Comment ça marche ».
 */

/* --- Icônes animées (viewBox 24, trait, pathLength=1 pour le tracé) --- */
const P = { pathLength: 1 } as const;

function IcBell() {
  return (
    <svg viewBox="0 0 24 24" className="sol-gain-svg" aria-hidden focusable="false">
      <g className="g-bell">
        <path {...P} d="M6 9a6 6 0 0 1 12 0c0 5 2 6.5 2 6.5H4S6 14 6 9z" />
        <path {...P} d="M10 19a2 2 0 0 0 4 0" />
      </g>
      <path {...P} className="g-wave" d="M3.5 9a9 9 0 0 1 2-3.5" />
      <path {...P} className="g-wave" d="M20.5 9a9 9 0 0 0-2-3.5" />
    </svg>
  );
}
function IcPhone() {
  return (
    <svg viewBox="0 0 24 24" className="sol-gain-svg" aria-hidden focusable="false">
      <g className="g-phone">
        <rect {...P} x="7" y="2.5" width="10" height="19" rx="2.5" />
        <path {...P} d="M11 18.5h2" />
      </g>
      <path {...P} className="g-wave" d="M3.5 9a6 6 0 0 0 0 6" />
      <path {...P} className="g-wave" d="M20.5 9a6 6 0 0 1 0 6" />
    </svg>
  );
}
function IcHistory() {
  return (
    <svg viewBox="0 0 24 24" className="sol-gain-svg" aria-hidden focusable="false">
      <path {...P} d="M3.6 9A9 9 0 1 1 3 12" />
      <path {...P} d="M3 4.5V9h4.5" />
      <g className="g-hand">
        <path {...P} d="M12 7.5V12l3 2" />
      </g>
    </svg>
  );
}
function IcSiren() {
  return (
    <svg viewBox="0 0 24 24" className="sol-gain-svg" aria-hidden focusable="false">
      <circle className="g-glow" cx="12" cy="13" r="5" />
      <path {...P} d="M7 18v-5a5 5 0 0 1 10 0v5" />
      <path {...P} d="M5 21h14M5 18h14" />
      <path {...P} className="g-rays" d="M12 3v2M4.2 6.2l1.4 1.4M19.8 6.2l-1.4 1.4M2 13h2M20 13h2" />
    </svg>
  );
}
function IcCamera() {
  return (
    <svg viewBox="0 0 24 24" className="sol-gain-svg" aria-hidden focusable="false">
      <g className="g-cam">
        <path {...P} d="M4 8.5h9a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2z" />
        <path {...P} d="M15 12l4-2.4v6.8L15 14" />
        <circle {...P} className="g-lens" cx="8.5" cy="13" r="2" />
      </g>
      <g className="g-ok">
        <circle cx="19" cy="5" r="3.6" />
        <path d="M17.3 5l1.3 1.3 2.2-2.4" />
      </g>
    </svg>
  );
}
function IcShield() {
  return (
    <svg viewBox="0 0 24 24" className="sol-gain-svg" aria-hidden focusable="false">
      <path {...P} d="M12 3l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10V6z" />
      <path {...P} className="g-check" d="M8.8 12.2l2.2 2.2 4.2-4.4" />
    </svg>
  );
}

const GAINS: { title: string; text: string; icon: ReactNode }[] = [
  {
    title: "Alertes en temps réel",
    text: "Soyez prévenu dès qu'une situation inhabituelle est détectée.",
    icon: <IcBell />,
  },
  {
    title: "Surveillance à distance",
    text: "Suivez la situation depuis votre téléphone ou sur le web, où que vous soyez.",
    icon: <IcPhone />,
  },
  {
    title: "Historique des événements",
    text: "Retrouvez à tout moment ce que Previa a détecté.",
    icon: <IcHistory />,
  },
  {
    title: "Lampe ou sirène automatiques",
    text: "Selon la configuration, Previa déclenche une lampe ou une sirène pour dissuader.",
    icon: <IcSiren />,
  },
  {
    title: "Vos caméras, ou les nôtres",
    text: "Previa s'installe sur vos caméras existantes. Vous n'en avez pas ? Nous les installons pour vous.",
    icon: <IcCamera />,
  },
  {
    title: "Simple à utiliser",
    text: "Aucune compétence technique nécessaire : tout est guidé, de l'activation aux alertes.",
    icon: <IcShield />,
  },
];

/** Intervalle entre deux cartes : elles arrivent une à une, dans l'ordre. */
const STEP_MS = 440;

export default function Features() {
  const reduce = useReducedMotion();
  const gridRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLElement | null)[]>([]);
  const gridInView = useInView(gridRef, { amount: 0.15 });
  const [seen, setSeen] = useState<boolean[]>(() => GAINS.map(() => false));
  const [replay, setReplay] = useState<number[]>(() => GAINS.map(() => 0));
  const [popped, setPopped] = useState<number | null>(null);
  const popTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  /* Défilement horizontal : épinglé sur ordinateur, balayage tactile ailleurs. */
  const pinRef = useRef<HTMLDivElement>(null);
  const [hscroll, setHscroll] = useState(false);
  const [dist, setDist] = useState(0);
  const barProg = useMotionValue(0);
  const { scrollYProgress } = useScroll({ target: pinRef, offset: ["start start", "end end"] });
  const distMv = useMotionValue(0);
  const x = useTransform([scrollYProgress, distMv], ([v, d]: number[]) => -v * d);

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const sync = () => setHscroll(mq.matches && !reduce);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, [reduce]);

  useEffect(() => {
    if (!hscroll) return;
    const grid = gridRef.current;
    if (!grid) return;
    const measure = () => {
      const d = Math.max(0, grid.scrollWidth - window.innerWidth);
      distMv.set(d);
      setDist(d);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(grid);
    window.addEventListener("resize", measure);
    const off = scrollYProgress.on("change", (v) => barProg.set(v));
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
      off();
    };
  }, [hscroll, scrollYProgress, barProg, distMv]);

  const onSwipe = (e: React.UIEvent<HTMLDivElement>) => {
    if (hscroll) return;
    const el = e.currentTarget;
    const max = el.scrollWidth - el.clientWidth;
    barProg.set(max > 0 ? el.scrollLeft / max : 0);
  };

  /* File d'attente : une carte n'arrive que STEP_MS après la précédente (dans l'ordre d'apparition à l'écran). */
  const nextSlot = useRef(0);
  const queued = useRef<boolean[]>(GAINS.map(() => false));
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  useEffect(() => {
    const list = timers.current;
    return () => list.forEach(clearTimeout);
  }, []);
  const enqueue = (i: number, now: number) => {
    if (queued.current[i]) return;
    queued.current[i] = true;
    const start = Math.max(now, nextSlot.current);
    nextSlot.current = start + STEP_MS;
    timers.current.push(
      setTimeout(() => setSeen((st) => (st[i] ? st : st.map((v, j) => (j === i ? true : v)))), start - now),
    );
  };

  /* Halo : suit le curseur (souris) ou voyage seul (écran tactile). */
  useEffect(() => {
    const grid = gridRef.current;
    if (!grid || reduce) return;
    const cards = () => cardRefs.current.filter(Boolean) as HTMLElement[];
    const aim = (clientX: number, clientY: number) => {
      cards().forEach((c) => {
        const r = c.getBoundingClientRect();
        c.style.setProperty("--mx", `${clientX - r.left}px`);
        c.style.setProperty("--my", `${clientY - r.top}px`);
        c.style.setProperty("--glow", "1");
      });
    };
    const off = () => cards().forEach((c) => c.style.setProperty("--glow", "0"));

    const fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    if (fine) {
      const move = (e: PointerEvent) => aim(e.clientX, e.clientY);
      grid.addEventListener("pointermove", move);
      grid.addEventListener("pointerleave", off);
      return () => {
        grid.removeEventListener("pointermove", move);
        grid.removeEventListener("pointerleave", off);
        off();
      };
    }

    if (!gridInView) return;
    let raf = 0;
    let last = 0;
    const loop = (t: number) => {
      if (t - last > 33) {
        last = t;
        const r = grid.getBoundingClientRect();
        const x = r.left + r.width * (0.5 + 0.42 * Math.sin(t * 0.00042));
        const y = r.top + r.height * (0.5 + 0.42 * Math.sin(t * 0.00031 + 1.2));
        aim(x, y);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      off();
    };
  }, [reduce, gridInView]);

  const bump = (i: number) => setReplay((r) => r.map((v, j) => (j === i ? v + 1 : v)));
  const pop = (i: number) => {
    setPopped(i);
    if (popTimer.current) clearTimeout(popTimer.current);
    popTimer.current = setTimeout(() => setPopped(null), 2200);
  };

  const headEl = (
    <Reveal className="section-head">
          <span className="eyebrow sol-eyebrow">Ce que vous gagnez</span>
          <h2 className="sol-h2">Une surveillance qui travaille pour vous.</h2>
          <p className="lead">Moins de stress, plus de réactivité, sans rien de compliqué.</p>
          <span className="section-rule" aria-hidden />
    </Reveal>
  );
  const gridEl = (
        <motion.div className="sol-gains-grid" ref={gridRef} style={hscroll ? { x } : undefined} onScroll={onSwipe}>
          {GAINS.map((g, i) => (
            <motion.div
              key={g.title}
              style={{ transformPerspective: 900 }}
              initial={reduce ? false : { opacity: 0, y: 46, scale: 0.93, rotateX: 14, filter: "blur(10px)" }}
              animate={
                seen[i] || reduce
                  ? { opacity: 1, y: 0, scale: 1, rotateX: 0, filter: "blur(0px)" }
                  : { opacity: 0, y: 46, scale: 0.93, rotateX: 14, filter: "blur(10px)" }
              }
              viewport={{ once: true, amount: 0.3 }}
              transition={{
                default: { type: "spring", stiffness: 115, damping: 15 },
                opacity: { duration: 0.6 },
                filter: { duration: 0.7 },
              }}
              onViewportEnter={(entry) => enqueue(i, entry?.time ?? 0)}
            >
              <article
                ref={(el) => {
                  cardRefs.current[i] = el;
                }}
                className={`sol-gain ${seen[i] || reduce ? "is-in" : ""} ${popped === i ? "is-pop" : ""}`}
                style={{ "--base": replay[i] ? "0s" : "0.1s" } as CSSProperties}
                onPointerEnter={() => seen[i] && bump(i)}
                onClick={() => pop(i)}
              >
                <span className="sol-gain-icon" key={replay[i]}>
                  {g.icon}
                </span>
                <h3 className="sol-gain-title">{g.title}</h3>
                <p className="sol-gain-text">{g.text}</p>
              </article>
            </motion.div>
          ))}
        </motion.div>
  );
  const barEl = (
    <div className="sol-gains-bar" aria-hidden>
      <motion.span style={{ scaleX: barProg }} />
    </div>
  );
  const hintEl = <p className="sol-gains-hint">Faites glisser pour voir la suite</p>;

  /* Structure identique dans les deux modes : la cible du scroll existe dès le premier rendu. */
  return (
    <section className={`section sol-features ${hscroll ? "is-hscroll" : ""}`}>
      <div className="sol-gains-pin" ref={pinRef} style={hscroll ? { height: `calc(100vh + ${dist}px)` } : undefined}>
        <div className="sol-gains-sticky">
          <div className="container">{headEl}</div>
          <div className="container sol-gains-wrap">
            {gridEl}
            {barEl}
            {hintEl}
          </div>
        </div>
      </div>
    </section>
  );
}
