"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView, useReducedMotion } from "motion/react";

/**
 * « LA RÉPONSE PREVIA » — signature motion du logo, en deux actes.
 *
 *  Acte 1 : le mot PREVIA se dessine de gauche à droite (révélation par masque,
 *           une seule courbe douce — pas de saccades).
 *  Pause  : ~0,4 s, le mot reste immobile.
 *  Acte 2 : le suricate apparaît à droite, glisse en courbe vers le « a » et
 *           s'y intègre. Il ne paraît jamais avant la fin du dessin du mot.
 *  Fin    : micro-stabilisation 99 % → 100 %, puis plus aucun mouvement.
 *
 * L'animation se REJOUE à chaque fois que la section revient à l'écran après
 * l'avoir quittée (scroll haut ou bas) : `useInView` sans `once` incrémente une
 * clé qui remonte le sous-arbre et relance la séquence depuis le début.
 *
 * Le logo fourni n'est jamais redessiné : deux copies identiques se superposent
 * (le mot / la zone suricate), on n'anime que clip-path, position et opacité.
 */

const T_WRITE_START = 0.15;
const T_WRITE_DUR = 1.7;
const T_PAUSE = 0.4;
const T_MEER_START = T_WRITE_START + T_WRITE_DUR + T_PAUSE; // ≈ 2.25 s
const T_MEER_DUR = 1.15;

function LogoImgs() {
  return (
    <>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img className="slr-logo slr-logo--light" src="/logo-previa.png" alt="Previa" draggable={false} />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        className="slr-logo slr-logo--dark"
        src="/logo-previa-dark.png"
        alt=""
        aria-hidden
        draggable={false}
      />
    </>
  );
}

export default function ResponsePrevia() {
  const reduce = useReducedMotion();
  const stageRef = useRef<HTMLDivElement>(null);
  const inView = useInView(stageRef, { amount: 0.3 });

  // Chaque entrée dans le viewport relance l'animation (clé de remontage).
  const [runs, setRuns] = useState(0);
  useEffect(() => {
    if (inView) setRuns((r) => r + 1);
  }, [inView]);

  return (
    <section className="section sol-response">
      <div className="container">
        <div className="sol-response-head">
          <div className="sol-logo-reveal">
            <span className="sol-logo-halo" aria-hidden />

            <div className="slr-stage" ref={stageRef}>
              <motion.div
                key={runs}
                className="slr-canvas"
                initial={reduce ? false : { scale: 0.992 }}
                animate={{ scale: 1 }}
                transition={
                  reduce
                    ? { duration: 0 }
                    : { delay: T_MEER_START + 0.85, duration: 0.9, ease: [0.33, 0, 0.2, 1] }
                }
              >
                {/* Acte 1 — le mot se dessine (révélé jusqu'au « a », suricate exclu) */}
                <motion.div
                  className="slr-word"
                  initial={reduce ? false : { clipPath: "inset(0% 100% 0% 0%)" }}
                  animate={{ clipPath: reduce ? "inset(0% 0% 0% 0%)" : "inset(0% 26% 0% 0%)" }}
                  transition={
                    reduce
                      ? { duration: 0 }
                      : { delay: T_WRITE_START, duration: T_WRITE_DUR, ease: [0.45, 0, 0.12, 1] }
                  }
                >
                  <LogoImgs />
                </motion.div>

                {/* Acte 2 — le suricate arrive par la droite et s'intègre au « a » */}
                <motion.div
                  className="slr-meer"
                  initial={reduce ? false : { opacity: 0, x: 62, y: -9 }}
                  animate={{ opacity: 1, x: 0, y: 0 }}
                  transition={
                    reduce
                      ? { duration: 0 }
                      : {
                          opacity: { delay: T_MEER_START, duration: 0.45, ease: "easeOut" },
                          x: { delay: T_MEER_START, duration: T_MEER_DUR, ease: [0.33, 0, 0.15, 1] },
                          y: { delay: T_MEER_START, duration: T_MEER_DUR, ease: [0.6, 0, 0.25, 1] },
                        }
                  }
                >
                  <LogoImgs />
                </motion.div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
