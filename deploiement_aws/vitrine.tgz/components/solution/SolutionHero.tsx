"use client";

import { useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import VideoModal from "@/components/home/VideoModal";
import { SceneImage } from "@/components/home/scenes";
import { IconPlay } from "@/components/home/icons";

/**
 * Lien de la vraie vidéo de démonstration Previa.
 * Laisser vide pour afficher l'aperçu animé + modale « à venir ».
 * Renseigner ultérieurement (fichier /public ou URL) sans toucher au reste.
 */
const DEMO_VIDEO_SRC = "/video-solution.mp4";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function SolutionHero() {
  const reduce = useReducedMotion();
  const [open, setOpen] = useState(false);

  return (
    <section className="sol-hero" id="solution">
      <div className="container">
        <div className="sol-hero-layout">
          <motion.div
            className="sol-hero-frame"
            initial={{ opacity: 0, scale: reduce ? 1 : 0.955, y: reduce ? 0 : 22 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.15, ease: EASE }}
          >
            <div className="sol-hero-stage">
              {DEMO_VIDEO_SRC ? (
                <video
                  className="sol-hero-video"
                  src={DEMO_VIDEO_SRC}
                  muted
                  autoPlay
                  loop
                  playsInline
                  preload="auto"
                  ref={(el) => {
                    if (el) {
                      el.muted = true;
                      el.play().catch(() => {});
                    }
                  }}
                />
              ) : (
                <SceneImage env="entreprise" alt="" className="sol-hero-img" />
              )}

              <div className="sol-hero-veil" />

              {!reduce && (
                <>
                  <motion.span
                    className="sol-hero-scan"
                    initial={{ y: "-100%" }}
                    animate={{ y: "100%" }}
                    transition={{ duration: 4.2, ease: "easeInOut", repeat: Infinity, repeatType: "reverse" }}
                  />
                  <motion.span
                    className="sol-hero-box"
                    animate={{ opacity: [0, 1, 1, 0], scale: [0.94, 1, 1, 0.98] }}
                    transition={{ duration: 5, times: [0, 0.15, 0.82, 1], repeat: Infinity, repeatDelay: 1.4 }}
                  />
                </>
              )}

              <div className="sol-hero-hud">
                <span className="sol-hero-live">
                  <i /> LIVE
                </span>
                <span className="sol-hero-hud-label">Analyse comportementale</span>
              </div>

              <motion.button
                type="button"
                className="sol-hero-play"
                onClick={() => setOpen(true)}
                aria-label="Voir la démonstration Previa"
                initial={{ opacity: 0, scale: reduce ? 1 : 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: reduce ? 0 : 0.8, ease: EASE }}
                whileHover={reduce ? undefined : { scale: 1.07 }}
                whileTap={reduce ? undefined : { scale: 0.95 }}
              >
                <span className="sol-hero-play-ring" aria-hidden />
                <IconPlay width={22} height={22} />
              </motion.button>
            </div>
          </motion.div>

          <div className="sol-hero-copy">
            <motion.span
              className="eyebrow sol-hero-eyebrow"
              initial={{ opacity: 0, y: reduce ? 0 : 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: reduce ? 0 : 0.3 }}
            >
              La solution Previa
            </motion.span>

            <motion.h1
              className="sol-hero-title"
              initial={{ opacity: 0, y: reduce ? 0 : 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: reduce ? 0 : 0.45, ease: EASE }}
            >
              La vidéosurveillance qui comprend ce qu&apos;elle observe.
            </motion.h1>
          </div>
        </div>
      </div>

      <VideoModal open={open} onClose={() => setOpen(false)} src={DEMO_VIDEO_SRC || undefined} />
    </section>
  );
}
