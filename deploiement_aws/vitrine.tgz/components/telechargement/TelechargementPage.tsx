"use client";

import Navbar from "@/components/home/Navbar";
import Footer from "@/components/home/Footer";
import DownloadHero from "./DownloadHero";
import DownloadSteps from "./DownloadSteps";
import DownloadDevices from "./DownloadDevices";

export default function TelechargementPage() {
  return (
    <>
      <Navbar />
      <main>
        <DownloadHero />
        <DownloadSteps />
        <DownloadDevices />
      </main>
      <Footer />
    </>
  );
}
