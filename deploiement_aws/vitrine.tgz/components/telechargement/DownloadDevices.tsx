"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import Reveal from "@/components/home/Reveal";
import { startDownload, type DownloadPlatform } from "@/lib/download";
import {
  IconMonitor,
  IconWindows,
  IconApple,
  IconAndroid,
  IconDownload,
  IconCheck,
} from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

const DEVICES = [
  { key: "web", name: "Application web", icon: IconMonitor },
  { key: "windows", name: "Windows", icon: IconWindows },
  { key: "android", name: "Android", icon: IconAndroid },
  { key: "ios", name: "iOS", icon: IconApple },
] as const;

function DeviceCard({
  name,
  platform,
  Icon,
  index,
}: {
  name: string;
  platform: DownloadPlatform;
  Icon: (p: { width?: number; height?: number }) => React.ReactElement;
  index: number;
}) {
  const reduce = useReducedMotion();
  const [confirmed, setConfirmed] = useState(false);
  const [soon, setSoon] = useState(false);

  const handleClick = () => {
    if (confirmed || soon) return;
    // Lance le vrai téléchargement ; sans fichier pour cet appareil : « Bientôt disponible ».
    if (startDownload(platform)) {
      setConfirmed(true);
      window.setTimeout(() => setConfirmed(false), 1400);
    } else {
      setSoon(true);
      window.setTimeout(() => setSoon(false), 2200);
    }
  };

  return (
    <Reveal
      delay={index * 0.12}
      y={18}
      className="tc-device-card"
    >
      <span className="tc-device-icon">
        <Icon width={30} height={30} />
      </span>
      <h3 className="tc-device-name">{name}</h3>

      <motion.button
        type="button"
        className="btn btn-primary tc-device-btn"
        onClick={handleClick}
        whileHover={reduce ? undefined : { scale: 1.02 }}
        whileTap={reduce ? undefined : { scale: 0.97 }}
      >
        <span>{soon ? "Bientôt disponible" : platform === "web" ? "Ouvrir l'application" : "Télécharger"}</span>
        <span className="tc-device-btn-icon">
          <AnimatePresence mode="wait" initial={false}>
            {confirmed ? (
              <motion.span
                key="check"
                initial={{ opacity: 0, scale: 0.6 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.6 }}
                transition={{ duration: 0.25, ease: EASE }}
              >
                <IconCheck width={18} height={18} />
              </motion.span>
            ) : (
              <motion.span
                key="download"
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 4 }}
                transition={{ duration: 0.25, ease: EASE }}
              >
                <IconDownload width={18} height={18} />
              </motion.span>
            )}
          </AnimatePresence>
        </span>
      </motion.button>
    </Reveal>
  );
}

export default function DownloadDevices() {
  return (
    <section className="section tc-devices">
      <div className="container">
        <Reveal className="section-head">
          <span className="eyebrow sol-eyebrow">Vos appareils</span>
          <h2 className="sol-h2">DISPONIBLE SUR VOS APPAREILS</h2>
          <span className="section-rule" aria-hidden />
        </Reveal>

        <div className="tc-devices-grid">
          {DEVICES.map((d, i) => (
            <DeviceCard key={d.key} name={d.name} platform={d.key} Icon={d.icon} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
