"use client";

import { useEffect, useRef } from "react";
import { motion, useReducedMotion } from "motion/react";
import Reveal from "@/components/home/Reveal";
import {
  IconDownload,
  IconPackage,
  IconShieldCheck,
  IconSurveillance,
} from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

const STEPS = [
  {
    key: "download",
    n: "01",
    title: "Télécharger",
    text: "Récupérez Previa depuis la plateforme adaptée à votre appareil.",
    icon: IconDownload,
  },
  {
    key: "install",
    n: "02",
    title: "Installer",
    text: "Suivez les quelques étapes guidées pour installer l'application.",
    icon: IconPackage,
  },
  {
    key: "activate",
    n: "03",
    title: "Activer",
    text: "Activez votre espace Previa avec votre code d'activation.",
    icon: IconShieldCheck,
  },
  {
    key: "watch",
    n: "04",
    title: "Surveiller",
    text: "Suivez vos environnements en direct, où que vous soyez.",
    icon: IconSurveillance,
  },
] as const;

const CARD_ANGLE = 360 / STEPS.length; // 90°
const RADIUS_FACTOR = 0.92; // rayon du cylindre relatif à la largeur d'une carte
// Négatif : fait défiler les cartes dans l'ordre 01 → 02 → 03 → 04, de gauche à droite.
const BASE_SPEED = -360 / 24; // °/s — un tour complet toutes les ~24s
const VELOCITY_EASE = 2.4; // vitesse d'approche vers la vitesse cible
const DRAG_SENSITIVITY = 0.34; // ° par pixel glissé
const MAX_FLING_SPEED = 220; // °/s, plafond après un lâcher rapide
const IDLE_RESUME_DELAY = 2200; // ms avant reprise auto après une interaction manuelle
const FRONT_THRESHOLD = 0.82; // cos(angle) au-delà duquel une carte est "active"

function normalizeAngle(deg: number) {
  let a = deg % 360;
  if (a < 0) a += 360;
  return a;
}

export default function DownloadSteps() {
  const reduce = useReducedMotion();

  const stageRef = useRef<HTMLDivElement>(null);
  const cylinderRef = useRef<HTMLDivElement>(null);
  const slotRefs = useRef<(HTMLDivElement | null)[]>([]);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  // État d'animation conservé hors React (refs) pour rester à 60 FPS.
  const angleRef = useRef(0);
  const velocityRef = useRef(0);
  const targetVelocityRef = useRef(0);
  const startedRef = useRef(false);
  const hoveredRef = useRef<Set<number>>(new Set());
  const draggingRef = useRef(false);
  const dragStartXRef = useRef(0);
  const dragStartAngleRef = useRef(0);
  const lastMoveXRef = useRef(0);
  const lastMoveTRef = useRef(0);
  const dragVelocityRef = useRef(0);
  const resumeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeIndexRef = useRef(-1);

  const clearResumeTimer = () => {
    if (resumeTimerRef.current) {
      clearTimeout(resumeTimerRef.current);
      resumeTimerRef.current = null;
    }
  };

  const scheduleResume = () => {
    clearResumeTimer();
    resumeTimerRef.current = setTimeout(() => {
      if (hoveredRef.current.size === 0 && !draggingRef.current) {
        targetVelocityRef.current = BASE_SPEED;
      }
    }, IDLE_RESUME_DELAY);
  };

  useEffect(() => clearResumeTimer, []);

  // Positionne les 4 cartes sur le cylindre invisible (rayon dépendant de la largeur mesurée).
  useEffect(() => {
    const cylinder = cylinderRef.current;
    if (!cylinder) return;

    const applyRadius = () => {
      const width = cylinder.getBoundingClientRect().width;
      const radius = width * RADIUS_FACTOR;
      slotRefs.current.forEach((slot, i) => {
        if (!slot) return;
        slot.style.transform = `rotateY(${i * CARD_ANGLE}deg) translateZ(${radius}px)`;
      });
    };

    applyRadius();
    const ro = new ResizeObserver(applyRadius);
    ro.observe(cylinder);
    return () => ro.disconnect();
  }, []);

  // Boucle de rotation + calcul de profondeur (scale/opacité) par carte, image par image.
  useEffect(() => {
    if (reduce) return;

    let raf = 0;
    let last = performance.now();

    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      if (!draggingRef.current) {
        const ease = 1 - Math.exp(-VELOCITY_EASE * dt);
        velocityRef.current += (targetVelocityRef.current - velocityRef.current) * ease;
        angleRef.current = normalizeAngle(angleRef.current + velocityRef.current * dt);
      }

      const cylinder = cylinderRef.current;
      if (cylinder) {
        cylinder.style.transform = `rotateY(${angleRef.current}deg)`;
      }

      let bestFacing = -Infinity;
      let bestIndex = 0;
      cardRefs.current.forEach((card, i) => {
        if (!card) return;
        const worldAngle = normalizeAngle(i * CARD_ANGLE + angleRef.current);
        const rad = (worldAngle * Math.PI) / 180;
        const facing = Math.cos(rad); // 1 = face à l'utilisateur, -1 = de dos
        if (facing > bestFacing) {
          bestFacing = facing;
          bestIndex = i;
        }
        const t = (facing + 1) / 2; // 0..1
        const scale = 0.82 + 0.18 * t;
        const opacity = 0.32 + 0.68 * t;
        card.style.opacity = String(opacity);
        card.style.transform = `scale(${scale})`;
      });

      if (bestFacing >= FRONT_THRESHOLD && bestIndex !== activeIndexRef.current) {
        const prev = cardRefs.current[activeIndexRef.current];
        if (prev) prev.classList.remove("is-active");
        const next = cardRefs.current[bestIndex];
        if (next) {
          next.classList.add("is-active");
          next.style.transform = `scale(${0.82 + 0.18 * 1.04})`;
        }
        activeIndexRef.current = bestIndex;
      } else if (bestFacing < FRONT_THRESHOLD && activeIndexRef.current !== -1) {
        const prev = cardRefs.current[activeIndexRef.current];
        if (prev) prev.classList.remove("is-active");
        activeIndexRef.current = -1;
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reduce]);

  const pauseForHover = (i: number) => {
    hoveredRef.current.add(i);
    clearResumeTimer();
    targetVelocityRef.current = 0;
  };
  const resumeFromHover = (i: number) => {
    hoveredRef.current.delete(i);
    if (hoveredRef.current.size === 0 && !draggingRef.current) {
      targetVelocityRef.current = BASE_SPEED;
    }
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if (reduce) return;
    draggingRef.current = true;
    dragStartXRef.current = e.clientX;
    dragStartAngleRef.current = angleRef.current;
    lastMoveXRef.current = e.clientX;
    lastMoveTRef.current = performance.now();
    dragVelocityRef.current = 0;
    targetVelocityRef.current = 0;
    velocityRef.current = 0;
    clearResumeTimer();
    // Capturer sur la scène (pas sur la carte) : sinon le pointeur reste
    // "épinglé" à la carte cliquée pendant tout le glisser, ce qui fausse
    // le survol réel et peut bloquer la reprise après un drag.
    stageRef.current?.setPointerCapture?.(e.pointerId);
    stageRef.current?.classList.add("is-dragging");
    hoveredRef.current.clear();
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!draggingRef.current) return;
    const now = performance.now();
    const dtMs = Math.max(1, now - lastMoveTRef.current);
    const deltaX = e.clientX - dragStartXRef.current;
    angleRef.current = normalizeAngle(dragStartAngleRef.current - deltaX * DRAG_SENSITIVITY);

    const instVelocity =
      ((e.clientX - lastMoveXRef.current) * DRAG_SENSITIVITY * 1000) / dtMs;
    dragVelocityRef.current += (-instVelocity - dragVelocityRef.current) * 0.4;

    lastMoveXRef.current = e.clientX;
    lastMoveTRef.current = now;
  };

  const endDrag = () => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    stageRef.current?.classList.remove("is-dragging");
    hoveredRef.current.clear();
    const fling = Math.max(-MAX_FLING_SPEED, Math.min(MAX_FLING_SPEED, dragVelocityRef.current));
    velocityRef.current = fling;
    targetVelocityRef.current = 0;
    scheduleResume();
  };

  /** Filet de sécurité : si le pointeur quitte toute la scène, on ne doit
   * jamais rester bloqué en pause même si un couple enter/leave par carte
   * s'est désynchronisé (mouvement rapide entre cartes en 3D). */
  const onStageLeave = () => {
    const wasDragging = draggingRef.current;
    hoveredRef.current.clear();
    if (wasDragging) {
      endDrag(); // gère l'inertie puis la reprise différée
    } else {
      targetVelocityRef.current = BASE_SPEED;
    }
  };

  return (
    <section className="tc-steps">
      <div className="container tc-steps-head">
        <Reveal>
          <span className="eyebrow sol-eyebrow">Parcours Previa</span>
          <h2 className="sol-h2">COMMENCEZ EN QUELQUES ÉTAPES</h2>
        </Reveal>
      </div>

      {reduce ? (
        <div className="tc-steps-viewport">
          <div className="tc-steps-track--static">
            {STEPS.map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.key} className="tc-step" data-step={s.key}>
                  <span className="tc-step-n">{s.n}</span>
                  <span className="tc-step-icon">
                    <Icon width={26} height={26} />
                  </span>
                  <h3 className="tc-step-title">{s.title}</h3>
                  <p className="tc-step-text">{s.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <motion.div
          className="tc-cyl-stage"
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.8, ease: EASE, delay: 0.12 }}
          onViewportEnter={() => {
            if (startedRef.current) return;
            startedRef.current = true;
            window.setTimeout(() => {
              if (hoveredRef.current.size === 0 && !draggingRef.current) {
                targetVelocityRef.current = BASE_SPEED;
              }
            }, 250);
          }}
        >
          <div
            ref={stageRef}
            className="tc-cyl-perspective"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={endDrag}
            onPointerLeave={onStageLeave}
            onPointerCancel={onStageLeave}
          >
            <div ref={cylinderRef} className="tc-cylinder">
              {STEPS.map((s, i) => {
                const Icon = s.icon;
                return (
                  <div
                    key={s.key}
                    ref={(el) => {
                      slotRefs.current[i] = el;
                    }}
                    className="tc-cyl-slot"
                  >
                    <div
                      ref={(el) => {
                        cardRefs.current[i] = el;
                      }}
                      className="tc-step tc-cyl-card"
                      data-step={s.key}
                      onPointerEnter={() => pauseForHover(i)}
                      onPointerLeave={() => resumeFromHover(i)}
                    >
                      <span className="tc-step-n">{s.n}</span>
                      <span className="tc-step-icon">
                        <Icon width={26} height={26} />
                      </span>
                      <h3 className="tc-step-title">{s.title}</h3>
                      <p className="tc-step-text">{s.text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}
    </section>
  );
}
