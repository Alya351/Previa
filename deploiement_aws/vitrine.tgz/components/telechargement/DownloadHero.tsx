"use client";

import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";

const EASE = [0.22, 1, 0.36, 1] as const;

/**
 * Hero « image seule » : aucun texte, aucun bouton.
 * Zoom arrière très fluide à l'entrée + parallaxe subtil au scroll.
 */
export default function DownloadHero() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 22]);

  return (
    <section className="tc-hero" ref={ref}>
      <div className="container">
        <motion.div
          className="tc-hero-frame"
          initial={{ opacity: 0, scale: reduce ? 1 : 1.04 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.3, ease: EASE }}
          style={reduce ? undefined : { y }}
        >
          <img
            src="/scenes/page%20telechargement.jpg"
            alt="Plateforme et application Previa prêtes à être installées"
            className="tc-hero-img"
            draggable={false}
          />
        </motion.div>
      </div>
    </section>
  );
}
