"use client";

import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "motion/react";
import { IconPlus } from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

const QUESTIONS = [
  {
    q: "Qu'est-ce que Previa ?",
    a: "Previa est une solution de vidéosurveillance intelligente qui utilise l'analyse comportementale vidéo et l'intelligence artificielle pour détecter les situations inhabituelles ou à risque en temps réel.",
  },
  {
    q: "Comment fonctionne l'analyse comportementale de Previa ?",
    a: "Les caméras capturent les images, notre intelligence artificielle analyse les comportements en continu et identifie les situations inhabituelles pour permettre une réaction rapide des utilisateurs.",
  },
  {
    q: "Previa est-elle compatible avec les caméras existantes ?",
    a: "Oui, Previa a été conçue pour s'intégrer facilement à la plupart des infrastructures de vidéosurveillance déjà en place, sans nécessiter de remplacement matériel complet.",
  },
  {
    q: "Où sont traitées les données vidéo ?",
    a: "Les données vidéo sont traitées de façon sécurisée, avec des standards stricts de confidentialité et de protection des informations sensibles.",
  },
  {
    q: "Comment demander une démonstration ?",
    a: "Il vous suffit de remplir le formulaire de contact ci-dessus en précisant « Demande de démonstration » dans votre message, et notre équipe reviendra rapidement vers vous.",
  },
  {
    q: "Comment contacter l'équipe Previa ?",
    a: "Vous pouvez nous écrire à amanefantak@gmail.com, utiliser le formulaire de cette page, ou consulter les coordonnées de l'équipe listées ci-dessus.",
  },
] as const;

export default function Faq() {
  const reduce = useReducedMotion();
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" className="section ct-faq">
      <div className="container">
        <div className="section-head">
          <motion.span
            className="eyebrow"
            initial={{ opacity: 0, y: reduce ? 0 : 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6 }}
          >
            FAQ
          </motion.span>
          <motion.h2
            className="h2"
            initial={{ opacity: 0, y: reduce ? 0 : 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.7, delay: reduce ? 0 : 0.08, ease: EASE }}
          >
            Questions fréquentes
          </motion.h2>
          <motion.p
            className="lead"
            initial={{ opacity: 0, y: reduce ? 0 : 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6, delay: reduce ? 0 : 0.16, ease: EASE }}
          >
            Les réponses aux questions que vous vous posez sur Previa.
          </motion.p>
        </div>

        <div className="ct-faq-list">
          {QUESTIONS.map((item, i) => {
            const isOpen = open === i;
            const panelId = `faq-panel-${i}`;
            return (
              <motion.div
                className={`ct-faq-item${isOpen ? " is-open" : ""}`}
                key={item.q}
                initial={{ opacity: 0, y: reduce ? 0 : 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6, delay: reduce ? 0 : i * 0.06, ease: EASE }}
              >
                <button
                  type="button"
                  className="ct-faq-question"
                  aria-expanded={isOpen}
                  aria-controls={panelId}
                  onClick={() => setOpen(isOpen ? null : i)}
                >
                  <span className="ct-faq-num">{String(i + 1).padStart(2, "0")}</span>
                  <span className="ct-faq-text">{item.q}</span>
                  <span className={`ct-faq-icon${isOpen ? " is-open" : ""}`} aria-hidden>
                    <IconPlus width={16} height={16} />
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={panelId}
                      role="region"
                      className="ct-faq-answer-wrap"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: reduce ? 0 : 0.4, ease: EASE }}
                    >
                      <motion.p
                        className="ct-faq-answer"
                        initial={{ y: reduce ? 0 : -8 }}
                        animate={{ y: 0 }}
                        transition={{ duration: reduce ? 0 : 0.4, ease: EASE }}
                      >
                        {item.a}
                      </motion.p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        <motion.p
          className="ct-faq-more"
          initial={{ opacity: 0, y: reduce ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.8 }}
          transition={{ duration: 0.6, ease: EASE }}
        >
          <span>Vous ne trouvez pas votre réponse ?</span>
          <a href="#contact" className="ct-faq-cta">
            Nous écrire
          </a>
        </motion.p>
      </div>
    </section>
  );
}
