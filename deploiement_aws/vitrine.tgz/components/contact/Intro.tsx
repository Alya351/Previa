"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { IconMail, IconPhone, IconMapPin, IconSend } from "@/components/home/icons";
import { api, ApiError } from "@/lib/api";

const EASE = [0.22, 1, 0.36, 1] as const;

const INFO = [
  {
    icon: IconPhone,
    value: "54-31-51-11",
    hint: "Appelez-nous directement",
    href: "tel:+22654315111",
  },
  {
    icon: IconMail,
    value: "amanefantak@gmail.com",
    hint: "Réponse rapide de notre équipe",
    href: "mailto:amanefantak@gmail.com",
  },
  {
    icon: IconMapPin,
    value: "Ouagadougou",
    hint: "Burkina Faso",
    href: undefined,
  },
] as const;

export default function Intro() {
  const reduce = useReducedMotion();
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (sending) return;
    const form = e.currentTarget;
    const data = new FormData(form);
    setSending(true);
    setError(null);
    try {
      // Le message est enregistré côté serveur : le superadmin est notifié.
      await api.contact({
        nom: String(data.get("name") ?? ""),
        email: String(data.get("email") ?? ""),
        telephone: String(data.get("phone") ?? "") || undefined,
        message: String(data.get("message") ?? ""),
      });
      setSent(true);
      window.setTimeout(() => setSent(false), 4000);
      form.reset();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Envoi impossible. Réessayez.");
    } finally {
      setSending(false);
    }
  }

  return (
    <section id="contact" className="hero ct-intro">
      <div className="container">
        <motion.div
          className="ct-card"
          initial={{ opacity: 0, y: reduce ? 0 : 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.7, ease: EASE }}
        >
          <div className="ct-head">
            <h1 className="ct-title">
              CONTACTEZ-<span>NOUS</span>
            </h1>
            <p className="ct-sub">
              Une question ou besoin d&apos;assistance ? Nous sommes à votre écoute.
            </p>
          </div>

          <div className="ct-body">
            <ul className="ct-info-list">
              {INFO.map((item) => {
                const Icon = item.icon;
                const content = (
                  <>
                    <span className="ct-info-icon">
                      <Icon width={22} height={22} />
                    </span>
                    <span className="ct-info-text">
                      <span className="ct-info-value">{item.value}</span>
                      <span className="ct-info-hint">{item.hint}</span>
                    </span>
                  </>
                );
                return (
                  <li key={item.value}>
                    {item.href ? (
                      <a href={item.href} className="ct-info-link">
                        {content}
                      </a>
                    ) : (
                      <div className="ct-info-link">{content}</div>
                    )}
                  </li>
                );
              })}
            </ul>

            <form className="ct-form" onSubmit={handleSubmit}>
              <input name="name" type="text" placeholder="Votre nom" aria-label="Votre nom" required />
              <input
                name="email"
                type="email"
                placeholder="Votre e-mail"
                aria-label="Votre e-mail"
                required
              />
              <input
                name="phone"
                type="tel"
                placeholder="Votre numéro de téléphone"
                aria-label="Votre numéro de téléphone"
              />
              <textarea
                name="message"
                rows={4}
                placeholder="Votre message"
                aria-label="Votre message"
                required
              />

              <label className="ct-consent">
                <input type="checkbox" name="consent" required />
                <span>
                  J&apos;accepte les{" "}
                  <Link href="/mentions-legales">conditions d&apos;utilisation</Link> et la{" "}
                  <Link href="/confidentialite">politique de confidentialité</Link> relatives au
                  traitement de mes données personnelles.
                </span>
              </label>

              {error && (
                <p role="alert" style={{ margin: 0, fontSize: "0.82rem", fontWeight: 700, color: "var(--au-danger, #d1554c)" }}>
                  {error}
                </p>
              )}

              <button type="submit" className="ct-submit" disabled={sending}>
                <IconSend width={18} height={18} />
                {sending ? "Envoi..." : sent ? "Demande envoyée" : "Envoyer ma demande"}
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
