"use client";

import { useState } from "react";
import { motion, useReducedMotion, AnimatePresence } from "motion/react";
import { IconEye, IconEyeOff, IconCopy, IconDownload, IconKeyRound } from "@/components/home/icons";
import type { AbonnementApi } from "@/lib/api";
import { formatDate } from "./types";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Enveloppe puis code d'activation réel (affiché après OTP). Aucune activation à faire : l'abonnement est déjà actif. */
export default function BootstrapCode({
  code,
  subscription,
  expireLe,
  onReceipt,
}: {
  code: string;
  subscription: AbonnementApi;
  expireLe: string | null;
  onReceipt: () => void;
}) {
  const reduce = useReducedMotion();
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [stage, setStage] = useState<"closed" | "opening" | "open">(reduce ? "open" : "closed");

  const formatted = `${code.slice(0, 4)} ${code.slice(4)}`;
  const masked = `${code.slice(0, 2)}•• ••${code.slice(6)}`;

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {}
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  const openEnvelope = () => {
    if (stage !== "closed") return;
    setStage("opening");
    window.setTimeout(() => setStage("open"), 750);
  };

  if (stage !== "open") {
    return (
      <motion.div
        className="es-block"
        initial={{ opacity: 0, y: reduce ? 0 : 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: EASE }}
      >
        <div className="es-envelope-stage">
          <button
            type="button"
            className="es-envelope"
            onClick={openEnvelope}
            disabled={stage === "opening"}
            aria-label="Ouvrir l'enveloppe pour découvrir votre code d'activation"
          >
            <motion.div
              className="es-envelope-peek"
              initial={{ y: 36, opacity: 0 }}
              animate={stage === "opening" ? { y: -78, opacity: 1 } : { y: 36, opacity: 0 }}
              transition={{ duration: 0.55, delay: 0.28, ease: EASE }}
            >
              <IconKeyRound width={22} height={22} />
            </motion.div>
            <svg className="es-envelope-svg" viewBox="0 0 220 150" aria-hidden>
              <rect x="4" y="34" width="212" height="112" rx="18" className="es-envelope-pocket" />
              <circle cx="110" cy="70" r="15" className="es-envelope-seal" />
              <motion.g
                style={{ transformOrigin: "110px 34px", transformPerspective: 500 }}
                animate={{ rotateX: stage === "opening" ? -155 : 0 }}
                transition={{ duration: 0.5, ease: EASE }}
              >
                <polygon points="4,34 216,34 110,104" className="es-envelope-flap" />
              </motion.g>
            </svg>
          </button>
          {stage === "closed" && <p className="es-envelope-label">Cliquez pour ouvrir votre enveloppe</p>}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      className="es-block"
      initial={{ opacity: 0, y: reduce ? 0 : 20, scale: reduce ? 1 : 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5, ease: EASE }}
    >
      <div className="es-code-card">
        <motion.span
          className="es-code-icon"
          animate={reduce ? undefined : { y: [0, -5, 0] }}
          transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
        >
          <IconKeyRound width={22} height={22} />
        </motion.span>

        <span className="es-code-label">Votre code d&apos;activation</span>

        <div className="es-code-display">
          <AnimatePresence mode="wait" initial={false}>
            {revealed ? (
              <motion.span
                key="revealed"
                className="es-code-value"
                initial="hidden"
                animate="show"
                variants={{ show: { transition: { staggerChildren: 0.035 } } }}
              >
                {formatted.split("").map((char, i) => (
                  <motion.span
                    key={i}
                    className="es-code-char"
                    variants={{
                      hidden: { opacity: 0, y: reduce ? 0 : 10, filter: reduce ? "none" : "blur(4px)" },
                      show: { opacity: 1, y: 0, filter: "blur(0px)", transition: { duration: 0.3, ease: EASE } },
                    }}
                  >
                    {char === " " ? "  " : char}
                  </motion.span>
                ))}
              </motion.span>
            ) : (
              <motion.span
                key="masked"
                className="es-code-value es-code-value--masked"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
              >
                {masked}
              </motion.span>
            )}
          </AnimatePresence>
        </div>

        <div className="es-code-actions">
          <motion.button
            type="button"
            className="btn btn-secondary"
            whileTap={{ scale: 0.95 }}
            onClick={() => setRevealed((v) => !v)}
          >
            {revealed ? <IconEyeOff width={16} height={16} /> : <IconEye width={16} height={16} />}
            {revealed ? "Masquer le code" : "Afficher le code"}
          </motion.button>
          <motion.button type="button" className="btn btn-secondary" whileTap={{ scale: 0.95 }} onClick={copyCode}>
            <IconCopy width={16} height={16} />
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={copied ? "copied" : "copy"}
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                transition={{ duration: 0.18 }}
                style={{ display: "inline-block" }}
              >
                {copied ? "Copié ✓" : "Copier le code"}
              </motion.span>
            </AnimatePresence>
          </motion.button>
        </div>
      </div>

      <div className="es-ref-meta es-ref-meta--wide">
        <div>
          <span className="es-recap-label">Statut</span>
          <span className="es-status-pill es-status-pill--available">Disponible</span>
        </div>
        <div>
          <span className="es-recap-label">Abonnement</span>
          <span className="es-recap-value">{subscription.plan.nom}</span>
        </div>
        <div>
          <span className="es-recap-label">Date d&apos;émission</span>
          <span className="es-recap-value">{formatDate(subscription.code_envoye_le)}</span>
        </div>
        <div>
          <span className="es-recap-label">Date d&apos;expiration</span>
          <span className="es-recap-value">{formatDate(expireLe ?? subscription.fin)}</span>
        </div>
        <div>
          <span className="es-recap-label">Caméras autorisées</span>
          <span className="es-recap-value">{subscription.plan.cameras_max}</span>
        </div>
        <div>
          <span className="es-recap-label">Référence</span>
          <span className="es-recap-value" data-no-translate>
            {subscription.reference}
          </span>
        </div>
      </div>

      <motion.button type="button" className="btn btn-secondary es-activate-btn" whileTap={{ scale: 0.97 }} onClick={onReceipt}>
        <IconDownload width={16} height={16} />
        Télécharger le reçu (PDF)
      </motion.button>
    </motion.div>
  );
}
