import type { ReceiptData } from "./types";
import { tr, currentLang } from "@/lib/i18n/translate";

const BLUE: [number, number, number] = [0, 158, 227];
const DARK: [number, number, number] = [22, 50, 63];
const MUTED: [number, number, number] = [107, 125, 136];

/** Reçu PDF du code d'activation. Réservé au client, uniquement après vérification OTP (R37). */
export async function downloadBootstrapReceipt(data: ReceiptData) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const marginX = 56;
  let y = 64;

  const formattedCode = data.code ? `${data.code.slice(0, 4)} ${data.code.slice(4)}` : "—";
  const generatedAt = new Intl.DateTimeFormat(currentLang() === "en" ? "en-GB" : "fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date());

  // En-tête
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(...BLUE);
  doc.text("Previa", marginX, y);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  doc.text(tr("Surveillance intelligente. Anticipation renforcée."), marginX, y + 14);
  doc.text(tr(`Émis le ${generatedAt}`), pageWidth - marginX, y, { align: "right" });

  y += 30;
  doc.setDrawColor(...BLUE);
  doc.setLineWidth(1.4);
  doc.line(marginX, y, pageWidth - marginX, y);

  y += 36;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.setTextColor(...DARK);
  doc.text(tr("Reçu de demande de code d'activation"), marginX, y);

  y += 16;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...MUTED);
  doc.text(tr(`Référence ${data.reference}`), marginX, y);

  // Bloc code
  y += 28;
  const boxHeight = 70;
  doc.setFillColor(242, 250, 253);
  doc.setDrawColor(...BLUE);
  doc.setLineDashPattern([3, 2], 0);
  doc.roundedRect(marginX, y, pageWidth - marginX * 2, boxHeight, 8, 8, "FD");
  doc.setLineDashPattern([], 0);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  doc.text(tr("CODE D'ACTIVATION"), pageWidth / 2, y + 24, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.setTextColor(...DARK);
  doc.text(formattedCode, pageWidth / 2, y + 50, { align: "center" });

  y += boxHeight + 34;

  const rows: [string, string][] = [
    [tr("Client"), data.clientName],
    [tr("E-mail"), data.clientEmail],
    [tr("Abonnement"), tr(data.planName)],
    [tr("Caméras autorisées"), tr(data.cameras)],
    [tr("Durée"), tr(data.duration)],
    [tr("Montant"), tr(data.amount)],
    [tr("Statut"), tr(data.statut)],
    [tr("Date de la demande"), tr(data.date)],
    [tr("Date d'expiration du code"), data.expiration ? tr(data.expiration) : "—"],
  ];

  doc.setFontSize(10.5);
  for (const [label, value] of rows) {
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...MUTED);
    doc.text(label, marginX, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...DARK);
    doc.text(value, pageWidth - marginX, y, { align: "right" });
    doc.setDrawColor(238, 242, 245);
    doc.setLineWidth(0.6);
    doc.line(marginX, y + 6, pageWidth - marginX, y + 6);
    y += 24;
  }

  y += 20;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(...MUTED);
  const footer = doc.splitTextToSize(
    tr(
      "Ce reçu atteste de l'émission d'un code d'activation Previa. Ce code est personnel, à usage unique, et doit être utilisé pour l'inscription du premier administrateur sur la plateforme Previa. Ne le partagez pas."
    ),
    pageWidth - marginX * 2
  );
  doc.text(footer, pageWidth / 2, y, { align: "center" });

  doc.save(`recu-previa-${data.reference}.pdf`);
}
