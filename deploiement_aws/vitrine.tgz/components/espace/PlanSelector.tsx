"use client";

import { motion, useReducedMotion } from "motion/react";
import {
  IconCheck,
  IconArrowRight,
  IconCamera,
  IconLayers,
  IconUser,
  IconUsers,
  IconClock,
  IconWallet,
} from "@/components/home/icons";
import { PaymentBand, PlanPriceBadge } from "./PlanPricing";
import { TRANCHES, formatFcfa, planPrice, trancheAmount, type ClientType, type Plan } from "./types";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function PlanSelector({
  plans,
  selected,
  clientType,
  renewing,
  renewalExtra = 0,
  onClientType,
  onSelect,
  onEdit,
  onContinue,
  onQuote,
}: {
  plans: Plan[];
  selected: Plan | null;
  clientType: ClientType;
  /** true : renouvellement annuel (même abonnement, changement d'offre possible). */
  renewing?: boolean;
  /** Reliquat de la 1re année à solder en même temps que le renouvellement. */
  renewalExtra?: number;
  onClientType: (t: ClientType) => void;
  onSelect: (p: Plan) => void;
  onEdit: () => void;
  onContinue: () => void;
  onQuote: (p: Plan) => void;
}) {
  const reduce = useReducedMotion();
  const base = selected ? (renewing ? selected.renewalPrice : planPrice(selected, clientType)) : null;
  const total = base !== null && renewing ? base + renewalExtra : base;

  return (
    <div className="es-block">
      <h2 className="es-block-title">{renewing ? "Renouvelez votre abonnement" : "Choisissez votre offre"}</h2>
      <p className="es-equip-hint es-equip-hint--center">
        {renewing
          ? "Abonnement annuel, au même tarif quelle que soit l'offre."
          : "Un prix tout compris, payable en 3 tranches."}
      </p>

      <div className="es-plans">
        {plans.map((plan, i) => {
          const isActive = selected?.id === plan.id;
          return (
            <motion.article
              key={plan.id}
              className={`es-plan ${isActive ? "is-active" : ""} ${selected && !isActive ? "is-dim" : ""}`}
              initial={{ opacity: 0, y: reduce ? 0 : 16 }}
              animate={{ opacity: 1, y: 0, scale: isActive && !reduce ? 1.02 : 1 }}
              transition={{ duration: 0.45, ease: EASE, delay: reduce ? 0 : i * 0.08 }}
              whileHover={reduce ? undefined : { y: -8, transition: { duration: 0.25, ease: EASE } }}
              whileTap={reduce ? undefined : { scale: 0.98 }}
              onClick={() => onSelect(plan)}
            >
              {plan.recommended && <span className="es-plan-badge">Recommandé</span>}

              <div className="es-plan-clip">
                {isActive && (
                  <motion.span
                    className="es-plan-check"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.3, ease: EASE }}
                  >
                    <IconCheck width={14} height={14} />
                  </motion.span>
                )}

                <span className="es-plan-head-edge" aria-hidden="true" />
                <span className="es-plan-head-fill" aria-hidden="true" />
                <span className="es-plan-corner es-plan-corner--dark" aria-hidden="true" />
                <span className="es-plan-corner es-plan-corner--light" aria-hidden="true" />

                <div className="es-plan-head">
                  <h3 className="es-plan-name">{plan.name}</h3>
                </div>

                <PlanPriceBadge plan={plan} />

                <div className="es-plan-content">
                  <ul className="es-plan-features">
                    {[...plan.features, plan.support].filter(Boolean).map((f, fi) => (
                      <motion.li
                        key={f}
                        initial={{ opacity: 0, x: reduce ? 0 : -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, ease: EASE, delay: reduce ? 0 : i * 0.08 + 0.15 + fi * 0.05 }}
                      >
                        <IconCheck width={14} height={14} />
                        {f}
                      </motion.li>
                    ))}
                  </ul>

                  <button type="button" className="es-plan-btn">
                    {isActive ? "Offre sélectionnée" : plan.payable ? "Choisir cette offre" : "Demander un devis"}
                  </button>
                </div>
              </div>
            </motion.article>
          );
        })}
      </div>

      <PaymentBand renewalPrice={plans.find((p) => p.renewalPrice !== null)?.renewalPrice ?? null} />

      {selected && (
        <motion.div
          className="es-recap"
          initial={{ opacity: 0, y: reduce ? 0 : 14, height: 0 }}
          animate={{ opacity: 1, y: 0, height: "auto" }}
          transition={{ duration: 0.4, ease: EASE }}
        >
          <h3 className="es-recap-title">Votre sélection</h3>
          {/* Résumé en tuiles (la dernière, d'un bleu clair plus soutenu, met en avant le total) */}
          <div className="es-sel-grid">
            <div className="es-sel-tile">
              <span className="es-sel-label">Offre</span>
              <div className="es-sel-main">
                <span className="es-sel-icon">
                  <IconLayers width={22} height={22} />
                </span>
                <div>
                  <span className="es-sel-value">{selected.name}</span>
                  <span className="es-sel-sub">{selected.support}</span>
                </div>
              </div>
            </div>

            <div className="es-sel-tile">
              <span className="es-sel-label">{renewing ? "Durée" : "Profil"}</span>
              <div className="es-sel-main">
                <span className="es-sel-icon">
                  {renewing ? <IconClock width={22} height={22} /> : <IconUser width={22} height={22} />}
                </span>
                {renewing ? (
                  <div>
                    <span className="es-sel-value">1 an</span>
                    <span className="es-sel-sub">Abonnement annuel</span>
                  </div>
                ) : (
                  <span className="es-duration-chips" role="radiogroup" aria-label="Type de client">
                    {(
                      [
                        ["particulier", "Particulier", IconUser],
                        ["entreprise", "Entreprise", IconUsers],
                      ] as const
                    ).map(([id, label, Icon]) => (
                      <button
                        key={id}
                        type="button"
                        role="radio"
                        aria-checked={clientType === id}
                        className={`es-duration-chip ${clientType === id ? "is-active" : ""}`}
                        onClick={() => onClientType(id)}
                      >
                        <Icon width={13} height={13} />
                        {label}
                      </button>
                    ))}
                  </span>
                )}
              </div>
            </div>

            <div className="es-sel-tile">
              <span className="es-sel-label">Caméras autorisées</span>
              <div className="es-sel-main">
                <span className="es-sel-icon">
                  <IconCamera width={22} height={22} />
                </span>
                <div>
                  <span className="es-sel-value">{selected.camerasMax}</span>
                  <span className="es-sel-sub">{selected.equipped ? "caméras existantes" : "caméras fournies"}</span>
                </div>
              </div>
            </div>

            <div className="es-sel-tile es-sel-tile--total">
              <span className="es-sel-label">
                {total === null ? "Prix" : renewing ? "À payer" : "Total de la 1re année"}
              </span>
              <div className="es-sel-main">
                <span className="es-sel-icon">
                  <IconWallet width={22} height={22} />
                </span>
                <div>
                  <span className="es-sel-value">{total !== null ? `${formatFcfa(total)} FCFA` : "Sur devis"}</span>
                  <span className="es-sel-sub">
                    {total === null
                      ? "Selon devis"
                      : renewing
                        ? renewalExtra > 0
                          ? `Abonnement annuel + solde de la 1re année (${formatFcfa(renewalExtra)} FCFA)`
                          : "Abonnement annuel"
                        : `${TRANCHES} tranches · 1re : ${formatFcfa(trancheAmount(total, 1))} FCFA`}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="es-recap-actions" style={{ marginTop: 18 }}>
            <motion.button
              type="button"
              className="btn btn-secondary"
              whileTap={{ scale: 0.96 }}
              onClick={onEdit}
            >
              Modifier mon choix
            </motion.button>
            <motion.button
              type="button"
              className="btn btn-primary"
              whileHover={{ x: 2 }}
              whileTap={{ scale: 0.96 }}
              onClick={selected.payable ? onContinue : () => onQuote(selected)}
            >
              {selected.payable ? "Continuer vers le paiement" : "Demander un devis"}
              <motion.span
                style={{ display: "inline-flex" }}
                animate={{ x: [0, 3, 0] }}
                transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
              >
                <IconArrowRight width={16} height={16} />
              </motion.span>
            </motion.button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
