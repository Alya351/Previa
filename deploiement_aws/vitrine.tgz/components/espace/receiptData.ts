import type { AbonnementApi, PaiementApi } from "@/lib/api";
import { TRANCHES, durationLabel, formatDate, formatFcfa, type ReceiptData } from "./types";

/** Assemble les données du reçu PDF à partir de l'abonnement, des paiements et du code (déjà vérifié par OTP). */
export function buildReceipt(
  user: { name: string; email: string },
  sub: AbonnementApi,
  payments: PaiementApi[],
  code: string,
  expireLe?: string | null
): ReceiptData {
  const first = sub.periodes?.[0];
  const payment = payments.find((p) => p.id === first?.payment_id) ?? payments.find((p) => p.statut === "reussi");
  const months = first?.duree_mois ?? payment?.duree_mois ?? 12;
  const amount =
    sub.prix_total != null
      ? `${formatFcfa(sub.prix_total)} FCFA (${sub.tranches_payees ?? 1}/${TRANCHES} tranches réglées)`
      : payment
        ? `${formatFcfa(payment.montant)} FCFA`
        : "Sur devis";
  return {
    reference: sub.reference,
    planName: sub.plan.nom,
    cameras: `${sub.plan.cameras_max} caméras`,
    duration: durationLabel(months),
    amount,
    statut: sub.statut === "actif" || sub.statut === "expire_bientot" ? "Abonnement actif" : "Abonnement " + sub.statut,
    date: formatDate(sub.cree_le),
    code,
    expiration: formatDate(expireLe ?? sub.fin),
    clientName: user.name,
    clientEmail: user.email,
  };
}
