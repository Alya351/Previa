"use client";

import { motion } from "motion/react";
import { IconCheck } from "@/components/home/icons";
import type { FlowState } from "./types";

type StepStatus = "done" | "active" | "upcoming" | "error";

const STEPS = [
  { n: "01", label: "Offre" },
  { n: "02", label: "Paiement" },
  { n: "03", label: "Code" },
  { n: "04", label: "Abonnement" },
] as const;

function statusForStep(index: number, state: FlowState): StepStatus {
  const stageOf: Record<FlowState, number> = {
    AUCUNE_DEMANDE: 0,
    OFFRE_SELECTIONNEE: 0,
    PAIEMENT: 1,
    PAIEMENT_EN_COURS: 1,
    PAIEMENT_ECHOUE: 1,
    EN_ATTENTE_CODE: 2,
    CODE_DISPONIBLE: 2,
    OTP: 2,
    CODE_AFFICHE: 3,
  };
  const current = stageOf[state];
  if (index < current) return "done";
  if (index === current) return state === "CODE_AFFICHE" && index === 3 ? "done" : "active";
  return "upcoming";
}

export default function StageTimeline({ state }: { state: FlowState }) {
  return (
    <div className="es-stages" role="list" aria-label="Progression de l'activation">
      {STEPS.map((step, i) => {
        const status = statusForStep(i, state);
        return (
          <div className="es-stage" role="listitem" key={step.n} data-status={status}>
            <div className="es-stage-node">
              {status === "done" ? (
                <motion.span
                  className="es-stage-check"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                >
                  <IconCheck width={13} height={13} />
                </motion.span>
              ) : (
                <span className="es-stage-n">{step.n}</span>
              )}
              {status === "active" && <span className="es-stage-halo" aria-hidden />}
            </div>
            <span className="es-stage-label">{step.label}</span>
            {i < STEPS.length - 1 && (
              <span className="es-stage-connector" aria-hidden>
                <motion.span
                  className="es-stage-connector-fill"
                  initial={false}
                  animate={{ scaleX: status === "done" ? 1 : 0 }}
                  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                />
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}
