"use client";

import { motion, useReducedMotion } from "motion/react";
import type { AbonnementApi, SubStatus } from "@/lib/api";
import { TRANCHES, durationLabel, formatDate, formatFcfa } from "./types";

const EASE = [0.22, 1, 0.36, 1] as const;

const STATUS_LABEL: Record<SubStatus, string> = {
  en_attente_code: "En attente du code",
  actif: "Actif",
  expire_bientot: "Expire bientôt",
  expire: "Expiré",
  suspendu: "Suspendu",
  termine: "Terminé",
};

const STATUS_CLASS: Record<SubStatus, string> = {
  en_attente_code: "pending",
  actif: "active",
  expire_bientot: "pending",
  expire: "danger",
  suspendu: "danger",
  termine: "danger",
};

/** Petite carte récapitulative de l'abonnement : visible sans OTP (R38). */
export default function SubscriptionSummary({
  subscription,
  onRenew,
  onPayInstallment,
}: {
  subscription: AbonnementApi;
  onRenew?: () => void;
  /** Paiement de la tranche suivante (2/3 puis 3/3) de la 1re année, ou du reliquat entier (`solde`). */
  onPayInstallment?: (solde?: boolean) => void;
}) {
  const reduce = useReducedMotion();
  const last = subscription.periodes?.[subscription.periodes.length - 1];
  const next = subscription.prochaine_tranche ?? null;
  const reliquat = subscription.reliquat ?? 0;
  const alert =
    subscription.etat_tranche === "impayee"
      ? { kind: "danger", text: "Votre accès est suspendu faute de paiement de la tranche. Il reprend dès le règlement." }
      : subscription.etat_tranche === "echue"
        ? { kind: "danger", text: "Une tranche est en retard : réglez-la rapidement pour éviter la suspension de votre accès." }
        : subscription.etat_tranche === "proche"
          ? { kind: "pending", text: "Une tranche arrive à échéance prochainement." }
          : null;

  return (
    <motion.div
      className="es-sub-card"
      initial={{ opacity: 0, y: reduce ? 0 : 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: EASE }}
    >
      <div className="es-sub-head">
        <h3 className="es-panel-h">Mon abonnement</h3>
        <span className={`es-status-pill es-status-pill--${STATUS_CLASS[subscription.statut]}`}>
          {STATUS_LABEL[subscription.statut]}
        </span>
      </div>
      <div className="es-ref-meta es-ref-meta--wide">
        <div>
          <span className="es-recap-label">Offre</span>
          <span className="es-recap-value">{subscription.plan.nom}</span>
        </div>
        <div>
          <span className="es-recap-label">Caméras autorisées</span>
          <span className="es-recap-value">{subscription.plan.cameras_max}</span>
        </div>
        <div>
          <span className="es-recap-label">Début</span>
          <span className="es-recap-value">{formatDate(subscription.debut)}</span>
        </div>
        <div>
          <span className="es-recap-label">Fin</span>
          <span className="es-recap-value">{formatDate(subscription.fin)}</span>
        </div>
        {last && (
          <div>
            <span className="es-recap-label">Dernière période</span>
            <span className="es-recap-value">{durationLabel(last.duree_mois)}</span>
          </div>
        )}
        <div>
          <span className="es-recap-label">Référence</span>
          <span className="es-recap-value" data-no-translate>
            {subscription.reference}
          </span>
        </div>
      </div>
      {subscription.prix_total != null && (
        <div className="es-installments">
          <div className="es-installments-head">
            <span className="es-recap-label">Paiement de la 1re année</span>
            <span className="es-recap-value">
              {subscription.tranches_payees ?? 0}/{TRANCHES} tranches réglées · {formatFcfa(subscription.prix_total)} FCFA
            </span>
          </div>
          <div className="es-installments-bar" aria-hidden="true">
            {Array.from({ length: TRANCHES }, (_, i) => (
              <span key={i} className={i < (subscription.tranches_payees ?? 0) ? "is-paid" : ""} />
            ))}
          </div>
          {next && (
            <p className="es-installments-next">
              Prochaine tranche ({next.numero}/{TRANCHES}) : <strong>{formatFcfa(next.montant)} FCFA</strong>
              {next.echeance ? ` · avant le ${formatDate(next.echeance)}` : " · dès l'activation de votre code"}
            </p>
          )}
          {alert && <p className={`es-installments-alert es-installments-alert--${alert.kind}`}>{alert.text}</p>}
          {next && onPayInstallment && (
            <button type="button" className="btn btn-secondary es-activate-btn" onClick={() => onPayInstallment(false)}>
              Payer la tranche {next.numero}/{TRANCHES}
            </button>
          )}
          {next && onPayInstallment && next.numero < TRANCHES && (
            <button type="button" className="es-installments-settle" onClick={() => onPayInstallment(true)}>
              Tout solder d&apos;un coup ({formatFcfa(reliquat)} FCFA)
            </button>
          )}
        </div>
      )}
      {onRenew && (
        <button type="button" className="btn btn-primary es-activate-btn" onClick={onRenew}>
          {next ? `Solder (${formatFcfa(reliquat)} FCFA) et renouveler` : "Renouveler mon abonnement"}
        </button>
      )}
    </motion.div>
  );
}
