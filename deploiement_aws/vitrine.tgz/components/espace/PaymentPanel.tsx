"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import {
  IconWallet,
  IconCreditCard,
  IconCheck,
  IconAlertTriangle,
  IconPhone,
  IconChevronDown,
  IconShieldCheck,
} from "@/components/home/icons";
import Image from "next/image";
import CardPreview from "./CardPreview";
import Modal from "@/components/home/Modal";
import { MOBILE_MONEY_LOGO_SRC } from "./MobileMoneyLogos";
import {
  COUNTRY_CODES,
  COUNTRY_NETWORKS,
  MOBILE_NETWORKS,
  formatFcfa,
  type MobileNetworkId,
  type Plan,
  type PaymentMethodId,
  type PaymentDetails,
  type ClientType,
} from "./types";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export type RecipientInfo = {
  clientType: ClientType;
  entrepriseName?: string;
  recipientFirstName: string;
  recipientLastName: string;
  recipientEmail: string;
};

const EASE = [0.22, 1, 0.36, 1] as const;

const METHODS: { id: PaymentMethodId; label: string; hint: string; icon: typeof IconWallet }[] = [
  { id: "mobile-money", label: "Mobile Money", hint: "Orange, MTN, Moov, Wave…", icon: IconWallet },
  { id: "carte", label: "Carte bancaire", hint: "Visa, Mastercard", icon: IconCreditCard },
];

function formatCardNumber(v: string) {
  return v
    .replace(/\D/g, "")
    .slice(0, 16)
    .replace(/(.{4})/g, "$1 ")
    .trim();
}
function formatExpiry(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
}
function formatPhone(v: string) {
  return v
    .replace(/\D/g, "")
    .slice(0, 10)
    .replace(/(.{2})/g, "$1 ")
    .trim();
}

function CountrySelect({
  country,
  countries,
  onChange,
}: {
  country: (typeof COUNTRY_CODES)[number];
  countries: typeof COUNTRY_CODES;
  onChange: (c: (typeof COUNTRY_CODES)[number]) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="es-country-select" ref={ref}>
      <button type="button" className="es-country-btn" onClick={() => setOpen((v) => !v)}>
        <span>{country.flag}</span>
        {country.dial}
        <IconChevronDown width={12} height={12} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            className="es-panel es-country-panel"
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.18, ease: EASE }}
          >
            {countries.map((c) => (
              <button
                type="button"
                key={c.id}
                className={`es-country-option ${c.id === country.id ? "is-active" : ""}`}
                onClick={() => {
                  onChange(c);
                  setOpen(false);
                }}
              >
                <span>{c.flag}</span>
                {c.name}
                <span className="es-country-dial">{c.dial}</span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** checkout = 1re tranche (avec les infos du destinataire) ; installment = tranche suivante ; renew = renouvellement annuel. */
export type PaymentMode = "checkout" | "installment" | "renew";

export default function PaymentPanel({
  plan,
  mode,
  clientType,
  amount,
  caption,
  status,
  errorMessage,
  onPay,
}: {
  plan: Plan;
  mode: PaymentMode;
  clientType: ClientType;
  /** Montant prélevé maintenant (FCFA). */
  amount: number;
  /** Précision affichée avec le montant (ex. « tranche 1/3 sur 570 000 FCFA »). */
  caption: string;
  status: "idle" | "loading" | "error";
  errorMessage?: string;
  onPay: (method: PaymentMethodId, recipient: RecipientInfo, details: PaymentDetails) => void;
}) {
  const totalLabel = `${formatFcfa(amount)} FCFA · ${caption}`;
  const needsRecipient = mode === "checkout";
  const reduce = useReducedMotion();
  const [method, setMethod] = useState<PaymentMethodId>("mobile-money");

  const [network, setNetwork] = useState<MobileNetworkId | null>(null);
  const [country, setCountry] = useState(COUNTRY_CODES[0]);
  const [phone, setPhone] = useState("");
  const [touched, setTouched] = useState(false);

  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardName, setCardName] = useState("");
  const [cvvFocused, setCvvFocused] = useState(false);

  const [entrepriseName, setEntrepriseName] = useState("");
  const [recipientFirstName, setRecipientFirstName] = useState("");
  const [recipientLastName, setRecipientLastName] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [recipientTouched, setRecipientTouched] = useState(false);

  // Les 4 opérateurs restent toujours affichés. En revanche, un opérateur
  // n'est disponible que dans certains pays (ex: MTN n'existe qu'au Ghana et
  // en Côte d'Ivoire parmi nos pays listés) : une fois l'opérateur choisi, le
  // sélecteur de pays ne propose plus que les pays où il est réellement présent.
  const availableCountries = network
    ? COUNTRY_CODES.filter((c) => (COUNTRY_NETWORKS[c.id] ?? []).includes(network))
    : COUNTRY_CODES;

  const handleNetworkSelect = (id: MobileNetworkId) => {
    setNetwork(id);
    // Si le pays actuellement choisi ne propose pas cet opérateur, on bascule
    // automatiquement sur le premier pays où il est disponible.
    if (!(COUNTRY_NETWORKS[country.id] ?? []).includes(id)) {
      const firstValid = COUNTRY_CODES.find((c) => (COUNTRY_NETWORKS[c.id] ?? []).includes(id));
      if (firstValid) setCountry(firstValid);
    }
  };

  const phoneDigits = phone.replace(/\D/g, "");
  const mobileValid = !!network && phoneDigits.length >= 8 && phoneDigits.length <= 10;

  const cardDigits = cardNumber.replace(/\s/g, "");
  const expiryMonth = Number(expiry.slice(0, 2));
  const expiryDay = Number(expiry.slice(3, 5));
  const expiryValid =
    /^\d{2}\/\d{2}$/.test(expiry) && expiryMonth >= 1 && expiryMonth <= 12 && expiryDay >= 1 && expiryDay <= 31;
  const cardValid = cardDigits.length === 16 && expiryValid && cvv.length === 3 && cardName.trim().length > 1;

  const recipientValid =
    !needsRecipient ||
    (recipientFirstName.trim().length > 0 &&
      recipientLastName.trim().length > 0 &&
      EMAIL_RE.test(recipientEmail) &&
      (clientType !== "entreprise" || entrepriseName.trim().length > 0));

  const formValid = recipientValid && (method === "mobile-money" ? mobileValid : cardValid);
  const selectedNetwork = MOBILE_NETWORKS.find((n) => n.id === network);

  const [confirmOpen, setConfirmOpen] = useState(false);

  const handleSubmit = () => {
    setRecipientTouched(true);
    if (method === "mobile-money") setTouched(true);
    if (!formValid) return;
    setConfirmOpen(true);
  };

  const confirmAndPay = () => {
    setConfirmOpen(false);
    onPay(
      method,
      {
        clientType,
        entrepriseName: clientType === "entreprise" ? entrepriseName.trim() : undefined,
        recipientFirstName: recipientFirstName.trim(),
        recipientLastName: recipientLastName.trim(),
        recipientEmail: recipientEmail.trim(),
      },
      method === "mobile-money"
        ? { operateur: network ?? undefined, telephone: `${country.dial} ${phone}` }
        : { carteNumero: cardDigits }
    );
  };

  return (
    <>
    <motion.div
      className="es-block"
      initial={{ opacity: 0, y: reduce ? 0 : 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: EASE }}
    >
      <h2 className="es-block-title">Finaliser votre paiement</h2>

      <div className="es-payment-layout">
        <div className="es-payment-methods">
          <AnimatePresence mode="wait" initial={false}>
            {status === "loading" ? (
              <motion.div
                key="loading"
                className="es-pay-loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
              >
                <span className="es-pay-loading-icon-wrap">
                  <motion.span
                    className="es-pay-loading-ring"
                    animate={reduce ? undefined : { rotate: 360 }}
                    transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }}
                    style={
                      method === "mobile-money" && selectedNetwork
                        ? { borderColor: `${selectedNetwork.color}66` }
                        : undefined
                    }
                  />
                  <span
                    className="es-pay-loading-icon"
                    style={
                      method === "mobile-money" && selectedNetwork
                        ? { background: `${selectedNetwork.color}22`, color: selectedNetwork.color }
                        : undefined
                    }
                  >
                    {method === "mobile-money" ? (
                      <IconPhone width={20} height={20} />
                    ) : (
                      <IconCreditCard width={20} height={20} />
                    )}
                  </span>
                </span>
                {method === "mobile-money" ? (
                  <>
                    <p className="es-pay-loading-title">Confirmez sur votre téléphone</p>
                    <p className="es-pay-loading-text">
                      {`Une demande ${selectedNetwork?.label} a été envoyée au ${country.dial} ${phone}. Validez-la pour poursuivre.`}
                    </p>
                  </>
                ) : (
                  <>
                    <p className="es-pay-loading-title">Traitement de la transaction</p>
                    <p className="es-pay-loading-text">Votre paiement par carte est en cours de vérification sécurisée.</p>
                  </>
                )}
              </motion.div>
            ) : (
              <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
                <h3 className="es-panel-h">Choisissez votre moyen de paiement</h3>
                <div className="es-method-grid">
                  {METHODS.map((m) => {
                    const Icon = m.icon;
                    const active = method === m.id;
                    return (
                      <motion.button
                        type="button"
                        key={m.id}
                        className={`es-method ${active ? "is-active" : ""}`}
                        whileHover={reduce ? undefined : { y: -2 }}
                        whileTap={reduce ? undefined : { scale: 0.98 }}
                        onClick={() => setMethod(m.id)}
                      >
                        <span className="es-method-icon">
                          <Icon width={18} height={18} />
                        </span>
                        <span>
                          <span className="es-method-label">{m.label}</span>
                          <span className="es-method-hint">{m.hint}</span>
                        </span>
                        {active && (
                          <motion.span
                            className="es-method-check"
                            initial={{ scale: 0, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ duration: 0.25, ease: EASE }}
                          >
                            <IconCheck width={13} height={13} />
                          </motion.span>
                        )}
                      </motion.button>
                    );
                  })}
                </div>

                <AnimatePresence mode="wait" initial={false}>
                  {method === "mobile-money" ? (
                    <motion.div
                      key="mobile"
                      className="es-payment-subform"
                      initial={{ opacity: 0, y: reduce ? 0 : 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: reduce ? 0 : -6 }}
                      transition={{ duration: 0.3, ease: EASE }}
                    >
                      <span className="es-subform-label">Choisissez votre opérateur</span>
                      <div className="es-network-grid">
                        {MOBILE_NETWORKS.map((n) => (
                          <motion.button
                            type="button"
                            key={n.id}
                            className={`es-network-chip ${network === n.id ? "is-active" : ""}`}
                            whileTap={reduce ? undefined : { scale: 0.96 }}
                            onClick={() => handleNetworkSelect(n.id)}
                          >
                            <span className="es-network-logo">
                              <Image src={MOBILE_MONEY_LOGO_SRC[n.id]} alt={n.label} fill sizes="44px" style={{ objectFit: "contain" }} />
                            </span>
                            {n.label}
                          </motion.button>
                        ))}
                      </div>

                      <div className="es-field-group">
                        <label htmlFor="es-phone">Numéro de téléphone</label>
                        <div className="es-input-prefix">
                          <CountrySelect country={country} countries={availableCountries} onChange={setCountry} />
                          <input
                            id="es-phone"
                            className="es-input"
                            inputMode="numeric"
                            placeholder="07 00 00 00 00"
                            value={phone}
                            onChange={(e) => setPhone(formatPhone(e.target.value))}
                            onBlur={() => setTouched(true)}
                          />
                        </div>
                        {touched && !mobileValid && (
                          <span className="es-field-error">
                            {!network ? "Choisissez un opérateur." : "Numéro de téléphone invalide."}
                          </span>
                        )}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="card"
                      className="es-payment-subform"
                      initial={{ opacity: 0, y: reduce ? 0 : 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: reduce ? 0 : -6 }}
                      transition={{ duration: 0.3, ease: EASE }}
                    >
                      <CardPreview number={cardNumber} name={cardName} expiry={expiry} cvv={cvv} flipped={cvvFocused} />

                      <div className="es-field-group">
                        <label htmlFor="es-card-number">Numéro de carte</label>
                        <input
                          id="es-card-number"
                          className="es-input"
                          inputMode="numeric"
                          placeholder="0000 0000 0000 0000"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                        />
                      </div>
                      <div className="es-field-row">
                        <div className="es-field-group">
                          <label htmlFor="es-expiry">Expiration</label>
                          <input
                            id="es-expiry"
                            className="es-input"
                            inputMode="numeric"
                            placeholder="MM/AA"
                            value={expiry}
                            onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                          />
                        </div>
                        <div className="es-field-group">
                          <label htmlFor="es-cvv">CVV</label>
                          <input
                            id="es-cvv"
                            className="es-input"
                            inputMode="numeric"
                            placeholder="123"
                            maxLength={3}
                            value={cvv}
                            onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                            onFocus={() => setCvvFocused(true)}
                            onBlur={() => setCvvFocused(false)}
                          />
                        </div>
                      </div>
                      <div className="es-field-group">
                        <label htmlFor="es-card-name">Titulaire de la carte</label>
                        <input
                          id="es-card-name"
                          className="es-input"
                          placeholder="Comme indiqué sur la carte"
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value.toUpperCase())}
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {needsRecipient && (
                <div className="es-payment-subform es-recipient-fields">
                  <span className="es-subform-label">Vos informations</span>

                  {clientType === "entreprise" && (
                    <div className="es-field-group">
                      <label htmlFor="es-entreprise">Nom de l&apos;entreprise</label>
                      <input
                        id="es-entreprise"
                        className="es-input"
                        placeholder="Raison sociale"
                        value={entrepriseName}
                        onChange={(e) => setEntrepriseName(e.target.value)}
                      />
                      {recipientTouched && !entrepriseName.trim() && (
                        <span className="es-field-error">Le nom de l&apos;entreprise est requis.</span>
                      )}
                    </div>
                  )}

                  <div className="es-field-row">
                    <div className="es-field-group">
                      <label htmlFor="es-recipient-first">Prénom du destinataire</label>
                      <input
                        id="es-recipient-first"
                        className="es-input"
                        value={recipientFirstName}
                        onChange={(e) => setRecipientFirstName(e.target.value)}
                      />
                    </div>
                    <div className="es-field-group">
                      <label htmlFor="es-recipient-last">Nom du destinataire</label>
                      <input
                        id="es-recipient-last"
                        className="es-input"
                        value={recipientLastName}
                        onChange={(e) => setRecipientLastName(e.target.value)}
                      />
                    </div>
                  </div>
                  {recipientTouched && (!recipientFirstName.trim() || !recipientLastName.trim()) && (
                    <span className="es-field-error">Prénom et nom du destinataire sont requis.</span>
                  )}

                  <div className="es-field-group">
                    <label htmlFor="es-recipient-email">Email du destinataire</label>
                    <input
                      id="es-recipient-email"
                      className="es-input"
                      type="email"
                      placeholder="nom@exemple.com"
                      value={recipientEmail}
                      onChange={(e) => setRecipientEmail(e.target.value)}
                    />
                    {recipientTouched && !EMAIL_RE.test(recipientEmail) && (
                      <span className="es-field-error">Adresse email invalide.</span>
                    )}
                  </div>
                </div>
                )}

                <p className="es-payment-note">
                  <IconShieldCheck width={15} height={15} />
                  Le paiement est traité par un prestataire sécurisé. Previa ne collecte ni ne stocke vos informations
                  bancaires.
                </p>

                {status === "error" && (
                  <motion.p
                    className="es-payment-error"
                    initial={{ opacity: 0, x: -4 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <IconAlertTriangle width={15} height={15} />
                    {errorMessage || "Le paiement a échoué. Vérifiez vos informations et réessayez."}
                  </motion.p>
                )}

                <motion.button
                  type="button"
                  className="btn btn-primary es-payment-submit"
                  disabled={!formValid}
                  whileHover={!formValid ? undefined : { scale: 1.015 }}
                  whileTap={!formValid ? undefined : { scale: 0.97 }}
                  onClick={handleSubmit}
                >
                  {mode === "checkout" ? "Payer et envoyer ma demande" : `Payer ${formatFcfa(amount)} FCFA`}
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>

      <Modal
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        icon={<IconShieldCheck width={20} height={20} />}
        title="Est-ce bien vous ?"
        subtitle="Confirmez que c'est bien vous qui effectuez ce paiement avant de continuer."
        maxWidth={380}
      >
        <dl className="es-summary-list" style={{ margin: 0 }}>
          <div>
            <dt>Offre</dt>
            <dd>{plan.name}</dd>
          </div>
          <div>
            <dt>Moyen de paiement</dt>
            <dd>
              {method === "mobile-money"
                ? `${selectedNetwork?.label ?? "Mobile Money"} — ${country.dial} ${phone}`
                : `Carte •••• ${cardDigits.slice(-4)}`}
            </dd>
          </div>
          <div className="es-summary-total">
            <dt>Montant</dt>
            <dd>{totalLabel}</dd>
          </div>
        </dl>
        <div className="pv-modal-actions">
          <button type="button" className="btn btn-secondary" onClick={() => setConfirmOpen(false)}>
            Annuler
          </button>
          <button type="button" className="btn btn-primary" onClick={confirmAndPay}>
            Oui, c&apos;est moi — payer
          </button>
        </div>
      </Modal>
    </>
  );
}
