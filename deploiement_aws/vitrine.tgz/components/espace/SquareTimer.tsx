"use client";

/** Décompte « mm:ss » affiché dans de petits carrés (un chiffre par carré). */
export default function SquareTimer({ seconds, urgent }: { seconds: number; urgent?: boolean }) {
  const s = Math.max(0, seconds);
  const mm = String(Math.floor(s / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  const cells = [mm[0], mm[1], ":", ss[0], ss[1]];

  return (
    <div
      className={`es-timer ${urgent ? "is-urgent" : ""}`}
      role="timer"
      aria-label={`Temps restant : ${mm} minutes ${ss} secondes`}
      data-no-translate
    >
      {cells.map((c, i) =>
        c === ":" ? (
          <span key={i} className="es-timer-sep" aria-hidden>
            :
          </span>
        ) : (
          <span key={i} className="es-timer-cell" aria-hidden>
            {c}
          </span>
        )
      )}
    </div>
  );
}
