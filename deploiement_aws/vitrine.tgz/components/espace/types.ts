import type { PlanApi } from "@/lib/api";

/**
 * États de l'écran « Code d'activation » (espace client). Ils se déduisent de l'abonnement
 * renvoyé par l'API (docs/regles-metier.md) :
 *  - pas d'abonnement / terminé            → choix de l'offre et paiement
 *  - en attente du code                    → EN_ATTENTE_CODE
 *  - code envoyé par le superadmin         → CODE_DISPONIBLE (puis OTP, puis CODE_AFFICHE)
 */
export type FlowState =
  | "AUCUNE_DEMANDE"
  | "OFFRE_SELECTIONNEE"
  | "PAIEMENT"
  | "PAIEMENT_EN_COURS"
  | "PAIEMENT_ECHOUE"
  | "EN_ATTENTE_CODE"
  | "CODE_DISPONIBLE"
  | "OTP"
  | "CODE_AFFICHE";

/** Offre telle qu'affichée par l'interface (construite à partir de l'API). */
export type Plan = {
  id: string;
  name: string;
  /** Prix tout compris de la 1re année (FCFA), payable en 3 tranches ; null = sur devis. */
  prixParticulier: number | null;
  prixEntreprise: number | null;
  /** Abonnement annuel dès l'année 2 (FCFA). */
  renewalPrice: number | null;
  /** false = offre sur devis : « Demander un devis » au lieu du paiement en ligne. */
  payable: boolean;
  camerasMax: number;
  features: string[];
  support: string;
  recommended?: boolean;
  /** true = « Intégration » : sur les caméras existantes du client. */
  equipped?: boolean;
};

/** Le prix de la 1re année se règle en 3 tranches (une par quadrimestre). */
export const TRANCHES = 3;

export function trancheAmount(total: number, numero: number): number {
  const base = Math.floor(total / TRANCHES);
  return numero === TRANCHES ? total - base * (TRANCHES - 1) : base;
}

export function planPrice(plan: Plan, clientType: ClientType): number | null {
  return clientType === "entreprise" ? plan.prixEntreprise : plan.prixParticulier;
}

export function formatFcfa(amount: number): string {
  return new Intl.NumberFormat("fr-FR").format(amount).replace(/[  ]/g, " ");
}

export function durationLabel(months: number): string {
  if (months === 12) return "1 an";
  return `${months} mois`;
}

export function planFromApi(p: PlanApi): Plan {
  const payable = p.payable_en_ligne && p.prix_particulier !== null && p.prix_entreprise !== null;
  return {
    id: p.id,
    name: p.nom,
    prixParticulier: p.prix_particulier,
    prixEntreprise: p.prix_entreprise,
    renewalPrice: p.prix_renouvellement,
    payable,
    camerasMax: p.cameras_max,
    features: p.options,
    support: p.support,
    recommended: p.recommande,
    equipped: p.logiciel_seul,
  };
}

/** Date lisible en français à partir d'une date ISO. */
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "long", year: "numeric" }).format(new Date(iso));
}

export type PaymentMethodId = "mobile-money" | "carte";

export type MobileNetworkId = "orange" | "mtn" | "moov" | "wave";

export const MOBILE_NETWORKS: { id: MobileNetworkId; label: string; color: string; text?: string }[] = [
  { id: "orange", label: "Orange Money", color: "#FF6600" },
  { id: "mtn", label: "MTN MoMo", color: "#FFCB05", text: "#151515" },
  { id: "moov", label: "Moov Money", color: "#0057B8" },
  { id: "wave", label: "Wave", color: "#1DC8DE" },
];

export type CountryCode = {
  id: string;
  name: string;
  dial: string;
  flag: string;
};

export const COUNTRY_CODES: CountryCode[] = [
  { id: "bf", name: "Burkina Faso", dial: "+226", flag: "🇧🇫" },
  { id: "ci", name: "Côte d'Ivoire", dial: "+225", flag: "🇨🇮" },
  { id: "ml", name: "Mali", dial: "+223", flag: "🇲🇱" },
  { id: "ne", name: "Niger", dial: "+227", flag: "🇳🇪" },
  { id: "gh", name: "Ghana", dial: "+233", flag: "🇬🇭" },
  { id: "sn", name: "Sénégal", dial: "+221", flag: "🇸🇳" },
  { id: "fr", name: "France", dial: "+33", flag: "🇫🇷" },
];

/**
 * Opérateurs Mobile Money réellement disponibles par pays (couverture
 * Orange Money / MTN MoMo / Moov Money / Wave en Afrique de l'Ouest).
 */
export const COUNTRY_NETWORKS: Record<string, MobileNetworkId[]> = {
  bf: ["orange", "moov", "wave"],
  ci: ["orange", "mtn", "moov", "wave"],
  ml: ["orange", "moov", "wave"],
  ne: ["orange", "moov"],
  gh: ["mtn"],
  sn: ["orange", "wave"],
  fr: [],
};

export type ClientType = "particulier" | "entreprise";

/** Détails de paiement saisis dans le formulaire (jamais conservés côté site après l'envoi). */
export type PaymentDetails = {
  operateur?: MobileNetworkId;
  /** Numéro complet avec indicatif, ex. « +226 70 00 00 01 ». */
  telephone?: string;
  /** Numéro de carte, transmis une seule fois à l'API (le CVV n'est jamais envoyé). */
  carteNumero?: string;
};

/** Données affichées dans le reçu PDF (disponible après OTP uniquement, R37). */
export type ReceiptData = {
  reference: string;
  planName: string;
  cameras: string;
  duration: string;
  amount: string;
  statut: string;
  date: string;
  code: string;
  expiration?: string;
  clientName: string;
  clientEmail: string;
};
