import { formatFcfa, type Plan } from "./types";

/** Prix de l'offre (particuliers / entreprises), au format de la diapositive « Modèle économique ». */
export function PlanPriceBadge({ plan }: { plan: Plan }) {
  if (!plan.payable) {
    return (
      <div className="es-plan-price-badge es-plan-price-badge--dual">
        <span className="es-plan-price es-plan-price--sm">Sur devis</span>
      </div>
    );
  }
  const cols = [
    { label: "Particuliers", value: plan.prixParticulier },
    { label: "Entreprises", value: plan.prixEntreprise },
  ];
  return (
    <div className="es-plan-price-badge es-plan-price-badge--dual">
      {cols.map((c) => (
        <div key={c.label} className="es-plan-price-col">
          <span className="es-plan-price-label">{c.label}</span>
          <span className="es-plan-price">
            {formatFcfa(c.value as number)} <small>FCFA</small>
          </span>
        </div>
      ))}
    </div>
  );
}

const TRANCHE_LABELS = ["Premier quadrimestre", "Prochain quadrimestre", "Dernier quadrimestre"];

/** Bandeau « Paiement en 3 tranches » + tarif annuel dès l'année 2. */
export function PaymentBand({ renewalPrice }: { renewalPrice: number | null }) {
  return (
    <div className="es-pay-band">
      <p className="es-pay-band-title">
        Paiement
        <br />
        en 3 tranches
      </p>
      <ol className="es-pay-band-steps">
        {TRANCHE_LABELS.map((label, i) => (
          <li key={label}>
            <span className="es-pay-band-pill">{i + 1}/3</span>
            <span className="es-pay-band-label">{label}</span>
          </li>
        ))}
      </ol>
      {renewalPrice !== null && (
        <p className="es-pay-band-renew">
          <span>Dès l&apos;année 2</span>
          <strong>{formatFcfa(renewalPrice)} FCFA / an</strong>
        </p>
      )}
    </div>
  );
}
