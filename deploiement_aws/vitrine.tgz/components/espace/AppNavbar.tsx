"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import Logo from "@/components/home/Logo";
import ThemeToggle from "@/components/home/ThemeToggle";
import LangSwitch from "@/components/home/LangSwitch";
import AccountMenu from "@/components/home/AccountMenu";
import EditProfileModal from "@/components/home/EditProfileModal";
import NotificationMenu from "@/components/home/NotificationMenu";
import { SITE_LINKS } from "@/components/home/navLinks";
import { IconMenu, IconClose, IconLogOut, IconEdit } from "@/components/home/icons";
import { clearAuthUser } from "@/lib/auth";
import { useEspace } from "./EspaceContext";

export default function AppNavbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const pathname = usePathname();
  const { user, notifications, markAllRead, markRead } = useEspace();


  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Se déconnecter ne redirige jamais : /code-amorcage bascule automatiquement
  // côté public dès que l'utilisateur n'est plus authentifié.
  const handleLogout = () => clearAuthUser();

  return (
    <header className={`nav ${scrolled ? "scrolled" : ""}`}>
      <div className="container">
        <motion.div
          className="nav-pill"
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="nav-row">
            <Link href="/" className="nav-logo" aria-label="Previa — accueil">
              <Logo height={28} />
            </Link>

            <nav className="nav-desktop-only">
              <ul className="nav-links">
                {SITE_LINKS.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className={`nav-link ${pathname === l.href ? "is-active" : ""}`}
                      aria-current={pathname === l.href ? "page" : undefined}
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>

            <div className="nav-actions">
              <span className="nav-desktop-only">
                <LangSwitch />
              </span>
              <ThemeToggle />

              <NotificationMenu
                items={notifications}
                userEmail={user.email}
                onMarkAllRead={markAllRead}
                onMarkRead={markRead}
              />

              <span className="nav-desktop-only">
                <AccountMenu user={user} onLogout={handleLogout} />
              </span>

              <button
                className="icon-btn hamburger"
                aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
                aria-expanded={open}
                onClick={() => setOpen((v) => !v)}
              >
                {open ? <IconClose width={20} height={20} /> : <IconMenu width={20} height={20} />}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {open && (
              <motion.div
                className="mobile-menu"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              >
                <div className="mobile-menu-inner">
                  {SITE_LINKS.map((l) => (
                    <Link
                      key={l.href}
                      href={l.href}
                      className={`mobile-link ${pathname === l.href ? "is-active" : ""}`}
                      aria-current={pathname === l.href ? "page" : undefined}
                      onClick={() => setOpen(false)}
                    >
                      {l.label}
                    </Link>
                  ))}
                  <div className="mobile-actions">
                    <LangSwitch />
                  </div>
                  <div className="mobile-account">
                    <button
                      type="button"
                      className="mobile-account-edit"
                      onClick={() => {
                        setOpen(false);
                        setEditOpen(true);
                      }}
                    >
                      <IconEdit width={16} height={16} />
                      Modifier mon compte
                    </button>
                    <button type="button" className="btn btn-secondary" onClick={handleLogout}>
                      <IconLogOut width={16} height={16} />
                      Se déconnecter
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      <EditProfileModal open={editOpen} onClose={() => setEditOpen(false)} user={user} />
    </header>
  );
}
