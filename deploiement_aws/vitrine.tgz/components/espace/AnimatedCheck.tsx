"use client";

import { motion, useReducedMotion } from "motion/react";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Icône de validation animée : le cercle puis la coche se dessinent au trait. */
export default function AnimatedCheck({ size = 40, delay = 0 }: { size?: number; delay?: number }) {
  const reduce = useReducedMotion();

  return (
    <span className="es-success-check" style={{ width: size, height: size }}>
      <motion.svg
        width={size * 0.55}
        height={size * 0.55}
        viewBox="0 0 24 24"
        fill="none"
        stroke="#fff"
        strokeWidth={2.4}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <motion.circle
          cx="12"
          cy="12"
          r="10"
          strokeOpacity={0.35}
          initial={{ pathLength: reduce ? 1 : 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.5, ease: EASE, delay }}
        />
        <motion.path
          d="M7 12.5l3 3 7-7.5"
          initial={{ pathLength: reduce ? 1 : 0, opacity: reduce ? 1 : 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 0.4, ease: EASE, delay: delay + (reduce ? 0 : 0.4) }}
        />
      </motion.svg>
    </span>
  );
}
