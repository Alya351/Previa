"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import Footer from "@/components/home/Footer";
import Modal from "@/components/home/Modal";
import AppNavbar from "./AppNavbar";
import { EspaceProvider, useEspace } from "./EspaceContext";
import StageTimeline from "./StageTimeline";
import PlanSelector from "./PlanSelector";
import PaymentPanel, { type PaymentMode, type RecipientInfo } from "./PaymentPanel";
import RequestTracking from "./RequestTracking";
import OtpEntry from "./OtpEntry";
import BootstrapCode from "./BootstrapCode";
import SubscriptionSummary from "./SubscriptionSummary";
import AnimatedCheck from "./AnimatedCheck";
import {
  TRANCHES,
  durationLabel,
  formatDate,
  formatFcfa,
  planFromApi,
  planPrice,
  trancheAmount,
  type ClientType,
  type FlowState,
  type PaymentDetails,
  type PaymentMethodId,
  type Plan,
} from "./types";
import { readStoredToken } from "@/lib/auth";
import { clearPlanIntent, readPlanIntent, readPlanIntentClientType } from "@/lib/planIntent";
import { api, ApiError, type PaiementInput } from "@/lib/api";
import { IconClock, IconDownload, IconMail, IconKeyRound, IconShieldCheck, IconAlertTriangle } from "@/components/home/icons";
import { downloadBootstrapReceipt } from "./receipt";
import { buildReceipt } from "./receiptData";

const EASE = [0.22, 1, 0.36, 1] as const;

type ChoosingStep = "plan" | "pay" | "paying" | "payError";

function phaseOf(state: FlowState) {
  switch (state) {
    case "AUCUNE_DEMANDE":
    case "OFFRE_SELECTIONNEE":
      return "plan";
    case "PAIEMENT":
    case "PAIEMENT_EN_COURS":
    case "PAIEMENT_ECHOUE":
      return "payment";
    default:
      return state;
  }
}

function EspaceContent() {
  const reduce = useReducedMotion();
  const {
    user,
    plans,
    loading,
    subscription,
    canSubscribe,
    canRenew,
    refreshSubscription,
    payments,
    refreshPayments,
    refreshNotifications,
    revealed,
    setRevealed,
    historyOpen,
    setHistoryOpen,
  } = useEspace();

  // Choix de l'offre / paiement (nouvel abonnement ou renouvellement)
  const [renewing, setRenewing] = useState(false);
  const [step, setStep] = useState<ChoosingStep>("plan");
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [clientType, setClientType] = useState<ClientType>("particulier");
  // Paiement de la tranche suivante (2/3, 3/3) de la 1re année, sur l'abonnement existant.
  const [installing, setInstalling] = useState(false);
  // Paiement du reliquat entier (toutes les tranches restantes) plutôt que de la seule tranche suivante.
  const [settleAll, setSettleAll] = useState(false);
  const [payError, setPayError] = useState<string | undefined>();
  const [paymentSuccessModal, setPaymentSuccessModal] = useState(false);
  const [quotePlan, setQuotePlan] = useState<Plan | null>(null);
  const [quoteMessage, setQuoteMessage] = useState("");
  const [quoteState, setQuoteState] = useState<"idle" | "sending" | "sent">("idle");

  // Accès au code : OTP par e-mail puis lecture (R30–R36)
  const [otp, setOtp] = useState<{ expireLe: string } | null>(null);
  const [otpInfoOpen, setOtpInfoOpen] = useState(false);
  const [otpBusy, setOtpBusy] = useState(false);
  const [otpError, setOtpError] = useState<string | undefined>();
  const pendingReveal = useRef<{ code: string; expireLe: string | null } | null>(null);
  const autoOtp = useRef(false);
  // Jeton de lecture (10 min, délivré par le serveur après un OTP valide) gardé pour l'onglet courant :
  // il évite de redemander un OTP si le client quitte la page puis revient dans ce délai.
  const [restoreDone, setRestoreDone] = useState(false);

  const [verifBusy, setVerifBusy] = useState(false);
  const [verifSent, setVerifSent] = useState(false);

  const choosing = renewing || installing || !subscription || canSubscribe;
  const codeAvailable =
    !!subscription &&
    subscription.code_envoye &&
    (subscription.statut === "actif" || subscription.statut === "expire_bientot");

  let state: FlowState;
  if (choosing) {
    state =
      step === "paying"
        ? "PAIEMENT_EN_COURS"
        : step === "payError"
          ? "PAIEMENT_ECHOUE"
          : step === "pay"
            ? "PAIEMENT"
            : selectedPlan
              ? "OFFRE_SELECTIONNEE"
              : "AUCUNE_DEMANDE";
  } else if (subscription?.statut === "en_attente_code") {
    state = "EN_ATTENTE_CODE";
  } else if (revealed && codeAvailable) {
    state = "CODE_AFFICHE";
  } else if (otp && codeAvailable) {
    state = "OTP";
  } else {
    state = "CODE_DISPONIBLE";
  }

  // Tant que le code n'est pas prêt, on interroge le serveur plus souvent (le client est prévenu dès l'envoi).
  useEffect(() => {
    if (state !== "EN_ATTENTE_CODE") return;
    const id = window.setInterval(() => {
      refreshSubscription();
      refreshNotifications();
    }, 10000);
    return () => window.clearInterval(id);
  }, [state, refreshSubscription, refreshNotifications]);

  // Le lien de l'e-mail / de la notification (?otp=1) ouvre directement l'étape OTP.
  const startOtp = useCallback(async () => {
    const token = readStoredToken();
    if (!token || otpBusy) return;
    setOtpBusy(true);
    setOtpError(undefined);
    try {
      const res = await api.me.sendOtp(token);
      setOtp({ expireLe: res.expire_le });
      setOtpInfoOpen(true);
    } catch (err) {
      setOtpError(err instanceof ApiError ? err.message : "Envoi du code impossible. Réessayez.");
    } finally {
      setOtpBusy(false);
    }
  }, [otpBusy]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("otp") === "1") autoOtp.current = true;
    const onOpen = () => {
      autoOtp.current = true;
      refreshSubscription();
    };
    window.addEventListener("previa-open-otp", onOpen);
    return () => window.removeEventListener("previa-open-otp", onOpen);
  }, [refreshSubscription]);

  useEffect(() => {
    if (restoreDone || loading || !subscription) return;
    if (!codeAvailable) {
      setRestoreDone(true);
      return;
    }
    const stored = loadReadToken(user?.email);
    const token = readStoredToken();
    if (!stored || !token) {
      setRestoreDone(true);
      return;
    }
    let cancelled = false;
    api.me
      .getCode(token, stored)
      .then((res) => {
        if (!cancelled) setRevealed({ code: res.code, expireLe: res.expire_le });
      })
      .catch(() => clearReadToken())
      .finally(() => {
        if (!cancelled) setRestoreDone(true);
      });
    return () => {
      cancelled = true;
    };
  }, [restoreDone, loading, subscription, codeAvailable, user?.email]);

  useEffect(() => {
    if (!restoreDone || !autoOtp.current || loading || !codeAvailable || revealed || otp) return;
    autoOtp.current = false;
    const url = new URL(window.location.href);
    url.searchParams.delete("otp");
    window.history.replaceState({}, "", url.pathname + url.search);
    void startOtp();
  }, [restoreDone, loading, codeAvailable, revealed, otp, startOtp]);

  // Offre choisie sur la page Offres (avant connexion ou non) : on la présélectionne ; une offre
  // sur devis ouvre directement la demande de devis. Un client ayant déjà un abonnement en cours
  // retombe simplement sur son suivi (le choix est oublié). Appliqué une seule fois, dès que les
  // offres sont chargées (ajustement d'état pendant le rendu), puis effacé du stockage.
  const [intent] = useState<string | null>(() => (typeof window === "undefined" ? null : readPlanIntent()));
  const [intentClientType] = useState<ClientType | null>(() =>
    typeof window === "undefined" ? null : readPlanIntentClientType(),
  );
  const [intentDone, setIntentDone] = useState(false);
  if (intent && !intentDone && !loading && plans.length > 0) {
    setIntentDone(true);
    const wanted = choosing ? plans.find((p) => p.id === intent) : undefined;
    if (wanted) {
      if (intentClientType) setClientType(intentClientType);
      setSelectedPlan(wanted);
      setStep("plan");
      if (!wanted.payable) {
        setQuotePlan(wanted);
        setQuoteState("idle");
        setQuoteMessage("");
      }
    }
  }
  useEffect(() => {
    if (intentDone) clearPlanIntent();
  }, [intentDone]);

  // Chargement de l'historique des paiements à l'ouverture de la fenêtre.
  useEffect(() => {
    if (historyOpen) void refreshPayments();
  }, [historyOpen, refreshPayments]);

  const selectPlan = (plan: Plan) => {
    setSelectedPlan(plan);
    setStep("plan");
  };
  const editSelection = () => {
    setSelectedPlan(null);
    setStep("plan");
  };

  const startRenew = () => {
    setRenewing(true);
    setStep("plan");
    setSelectedPlan(subscription ? (plans.find((p) => p.id === subscription.plan.id && p.payable) ?? null) : null);
    setPayError(undefined);
  };
  const cancelRenew = () => {
    setRenewing(false);
    setInstalling(false);
    setSelectedPlan(null);
    setStep("plan");
  };
  const startInstallment = (solde = false) => {
    if (!subscription?.prochaine_tranche) return;
    setSettleAll(solde);
    setInstalling(true);
    setSelectedPlan(planFromApi(subscription.plan));
    setStep("pay");
    setPayError(undefined);
  };

  // Ce que le paiement en cours prélève : 1re tranche, tranche suivante ou renouvellement annuel.
  const mode: PaymentMode = installing ? "installment" : renewing ? "renew" : "checkout";
  let payAmount = 0;
  let payCaption = "";
  if (selectedPlan) {
    if (mode === "installment" && subscription?.prochaine_tranche) {
      if (settleAll) {
        payAmount = subscription.reliquat ?? subscription.prochaine_tranche.montant;
        payCaption = "solde de la 1re année";
      } else {
        payAmount = subscription.prochaine_tranche.montant;
        payCaption = `tranche ${subscription.prochaine_tranche.numero}/${TRANCHES}`;
      }
    } else if (mode === "renew") {
      const reliquat = subscription?.prochaine_tranche ? (subscription.reliquat ?? 0) : 0;
      payAmount = (selectedPlan.renewalPrice ?? 0) + reliquat;
      payCaption = reliquat > 0 ? "solde de la 1re année + abonnement annuel" : "abonnement annuel";
    } else {
      const total = planPrice(selectedPlan, clientType) ?? 0;
      payAmount = trancheAmount(total, 1);
      payCaption = `tranche 1/${TRANCHES} sur ${formatFcfa(total)} FCFA`;
    }
  }

  const pay = async (method: PaymentMethodId, recipient: RecipientInfo, details: PaymentDetails) => {
    const token = readStoredToken();
    if (!token || !selectedPlan) return;
    setStep("paying");
    setPayError(undefined);

    const paiement: PaiementInput =
      method === "mobile-money"
        ? { moyen: "mobile_money", operateur: details.operateur, telephone: details.telephone }
        : { moyen: "carte", carte_numero: details.carteNumero };

    try {
      if (installing) {
        await api.me.payInstallment(token, { paiement, solde: settleAll });
      } else if (renewing) {
        await api.me.renew(token, {
          plan_id: selectedPlan.id,
          paiement,
          solder_reliquat: !!subscription?.prochaine_tranche,
        });
      } else {
        await api.me.checkout(token, {
          plan_id: selectedPlan.id,
          paiement,
          destinataire_nom: `${recipient.recipientFirstName} ${recipient.recipientLastName}`.trim(),
          destinataire_email: recipient.recipientEmail,
          type_client: clientType,
          entreprise: recipient.entrepriseName,
        });
      }
      await Promise.all([refreshSubscription(), refreshPayments(), refreshNotifications()]);
      setPaymentSuccessModal(true);
      window.setTimeout(() => setPaymentSuccessModal(false), 1700);
      const wasInstalling = installing;
      setRenewing(false);
      setInstalling(false);
      setSettleAll(false);
      setSelectedPlan(null);
      setStep("plan");
      if (!wasInstalling) {
        setRevealed(null);
        setOtp(null);
      }
    } catch (err) {
      setPayError(err instanceof ApiError ? err.message : "Le paiement a échoué. Vérifiez vos informations et réessayez.");
      setStep("payError");
    }
  };

  const sendQuote = async () => {
    const token = readStoredToken();
    if (!token || !quotePlan) return;
    setQuoteState("sending");
    try {
      await api.me.quote(token, { plan_id: quotePlan.id, message: quoteMessage });
      setQuoteState("sent");
    } catch {
      setQuoteState("idle");
    }
  };

  const resendVerification = async () => {
    const token = readStoredToken();
    if (!token || verifBusy) return;
    setVerifBusy(true);
    try {
      await api.auth.resendVerification(token);
      setVerifSent(true);
    } finally {
      setVerifBusy(false);
    }
  };

  // OTP → jeton de lecture → code (mis en mémoire seulement à la fin de l'animation de succès).
  const verifyOtp = async (code: string) => {
    const token = readStoredToken();
    if (!token) throw new ApiError("Session expirée. Veuillez vous reconnecter.", 401);
    const { read_token, expire_le } = await api.me.verifyOtp(token, code);
    saveReadToken(read_token, expire_le, user?.email);
    const res = await api.me.getCode(token, read_token);
    pendingReveal.current = { code: res.code, expireLe: res.expire_le };
  };

  const resendOtp = async () => {
    const token = readStoredToken();
    if (!token) return;
    const res = await api.me.sendOtp(token);
    setOtp({ expireLe: res.expire_le });
    setOtpInfoOpen(true);
  };

  const otpVerified = () => {
    if (pendingReveal.current) setRevealed(pendingReveal.current);
    pendingReveal.current = null;
    setOtp(null);
  };

  const downloadReceipt = () => {
    if (revealed && subscription) {
      downloadBootstrapReceipt(buildReceipt(user, subscription, payments, revealed.code, revealed.expireLe));
    }
  };

  const planName = (id: string) => plans.find((p) => p.id === id)?.name ?? id;

  return (
    <main className="es-main">
      <section className="es-intro section">
        <div className="container es-intro-container">
          <motion.span
            className="eyebrow"
            initial={{ opacity: 0, y: reduce ? 0 : 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Code d&apos;activation
          </motion.span>
          <motion.h1
            className="h2 es-intro-title"
            initial={{ opacity: 0, y: reduce ? 0 : 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.06 }}
          >
            Activez votre environnement Previa
          </motion.h1>
          <motion.p
            className="lead"
            initial={{ opacity: 0, y: reduce ? 0 : 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.12 }}
          >
            Choisissez votre offre, effectuez votre paiement et suivez chaque étape jusqu&apos;à la réception de
            votre code d&apos;activation.
          </motion.p>

          <motion.div
            style={{ width: "100%" }}
            initial={{ opacity: 0, y: reduce ? 0 : 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.18 }}
          >
            <StageTimeline state={state} />
          </motion.div>
        </div>
      </section>

      <section className="es-content section">
        <div className="container es-content-container">
          {!user.emailVerified && (
            <div className="es-verify-banner" role="status">
              <IconMail width={18} height={18} />
              <p>
                <strong>Confirmez votre adresse e-mail</strong> pour pouvoir souscrire un abonnement : un lien vous a
                été envoyé à l&apos;inscription.
              </p>
              <button type="button" className="btn btn-secondary" onClick={resendVerification} disabled={verifBusy || verifSent}>
                {verifSent ? "E-mail renvoyé ✓" : "Renvoyer l'e-mail"}
              </button>
            </div>
          )}

          {loading ? (
            <p className="es-recap-label" style={{ textAlign: "center" }}>
              Chargement…
            </p>
          ) : (
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={phaseOf(state)}
                initial={{ opacity: 0, y: reduce ? 0 : 22, scale: reduce ? 1 : 0.97, filter: reduce ? "none" : "blur(6px)" }}
                animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: reduce ? 0 : -14, scale: reduce ? 1 : 0.98, filter: reduce ? "none" : "blur(4px)" }}
                transition={{ duration: 0.45, ease: EASE }}
              >
                {(state === "AUCUNE_DEMANDE" || state === "OFFRE_SELECTIONNEE") && (
                  <>
                    {renewing && (
                      <button type="button" className="au-link es-back-link" onClick={cancelRenew}>
                        ← Retour à mon abonnement
                      </button>
                    )}
                    <PlanSelector
                      plans={plans}
                      selected={selectedPlan}
                      clientType={clientType}
                      renewing={renewing}
                      renewalExtra={subscription?.prochaine_tranche ? (subscription.reliquat ?? 0) : 0}
                      onClientType={setClientType}
                      onSelect={selectPlan}
                      onEdit={editSelection}
                      onContinue={() => setStep("pay")}
                      onQuote={(p) => {
                        setQuotePlan(p);
                        setQuoteState("idle");
                        setQuoteMessage("");
                      }}
                    />
                  </>
                )}

                {(state === "PAIEMENT" || state === "PAIEMENT_EN_COURS" || state === "PAIEMENT_ECHOUE") && selectedPlan && (
                  <>
                    {(installing || renewing) && state !== "PAIEMENT_EN_COURS" && (
                      <button type="button" className="au-link es-back-link" onClick={cancelRenew}>
                        ← Retour à mon abonnement
                      </button>
                    )}
                  <PaymentPanel
                    plan={selectedPlan}
                    mode={mode}
                    clientType={clientType}
                    amount={payAmount}
                    caption={payCaption}
                    status={state === "PAIEMENT_EN_COURS" ? "loading" : state === "PAIEMENT_ECHOUE" ? "error" : "idle"}
                    errorMessage={payError}
                    onPay={(m, r, d) => {
                      if (state === "PAIEMENT_ECHOUE") setStep("pay");
                      else void pay(m, r, d);
                    }}
                  />
                  </>
                )}

                {state === "EN_ATTENTE_CODE" && subscription && (
                  <>
                    <RequestTracking subscription={subscription} />
                    <SubscriptionSummary subscription={subscription} onPayInstallment={startInstallment} />
                  </>
                )}

                {state === "CODE_DISPONIBLE" && subscription && (
                  <div className="es-block">
                    {codeAvailable ? (
                      <div className="es-success-card">
                        <span className="es-code-icon">
                          <IconKeyRound width={22} height={22} />
                        </span>
                        <div>
                          <p className="es-success-title">Votre code d&apos;activation est disponible</p>
                          <p className="es-success-text">
                            Pour votre sécurité, un code de vérification (OTP) vous sera envoyé par e-mail avant
                            l&apos;affichage du code.
                          </p>
                          {otpError && <p className="es-otp-error">{otpError}</p>}
                          <button
                            type="button"
                            className="btn btn-primary es-activate-btn"
                            onClick={startOtp}
                            disabled={otpBusy}
                          >
                            {otpBusy ? "Envoi du code…" : "Consulter mon code"}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="es-refused-card">
                        <p className="es-refused-title">
                          <IconAlertTriangle width={16} height={16} />
                          {subscription.statut === "suspendu"
                            ? "Abonnement suspendu"
                            : subscription.statut === "expire"
                              ? "Abonnement expiré"
                              : "Abonnement terminé"}
                        </p>
                        <p className="es-refused-reason">
                          {subscription.statut === "suspendu"
                            ? "Votre abonnement est suspendu. Contactez l'équipe Previa pour le réactiver."
                            : subscription.statut === "expire"
                              ? "Votre abonnement est arrivé à échéance. Renouvelez-le pour continuer à utiliser Previa."
                              : "Votre abonnement est terminé."}
                        </p>
                      </div>
                    )}
                    <SubscriptionSummary
                      subscription={subscription}
                      onRenew={canRenew ? startRenew : undefined}
                      onPayInstallment={startInstallment}
                    />
                  </div>
                )}

                {state === "OTP" && subscription && otp && (
                  <div className="es-block">
                    <OtpEntry
                      email={user.email}
                      expireLe={otp.expireLe}
                      onVerify={verifyOtp}
                      onResend={resendOtp}
                      onVerified={otpVerified}
                    />
                    <SubscriptionSummary subscription={subscription} onPayInstallment={startInstallment} />
                  </div>
                )}

                {state === "CODE_AFFICHE" && subscription && revealed && (
                  <>
                    <BootstrapCode
                      code={revealed.code}
                      subscription={subscription}
                      expireLe={revealed.expireLe}
                      onReceipt={downloadReceipt}
                    />
                    <SubscriptionSummary
                      subscription={subscription}
                      onRenew={canRenew ? startRenew : undefined}
                      onPayInstallment={startInstallment}
                    />
                  </>
                )}
              </motion.div>
            </AnimatePresence>
          )}

          {!loading && subscription && (
            <div className="es-tools">
              <div className="es-tool-card">
                <span className="es-tool-icon">
                  <IconDownload width={20} height={20} />
                </span>
                <div className="es-tool-body">
                  <p className="es-tool-title">Reçu PDF</p>
                  <p className="es-tool-text">
                    {revealed
                      ? "Téléchargez le reçu de votre code d'activation."
                      : "Disponible une fois votre code affiché (vérification par OTP)."}
                  </p>
                </div>
                <button type="button" className="btn btn-secondary" disabled={!revealed} onClick={downloadReceipt}>
                  Télécharger
                </button>
              </div>

              <div className="es-tool-card">
                <span className="es-tool-icon">
                  <IconClock width={20} height={20} />
                </span>
                <div className="es-tool-body">
                  <p className="es-tool-title">Historique</p>
                  <p className="es-tool-text">Consultez tous vos paiements et leur statut.</p>
                </div>
                <button type="button" className="btn btn-secondary" onClick={() => setHistoryOpen(true)}>
                  Consulter
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      <Modal
        open={paymentSuccessModal}
        onClose={() => setPaymentSuccessModal(false)}
        title="Confirmation réussie"
        subtitle="Votre paiement a été confirmé avec succès."
        maxWidth={340}
      >
        <div style={{ display: "flex", justifyContent: "center", padding: "6px 0 2px" }}>
          <AnimatedCheck size={56} />
        </div>
      </Modal>

      <Modal
        open={otpInfoOpen}
        onClose={() => setOtpInfoOpen(false)}
        icon={<IconMail width={20} height={20} />}
        title="Code de vérification envoyé"
        subtitle={`Un code à 6 chiffres vient d'être envoyé à ${user.email}. Il est valable 10 minutes : saisissez-le avant son expiration.`}
        maxWidth={400}
      >
        <button type="button" className="btn btn-primary" onClick={() => setOtpInfoOpen(false)}>
          J&apos;ai compris
        </button>
      </Modal>

      <Modal
        open={!!quotePlan}
        onClose={() => setQuotePlan(null)}
        icon={<IconShieldCheck width={20} height={20} />}
        title="Demander un devis"
        subtitle={
          quoteState === "sent"
            ? "Votre demande a bien été transmise. L'équipe Previa vous répondra rapidement."
            : `L'offre ${quotePlan?.name ?? ""} est sur devis : décrivez votre besoin, nous vous recontactons.`
        }
        maxWidth={440}
      >
        {quoteState === "sent" ? (
          <button type="button" className="btn btn-primary" onClick={() => setQuotePlan(null)}>
            Fermer
          </button>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <textarea
              className="es-input"
              rows={4}
              placeholder="Votre message"
              value={quoteMessage}
              onChange={(e) => setQuoteMessage(e.target.value)}
            />
            <div className="pv-modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setQuotePlan(null)}>
                Annuler
              </button>
              <button type="button" className="btn btn-primary" onClick={sendQuote} disabled={quoteState === "sending"}>
                {quoteState === "sending" ? "Envoi..." : "Envoyer ma demande"}
              </button>
            </div>
          </div>
        )}
      </Modal>

      <Modal
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        icon={<IconClock width={20} height={20} />}
        title="Historique des demandes"
        subtitle="Vos paiements et périodes d'abonnement."
        maxWidth={460}
      >
        {payments.length === 0 && subscription === null ? (
          <p className="es-recap-label">Aucune demande pour l&apos;instant.</p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 14, maxHeight: 360, overflowY: "auto" }}>
            {payments.map((p, i) => (
              <div
                key={p.id}
                style={{ borderBottom: i < payments.length - 1 ? "1px solid var(--border-soft)" : "none", paddingBottom: 14 }}
              >
                <dl className="es-summary-list" style={{ margin: 0 }}>
                  <div>
                    <dt>Référence</dt>
                    <dd data-no-translate>{p.reference}</dd>
                  </div>
                  <div>
                    <dt>Abonnement</dt>
                    <dd>{planName(p.plan_id)}</dd>
                  </div>
                  <div>
                    <dt>Paiement</dt>
                    <dd>
                      {p.tranche
                        ? `Tranche ${p.tranche}/${TRANCHES}`
                        : `Abonnement annuel (${durationLabel(p.duree_mois)})`}
                    </dd>
                  </div>
                  <div>
                    <dt>Montant</dt>
                    <dd>{formatFcfa(p.montant)} FCFA</dd>
                  </div>
                  <div>
                    <dt>Date</dt>
                    <dd>{formatDate(p.date)}</dd>
                  </div>
                  <div>
                    <dt>Statut</dt>
                    <dd>{p.statut === "reussi" ? "Paiement confirmé" : "Paiement échoué"}</dd>
                  </div>
                </dl>
              </div>
            ))}
            {revealed && subscription && (
              <button type="button" className="btn btn-secondary" style={{ width: "100%" }} onClick={downloadReceipt}>
                Télécharger le reçu (PDF)
              </button>
            )}
          </div>
        )}
      </Modal>
    </main>
  );
}

const READ_TOKEN_KEY = "previa_read_token";

function saveReadToken(token: string, expireLe: string, email?: string) {
  try {
    window.sessionStorage.setItem(READ_TOKEN_KEY, JSON.stringify({ token, exp: Date.parse(expireLe), email }));
  } catch {}
}

function clearReadToken() {
  try {
    window.sessionStorage.removeItem(READ_TOKEN_KEY);
  } catch {}
}

function loadReadToken(email?: string): string | null {
  try {
    const raw = window.sessionStorage.getItem(READ_TOKEN_KEY);
    if (!raw) return null;
    const v = JSON.parse(raw) as { token?: string; exp?: number; email?: string };
    if (!v.token || !v.exp || v.exp <= Date.now() + 5000 || v.email !== email) {
      clearReadToken();
      return null;
    }
    return v.token;
  } catch {
    return null;
  }
}

export default function EspaceCodeAmorcagePage() {
  return (
    <EspaceProvider>
      <AppNavbar />
      <EspaceContent />
      <Footer />
    </EspaceProvider>
  );
}
