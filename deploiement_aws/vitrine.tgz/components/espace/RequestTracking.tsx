"use client";

import { useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import { IconCopy, IconShieldCheck } from "@/components/home/icons";
import AnimatedCheck from "./AnimatedCheck";
import type { AbonnementApi } from "@/lib/api";
import { TRANCHES, formatDate, formatFcfa, trancheAmount } from "./types";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Suivi après paiement : le code est en préparation chez Previa (abonnement « en attente du code »). */
export default function RequestTracking({ subscription }: { subscription: AbonnementApi }) {
  const reduce = useReducedMotion();
  const [copied, setCopied] = useState(false);
  const total = subscription.prix_total ?? null;

  const copyRef = async () => {
    try {
      await navigator.clipboard.writeText(subscription.reference);
    } catch {}
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      className="es-block"
      initial={{ opacity: 0, y: reduce ? 0 : 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: EASE }}
    >
      <motion.div
        className="es-success-card"
        initial={{ opacity: 0, scale: reduce ? 1 : 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: EASE }}
      >
        <AnimatedCheck />
        <div>
          <p className="es-success-title">Paiement confirmé</p>
          <p className="es-success-text">
            Votre paiement a bien été enregistré. Votre demande de code d&apos;activation a été créée et transmise à
            l&apos;équipe Previa.
          </p>
        </div>
      </motion.div>

      <div className="es-ref-card">
        <div>
          <span className="es-ref-label">Référence de demande</span>
          <span className="es-ref-value" data-no-translate>
            {subscription.reference}
          </span>
        </div>
        <button type="button" className="btn btn-secondary es-ref-copy" onClick={copyRef}>
          <IconCopy width={15} height={15} />
          {copied ? "Copié ✓" : "Copier la référence"}
        </button>
      </div>

      <div className="es-ref-meta">
        <div>
          <span className="es-recap-label">Offre</span>
          <span className="es-recap-value">{subscription.plan.nom}</span>
        </div>
        <div>
          <span className="es-recap-label">Montant</span>
          <span className="es-recap-value">
            {total !== null
              ? `${formatFcfa(trancheAmount(total, 1))} FCFA · tranche 1/${TRANCHES} sur ${formatFcfa(total)} FCFA`
              : "—"}
          </span>
        </div>
        <div>
          <span className="es-recap-label">Date</span>
          <span className="es-recap-value">{formatDate(subscription.cree_le)}</span>
        </div>
        <div>
          <span className="es-recap-label">Statut</span>
          <span className="es-status-pill es-status-pill--pending">En attente du code</span>
        </div>
      </div>

      <motion.div
        className="es-pending"
        initial={{ opacity: 0, y: reduce ? 0 : 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: EASE, delay: 0.1 }}
      >
        <span className="es-pending-icon-wrap">
          <motion.span
            className="es-pending-ring"
            animate={reduce ? undefined : { rotate: 360 }}
            transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
          />
          <span className="es-pending-icon">
            <IconShieldCheck width={22} height={22} />
          </span>
        </span>
        <p className="es-success-title">Votre code d&apos;activation est en préparation</p>
        <p className="es-success-text es-pending-text">
          L&apos;équipe Previa prépare votre code d&apos;activation. Vous serez prévenu par e-mail et dans l&apos;application
          dès qu&apos;il sera disponible.
        </p>
        <div className="es-pending-dots" aria-hidden>
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              animate={reduce ? undefined : { y: [0, -6, 0], opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut", delay: i * 0.15 }}
            />
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}
