import type { MobileNetworkId } from "./types";

/** Logos officiels des opérateurs Mobile Money, fournis dans /public. */
export const MOBILE_MONEY_LOGO_SRC: Record<MobileNetworkId, string> = {
  orange: "/orange-money.jpg",
  mtn: "/MTN-MoMo.png",
  moov: "/moov-money.png",
  wave: "/wave.jpg",
};
