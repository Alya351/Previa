"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useAuthUser, readStoredToken, type AuthUser } from "@/lib/auth";
import { api, type AbonnementApi, type NotificationApi, type PaiementApi } from "@/lib/api";
import { formatDate, planFromApi, type Plan } from "./types";

export type NotificationKind = "info" | "success" | "danger";

export type EspaceNotification = {
  id: string;
  type: string;
  at: string;
  kind: NotificationKind;
  title: string;
  text: string;
  date: string;
  read: boolean;
  link: string | null;
};

function mapNotification(n: NotificationApi): EspaceNotification {
  const kind: NotificationKind =
    n.type === "code_disponible" ? "success" : n.titre.toLowerCase().includes("expir") ? "danger" : "info";
  return { id: n.id, type: n.type, at: n.date, kind, title: n.titre, text: n.texte, date: formatDate(n.date), read: n.lue, link: n.lien };
}

/** Code d'activation affiché : conservé UNIQUEMENT en mémoire de la page (R36). */
export type RevealedCode = { code: string; expireLe: string | null };

type EspaceContextValue = {
  user: AuthUser & { emailVerified: boolean };
  plans: Plan[];
  loading: boolean;
  subscription: AbonnementApi | null;
  canSubscribe: boolean;
  canRenew: boolean;
  refreshSubscription: () => Promise<void>;
  payments: PaiementApi[];
  refreshPayments: () => Promise<void>;
  notifications: EspaceNotification[];
  unreadCount: number;
  markAllRead: () => void;
  markRead: (id: string) => void;
  refreshNotifications: () => Promise<void>;
  revealed: RevealedCode | null;
  setRevealed: (r: RevealedCode | null) => void;
  historyOpen: boolean;
  setHistoryOpen: (open: boolean) => void;
};

const EspaceContext = createContext<EspaceContextValue | null>(null);

export function EspaceProvider({ children }: { children: ReactNode }) {
  const authUser = useAuthUser();
  const [emailVerified, setEmailVerified] = useState(true);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState<AbonnementApi | null>(null);
  const [canSubscribe, setCanSubscribe] = useState(true);
  const [canRenew, setCanRenew] = useState(false);
  const [payments, setPayments] = useState<PaiementApi[]>([]);
  const [notifications, setNotifications] = useState<EspaceNotification[]>([]);
  const [revealed, setRevealed] = useState<RevealedCode | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const refreshSubscription = useCallback(async () => {
    const token = readStoredToken();
    if (!token) return;
    try {
      const res = await api.me.getSubscription(token);
      if (!mounted.current) return;
      setSubscription(res.abonnement);
      setCanSubscribe(res.peut_souscrire);
      setCanRenew(res.peut_renouveler);
    } catch (err) {
      console.error("Erreur de chargement de l'abonnement :", err);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, []);

  const refreshPayments = useCallback(async () => {
    const token = readStoredToken();
    if (!token) return;
    try {
      const list = await api.me.payments(token);
      if (mounted.current) setPayments(list);
    } catch (err) {
      console.error("Erreur de chargement des paiements :", err);
    }
  }, []);

  const refreshNotifications = useCallback(async () => {
    const token = readStoredToken();
    if (!token) return;
    try {
      const res = await api.me.notifications(token);
      if (mounted.current) setNotifications(res.notifications.map(mapNotification));
    } catch {
      /* silencieux : les notifications se rechargent au prochain cycle */
    }
  }, []);

  // Chargement initial : offres, abonnement, e-mail confirmé, notifications.
  useEffect(() => {
    api.plans().then((list) => mounted.current && setPlans(list.map(planFromApi))).catch(() => {});
    refreshSubscription();
    refreshNotifications();
    const token = readStoredToken();
    if (token) {
      api.auth
        .getMe(token)
        .then((me) => mounted.current && setEmailVerified(me.email_verifie !== false))
        .catch(() => {});
    }
  }, [refreshSubscription, refreshNotifications]);

  // Rafraîchissement régulier : le client voit apparaître ses notifications (code disponible…) sans recharger.
  useEffect(() => {
    const id = window.setInterval(() => {
      refreshNotifications();
      refreshSubscription();
    }, 30000);
    return () => window.clearInterval(id);
  }, [refreshNotifications, refreshSubscription]);

  const markAllRead = useCallback(() => {
    const token = readStoredToken();
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    if (token) api.me.readAllNotifications(token).catch(() => {});
  }, []);

  const markRead = useCallback((id: string) => {
    const token = readStoredToken();
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    if (token) api.me.readNotification(token, id).catch(() => {});
  }, []);

  const user = useMemo(
    () => ({
      ...(authUser ?? { name: "", email: "" }),
      emailVerified,
    }),
    [authUser, emailVerified]
  );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const value = useMemo<EspaceContextValue>(
    () => ({
      user,
      plans,
      loading,
      subscription,
      canSubscribe,
      canRenew,
      refreshSubscription,
      payments,
      refreshPayments,
      notifications,
      unreadCount,
      markAllRead,
      markRead,
      refreshNotifications,
      revealed,
      setRevealed,
      historyOpen,
      setHistoryOpen,
    }),
    [
      user,
      plans,
      loading,
      subscription,
      canSubscribe,
      canRenew,
      refreshSubscription,
      payments,
      refreshPayments,
      notifications,
      unreadCount,
      markAllRead,
      markRead,
      refreshNotifications,
      revealed,
      historyOpen,
    ]
  );

  return <EspaceContext.Provider value={value}>{children}</EspaceContext.Provider>;
}

export function useEspace() {
  const ctx = useContext(EspaceContext);
  if (!ctx) throw new Error("useEspace must be used within EspaceProvider");
  return ctx;
}
