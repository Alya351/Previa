"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import AnimatedCheck from "./AnimatedCheck";
import SquareTimer from "./SquareTimer";
import { ApiError } from "@/lib/api";

const EASE = [0.22, 1, 0.36, 1] as const;
const CODE_LENGTH = 6;
const RESEND_SECONDS = 30;

function formatDuration(totalSeconds: number) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function secondsUntil(iso: string) {
  return Math.max(0, Math.ceil((new Date(iso).getTime() - Date.now()) / 1000));
}

/**
 * Saisie du code de vérification (OTP) reçu par e-mail. Le compteur suit l'heure d'expiration
 * fournie par le serveur (R32) ; les essais et le verrouillage sont contrôlés côté serveur (R33).
 */
export default function OtpEntry({
  email,
  expireLe,
  onVerify,
  onResend,
  onVerified,
}: {
  email: string;
  /** Heure d'expiration de l'OTP en cours (ISO, donnée par le serveur). */
  expireLe: string;
  onVerify: (otp: string) => Promise<void>;
  onResend: () => Promise<void>;
  onVerified: () => void;
}) {
  const reduce = useReducedMotion();
  const [values, setValues] = useState<string[]>(Array(CODE_LENGTH).fill(""));
  const [status, setStatus] = useState<"idle" | "checking" | "error" | "success">("idle");
  const [error, setError] = useState<string | undefined>();
  const [remaining, setRemaining] = useState(() => secondsUntil(expireLe));
  const [resendIn, setResendIn] = useState(RESEND_SECONDS);
  const [lockedFor, setLockedFor] = useState(0);
  const [resending, setResending] = useState(false);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);
  const locked = lockedFor > 0;
  const expired = remaining <= 0;

  // Nouveau code envoyé : on repart sur la nouvelle échéance.
  useEffect(() => {
    setRemaining(secondsUntil(expireLe));
    setValues(Array(CODE_LENGTH).fill(""));
    setStatus("idle");
    setError(undefined);
    setResendIn(RESEND_SECONDS);
  }, [expireLe]);

  useEffect(() => {
    const t = window.setInterval(() => {
      setRemaining(secondsUntil(expireLe));
      setResendIn((c) => Math.max(0, c - 1));
      setLockedFor((c) => Math.max(0, c - 1));
    }, 1000);
    return () => window.clearInterval(t);
  }, [expireLe]);

  const verify = async (entered: string) => {
    if (locked || expired || status === "checking") return;
    setStatus("checking");
    setError(undefined);
    try {
      await onVerify(entered);
      setStatus("success");
      window.setTimeout(onVerified, 900);
    } catch (err) {
      setStatus("error");
      if (err instanceof ApiError) {
        if (err.status === 423 && err.retryAfter) setLockedFor(err.retryAfter);
        setError(err.message);
      } else {
        setError("Vérification impossible. Réessayez.");
      }
      setValues(Array(CODE_LENGTH).fill(""));
      inputsRef.current[0]?.focus();
    }
  };

  const handleChange = (index: number, raw: string) => {
    if (locked || expired) return;
    const digit = raw.replace(/\D/g, "").slice(-1);
    const next = [...values];
    next[index] = digit;
    setValues(next);
    if (status === "error") setStatus("idle");
    if (digit && index < CODE_LENGTH - 1) inputsRef.current[index + 1]?.focus();
    if (digit && next.every((v) => v)) void verify(next.join(""));
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !values[index] && index > 0) inputsRef.current[index - 1]?.focus();
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const text = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, CODE_LENGTH);
    if (!text) return;
    e.preventDefault();
    const next = Array(CODE_LENGTH).fill("");
    for (let i = 0; i < text.length; i++) next[i] = text[i];
    setValues(next);
    inputsRef.current[Math.min(text.length, CODE_LENGTH - 1)]?.focus();
    if (text.length === CODE_LENGTH) void verify(text);
  };

  const resend = async () => {
    if (resendIn > 0 || locked || resending) return;
    setResending(true);
    setError(undefined);
    try {
      await onResend();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Envoi impossible. Réessayez.");
      if (err instanceof ApiError && err.status === 423 && err.retryAfter) setLockedFor(err.retryAfter);
    } finally {
      setResending(false);
    }
  };

  if (status === "success") {
    return (
      <motion.div
        className="es-otp-success"
        initial={{ opacity: 0, scale: reduce ? 1 : 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: EASE }}
      >
        <AnimatedCheck size={48} />
        <p className="es-success-title">Vérification réussie</p>
        <p className="es-success-text">Votre code d&apos;activation va s&apos;afficher.</p>
      </motion.div>
    );
  }

  return (
    <div className="es-otp">
      <p className="es-otp-label">Entrez le code OTP</p>
      <p className="es-otp-hint">
        Un code à 6 chiffres a été envoyé à <strong data-no-translate>{email}</strong>.
      </p>

      {!expired && !locked && (
        <div className="es-otp-timer-row">
          <span className="es-otp-timer-label">Expire dans</span>
          <SquareTimer seconds={remaining} urgent={remaining <= 60} />
        </div>
      )}

      {locked ? (
        <motion.p className="es-otp-error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }}>
          Trop de tentatives incorrectes. Réessayez dans {formatDuration(lockedFor)}.
        </motion.p>
      ) : expired ? (
        <motion.p className="es-otp-error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }}>
          Ce code a expiré. Demandez-en un nouveau.
        </motion.p>
      ) : (
        <>
          <div className={`es-otp-inputs ${status === "error" ? "is-error" : ""}`} onPaste={handlePaste}>
            {values.map((v, i) => (
              <motion.input
                key={i}
                ref={(el) => {
                  inputsRef.current[i] = el;
                }}
                className="es-otp-box"
                inputMode="numeric"
                maxLength={1}
                value={v}
                disabled={locked || expired || status === "checking"}
                autoFocus={i === 0}
                animate={v && !reduce ? { scale: [1, 1.12, 1] } : {}}
                transition={{ duration: 0.22 }}
                onChange={(e) => handleChange(i, e.target.value)}
                onKeyDown={(e) => handleKeyDown(i, e)}
                aria-label={`Chiffre ${i + 1} du code OTP`}
              />
            ))}
          </div>

          {error && status === "error" && (
            <motion.p className="es-otp-error" initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.2 }}>
              {error}
            </motion.p>
          )}

          <button
            type="button"
            className="btn btn-primary es-otp-submit"
            disabled={status === "checking" || values.some((v) => !v)}
            onClick={() => verify(values.join(""))}
          >
            {status === "checking" ? (
              <>
                <span className="es-spinner" aria-hidden />
                Vérification...
              </>
            ) : (
              "Vérifier le code"
            )}
          </button>
        </>
      )}

      {error && status !== "error" && <p className="es-otp-error">{error}</p>}

      <p className="es-otp-resend">
        Besoin d&apos;un nouveau code ?{" "}
        {locked ? (
          <span className="es-otp-countdown">Indisponible pendant le verrouillage</span>
        ) : resendIn > 0 && !expired ? (
          <span className="es-otp-countdown">Nouveau code dans {resendIn}s</span>
        ) : (
          <button type="button" className="au-link" onClick={resend} disabled={resending}>
            Générer un nouveau code
          </button>
        )}
      </p>
    </div>
  );
}
