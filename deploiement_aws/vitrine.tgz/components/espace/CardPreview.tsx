"use client";

import { motion } from "motion/react";
import { IconWifi } from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function CardPreview({
  number,
  name,
  expiry,
  cvv,
  flipped,
}: {
  number: string;
  name: string;
  expiry: string;
  cvv: string;
  flipped: boolean;
}) {
  const digits = number.replace(/\s/g, "");
  const brand = digits.startsWith("4") ? "VISA" : digits.startsWith("5") ? "MASTERCARD" : "";
  const groups = (number || "•••• •••• •••• ••••").padEnd(19, "•").match(/.{1,5}/g) || [];

  return (
    <div className="es-card-preview-scene">
      <motion.div
        className="es-card-preview"
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.55, ease: EASE }}
      >
        <div className="es-card-preview-face es-card-preview-front">
          <div className="es-card-preview-top">
            <span className="es-card-preview-chip" aria-hidden />
            <IconWifi width={18} height={18} />
          </div>
          <div className="es-card-preview-number">
            {groups.map((g, i) => (
              <span key={i}>{g.trim()}</span>
            ))}
          </div>
          <div className="es-card-preview-bottom">
            <span className="es-card-preview-name">{name || "TITULAIRE DE LA CARTE"}</span>
            <span className="es-card-preview-expiry">{expiry || "MM/AA"}</span>
          </div>
          {brand && <span className="es-card-preview-brand">{brand}</span>}
        </div>
        <div className="es-card-preview-face es-card-preview-back">
          <span className="es-card-preview-stripe" aria-hidden />
          <div className="es-card-preview-cvv-row">
            <span className="es-card-preview-cvv-band">{cvv.padEnd(3, "•")}</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
