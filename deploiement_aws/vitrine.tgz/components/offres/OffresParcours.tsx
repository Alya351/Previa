"use client";

import { useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import { IconCreditCard, IconKeyRound, IconPackage, IconShieldCheck } from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

const STEPS = [
  {
    icon: IconPackage,
    label: "Offre",
    title: "Choisissez l'offre",
    text: "Clé en main avec ses caméras, ou Intégration sur vos caméras existantes.",
  },
  {
    icon: IconCreditCard,
    label: "Paiement",
    title: "Créez et payez",
    text: "Réglez la première des trois tranches, par Mobile Money ou carte.",
  },
  {
    icon: IconKeyRound,
    label: "Code",
    title: "Recevez le code",
    text: "Une fois le paiement validé, l'équipe prépare votre code d'activation et vous prévient par e-mail.",
  },
  {
    icon: IconShieldCheck,
    label: "Activation",
    title: "Activez Previa",
    text: "Saisissez le code de vérification reçu, puis votre code d'activation : la surveillance démarre.",
  },
] as const;

/**
 * Parcours unique « de l'offre à l'activation » (il remplace l'ancienne page publique « Code d'activation »).
 * Les 4 étapes sont les portefeuilles d'origine : au clic, la carte d'infos remonte ; elle rentre au clic sur
 * elle-même ou sur un autre portefeuille (une seule carte sortie à la fois).
 * La bande finale s'adapte : visiteur (se connecter / créer un compte) ou client (mon espace).
 */
export default function OffresParcours() {
  const reduce = useReducedMotion();
  const [active, setActive] = useState<number | null>(null);

  const toggle = (i: number) => setActive((cur) => (cur === i ? null : i));

  return (
    <section className="section ofr-steps ofr-pc" id="activation">
      <div className="container">
        <div className="section-head">
          <span className="eyebrow">Comment ça marche</span>
          <h2 className="h2">
            De l&apos;offre à l&apos;<span className="accent">activation</span>
          </h2>
        </div>

        <motion.ol
          className="ofr-steps-list"
          initial={{ opacity: 0, y: reduce ? 0 : 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: EASE }}
        >
          {STEPS.map((s, i) => {
            const open = active === i;
            return (
              <li key={s.title} className="ofr-slot" data-open={open}>
                <span className="ofr-wallet-back" aria-hidden />

                <div
                  className={`ofr-step ofr-step--${i + 1}`}
                  role="button"
                  tabIndex={open ? 0 : -1}
                  aria-label={`Refermer : ${s.title}`}
                  aria-hidden={!open}
                  onClick={() => toggle(i)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      toggle(i);
                    }
                  }}
                >
                  <div className="ofr-step-text">
                    <h3>{s.title}</h3>
                    <p>{s.text}</p>
                  </div>
                </div>

                <span className="ofr-wallet-front" aria-hidden>
                  <i className="ofr-wallet-shape" />
                  <b>0{i + 1}</b>
                  <small>{s.label}</small>
                  <span className="ofr-wallet-icon">
                    <s.icon width={26} height={26} />
                  </span>
                </span>
                <span className="ofr-wallet-frame" aria-hidden />
                <button
                  type="button"
                  className="ofr-wallet-hit"
                  aria-expanded={open}
                  aria-label={`Étape ${i + 1} : ${s.title}`}
                  onClick={() => toggle(i)}
                />
              </li>
            );
          })}
        </motion.ol>

        <motion.div
          className="ofr-pc-band"
          initial={{ opacity: 0, y: reduce ? 0 : 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.6, ease: EASE }}
        >
          <span className="ofr-pc-band-icon" aria-hidden>
            <svg viewBox="0 0 24 24" width="36" height="36" fill="none" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <defs>
                <linearGradient id="ofrKeyGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#38bdf8" />
                  <stop offset="1" stopColor="#0670bd" />
                </linearGradient>
              </defs>
              <g stroke="url(#ofrKeyGrad)">
                <circle cx="8" cy="15.6" r="4.6" fill="rgba(0,158,227,0.14)" />
                <circle cx="8" cy="15.6" r="1.5" />
                <path d="M11.4 12.2 20.2 3.4M16.8 6.8l2.6 2.6M14.2 9.4l1.9 1.9" />
              </g>
            </svg>
          </span>
          <div className="ofr-pc-band-text">
            <span className="ofr-pc-band-label">À savoir</span>
            <p>
              Le <strong>code d&apos;activation</strong> est la clé unique et personnelle qui active Previa après
              paiement. Vous le retrouvez dans votre espace.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
