"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { useAuthUser } from "@/lib/auth";

const EASE = [0.22, 1, 0.36, 1] as const;

/**
 * Appel à l'action final : peu de texte, droit au but — se connecter ou créer un compte pour s'offrir Previa.
 * Un client déjà connecté est renvoyé directement vers son espace.
 */
export default function OffresCta() {
  const reduce = useReducedMotion();
  const authUser = useAuthUser();

  return (
    <section className="section ofr-join-section">
      <div className="container">
        <motion.div
          className="ofr-join"
          initial={{ opacity: 0, y: reduce ? 0 : 24, scale: reduce ? 1 : 0.97 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.7, ease: EASE }}
        >
          <h2 className="ofr-join-title">
            Offrez-vous <span>Previa</span>
          </h2>
          <p className="ofr-join-text">Connectez-vous ou créez votre compte pour commencer.</p>

          <div className="ofr-join-actions">
            {authUser ? (
              <Link href="/code-amorcage" className="ofr-join-btn ofr-join-btn--solid">
                Accéder à mon espace
              </Link>
            ) : (
              <>
                <Link href="/inscription" className="ofr-join-btn ofr-join-btn--solid">
                  Créer un compte
                </Link>
                <Link href="/connexion" className="ofr-join-btn ofr-join-btn--ghost">
                  Se connecter
                </Link>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
