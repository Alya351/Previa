"use client";

import Navbar from "@/components/home/Navbar";
import Footer from "@/components/home/Footer";
import OffresIntro from "./OffresIntro";
import OffresGrid from "./OffresGrid";
import OffresParcours from "./OffresParcours";
import OffresCta from "./OffresCta";

export default function OffresPage() {
  return (
    <>
      <Navbar />
      <main>
        <OffresIntro />
        <OffresGrid />
        <OffresParcours />
        <OffresCta />
      </main>
      <Footer />
    </>
  );
}
