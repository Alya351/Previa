"use client";

import { IconCheck } from "@/components/home/icons";
import { formatFcfa, type Plan } from "@/components/espace/types";

/**
 * Tableau comparatif, section à part entière (toujours visible) : grille « pastilles » —
 * en-têtes de colonnes, libellés de lignes et cellules arrondies, coche pleine ou cercle vide.
 */
export default function OffresCompare({ plans }: { plans: Plan[] }) {
  const options = Array.from(new Set(plans.flatMap((p) => p.features)));

  return (
    <div className="ofr-compare">
      <div className="section-head ofr-compare-title">
        <span className="eyebrow">Comparatif</span>
        <h2 className="h2">
          Comparez les <span className="accent">offres</span>
        </h2>
      </div>

            <div className="ofr-compare-card">
              <div className="ofr-compare-scroll">
                <table className="ofr-table">
                  <thead>
                    <tr>
                      <th>
                        <span className="ofr-pill ofr-pill--corner">Formule</span>
                      </th>
                      {plans.map((p) => (
                        <th key={p.id}>
                          <span className="ofr-pill ofr-pill--head">{p.name}</span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">
                        <span className="ofr-pill ofr-pill--row">Particuliers</span>
                      </th>
                      {plans.map((p) => (
                        <td key={p.id}>
                          <span className="ofr-pill ofr-pill--cell">{p.prixParticulier !== null ? `${formatFcfa(p.prixParticulier)} FCFA` : "Sur devis"}</span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <th scope="row">
                        <span className="ofr-pill ofr-pill--row">Entreprises</span>
                      </th>
                      {plans.map((p) => (
                        <td key={p.id}>
                          <span className="ofr-pill ofr-pill--cell">{p.prixEntreprise !== null ? `${formatFcfa(p.prixEntreprise)} FCFA` : "Sur devis"}</span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <th scope="row">
                        <span className="ofr-pill ofr-pill--row">Dès l&apos;année 2</span>
                      </th>
                      {plans.map((p) => (
                        <td key={p.id}>
                          <span className="ofr-pill ofr-pill--cell">{p.renewalPrice !== null ? `${formatFcfa(p.renewalPrice)} FCFA / an` : "Sur devis"}</span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <th scope="row">
                        <span className="ofr-pill ofr-pill--row">Paiement</span>
                      </th>
                      {plans.map((p) => (
                        <td key={p.id}>
                          <span className="ofr-pill ofr-pill--cell">{p.payable ? "3 tranches" : "Sur devis"}</span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <th scope="row">
                        <span className="ofr-pill ofr-pill--row">Inclus</span>
                      </th>
                      {plans.map((p) => (
                        <td key={p.id}>
                          <span className="ofr-pill ofr-pill--cell">{p.support}</span>
                        </td>
                      ))}
                    </tr>
                    {options.map((o) => (
                      <tr key={o}>
                        <th scope="row">
                          <span className="ofr-pill ofr-pill--row">{o}</span>
                        </th>
                        {plans.map((p) => {
                          const has = p.features.includes(o);
                          return (
                            <td key={p.id}>
                              <span className="ofr-pill ofr-pill--cell">
                                {has ? (
                                  <span className="ofr-dot is-yes" role="img" aria-label="Inclus">
                                    <IconCheck width={12} height={12} />
                                  </span>
                                ) : (
                                  <span className="ofr-dot" role="img" aria-label="Non inclus" />
                                )}
                              </span>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
    </div>
  );
}
