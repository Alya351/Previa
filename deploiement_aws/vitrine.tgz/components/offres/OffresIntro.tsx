"use client";

import { motion, useReducedMotion } from "motion/react";

const EASE = [0.22, 1, 0.36, 1] as const;

/** En-tête de la page Offres : un titre et une phrase. */
export default function OffresIntro() {
  const reduce = useReducedMotion();

  const rise = (delay: number) => ({
    initial: { opacity: 0, y: reduce ? 0 : 16 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.7, delay: reduce ? 0 : delay, ease: EASE },
  });

  return (
    <section className="ofr-intro">
      <div className="container">
        <motion.span className="eyebrow" {...rise(0)}>
          Nos offres
        </motion.span>
        <motion.h1 className="ofr-intro-title" {...rise(0.08)}>
          Choisissez votre <span>formule</span>
        </motion.h1>
        <motion.p className="ofr-intro-lead" {...rise(0.16)}>
          Que vous ayez déjà des caméras ou non, Previa s&apos;installe chez vous : choisissez la formule qui vous convient.
        </motion.p>
      </div>
    </section>
  );
}
