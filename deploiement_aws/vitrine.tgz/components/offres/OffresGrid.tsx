"use client";

import { useEffect, useState, type CSSProperties } from "react";
import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { IconArrowRight, IconCheck } from "@/components/home/icons";
import { DEFAULT_PLANS, fetchPlans, readCachedPlans } from "@/lib/plansCache";
import { useAuthUser } from "@/lib/auth";
import { setPlanIntent } from "@/lib/planIntent";
import OffresCompare from "./OffresCompare";
import { PaymentBand } from "@/components/espace/PlanPricing";
import { formatFcfa, planFromApi, type ClientType, type Plan } from "@/components/espace/types";

const EASE = [0.22, 1, 0.36, 1] as const;

const AUDIENCES: { id: ClientType; label: string }[] = [
  { id: "particulier", label: "Particuliers" },
  { id: "entreprise", label: "Entreprises" },
];

/** Grille des offres publiques : une carte Particuliers et une carte Entreprises, selon que le client a déjà ses caméras ou non. */
export default function OffresGrid() {
  const reduce = useReducedMotion();
  // Offres immédiatement visibles (valeurs par défaut), remplacées par le cache local puis par l'API.
  const [allPlans, setAllPlans] = useState<Plan[] | null>(() => DEFAULT_PLANS.map(planFromApi));
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [equipped, setEquipped] = useState(false);
  const authUser = useAuthUser();

  // Le serveur (Render) peut être en veille : on réessaie quelques fois avant d'abandonner.
  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const MAX_TRIES = 6;

    const cached = readCachedPlans();
    if (cached) queueMicrotask(() => !cancelled && setAllPlans(cached.map(planFromApi)));

    const load = (n: number) => {
      fetchPlans()
        .then((list) => {
          if (cancelled) return;
          setAllPlans(list.map(planFromApi));
          setFailed(false);
        })
        .catch(() => {
          if (cancelled) return;
          if (n + 1 < MAX_TRIES) timer = setTimeout(() => load(n + 1), 4000);
          else setFailed(true);
        });
    };

    load(0);
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [attempt]);

  const plans = allPlans ?? [];
  // « Je n'ai pas de caméras » → PREVIA Clé en main ; « J'ai des caméras » → PREVIA Intégration.
  const plan = plans.find((p) => !!p.equipped === equipped);

  return (
    <>
    <section className="section ofr-grid-section" id="offres">
      <div className="container">
        {allPlans === null && failed ? (
          <div className="ofr-loading">
            <p>Impossible de charger les offres pour le moment.</p>
            <button type="button" className="btn btn-primary ofr-retry" onClick={() => {
                setFailed(false);
                setAttempt((a) => a + 1);
              }}>
              Réessayer
            </button>
          </div>
        ) : allPlans === null ? (
          <div className="es-plans" aria-busy="true" aria-live="polite">
            <div className="ofr-skeleton" />
            <div className="ofr-skeleton" />
          </div>
        ) : plans.length === 0 ? (
          <p className="ofr-loading">Aucune offre disponible pour le moment.</p>
        ) : (
          <>
            <div className="es-equip-row">
              <div className="es-equip-toggle" role="tablist" aria-label="Équipement caméras">
                <button
                  type="button"
                  role="tab"
                  aria-selected={!equipped}
                  className={`es-equip-tab ${!equipped ? "is-active" : ""}`}
                  onClick={() => setEquipped(false)}
                >
                  Je n&apos;ai pas de caméras
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={equipped}
                  className={`es-equip-tab ${equipped ? "is-active" : ""}`}
                  onClick={() => setEquipped(true)}
                >
                  J&apos;ai des caméras
                </button>
              </div>
            </div>

            {plan && (
              <div className="es-plans" key={plan.id}>
                {AUDIENCES.map((aud, i) => {
                  const price = aud.id === "entreprise" ? plan.prixEntreprise : plan.prixParticulier;
                  return (
                    <motion.article
                      key={aud.id}
                      className="es-plan"
                      initial={{ opacity: 0, y: reduce ? 0 : 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, ease: EASE, delay: reduce ? 0 : i * 0.08 }}
                    >
                      <div className="es-plan-clip">
                        <span className="es-plan-head-edge" aria-hidden="true" />
                        <span className="es-plan-head-fill" aria-hidden="true" />
                        <span className="es-plan-corner es-plan-corner--dark" aria-hidden="true" />
                        <span className="es-plan-corner es-plan-corner--light" aria-hidden="true" />

                        <div className="es-plan-head">
                          <h3 className="es-plan-name">{aud.label}</h3>
                        </div>

                        <div className="es-plan-price-badge">
                          {plan.payable && price !== null ? (
                            <>
                              <span className="es-plan-price">{formatFcfa(price)}</span>
                              <span className="es-plan-price-period">FCFA · 1re année</span>
                            </>
                          ) : (
                            <span className="es-plan-price es-plan-price--sm">Sur devis</span>
                          )}
                        </div>

                        <div className="es-plan-content">
                          <p className="es-plan-cameras">{plan.name}</p>
                          <ul className="es-plan-features">
                            {[...plan.features, plan.support].filter(Boolean).map((f, j) => (
                              <motion.li
                                key={f}
                                style={{ "--j": j } as CSSProperties}
                                initial={{ opacity: 0, x: reduce ? 0 : -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{
                                  duration: 0.45,
                                  ease: EASE,
                                  delay: reduce ? 0 : 0.3 + i * 0.08 + j * 0.07,
                                }}
                              >
                                <IconCheck width={14} height={14} />
                                {f}
                              </motion.li>
                            ))}
                          </ul>

                          {/* Même scénario que /code-amorcage : visiteur → connexion/inscription, puis l'espace
                              client reprend l'offre et le profil choisis ; client connecté → directement l'espace. */}
                          <Link
                            href={authUser ? "/code-amorcage" : "/connexion"}
                            onClick={() => setPlanIntent(plan.id, aud.id)}
                            className="es-plan-btn ofr-plan-link shimmer-hover"
                          >
                            {plan.payable ? "S'abonner" : "Demander un devis"}
                            <span className="ofr-btn-arrow" aria-hidden>
                              <IconArrowRight width={16} height={16} />
                            </span>
                          </Link>
                        </div>
                      </div>
                    </motion.article>
                  );
                })}
              </div>
            )}
          </>
        )}

        {plans.length > 0 && (
          <PaymentBand renewalPrice={plans.find((p) => p.renewalPrice !== null)?.renewalPrice ?? null} />
        )}

      </div>
    </section>

    {plans.length > 1 && (
      <section className="section ofr-compare-section" id="comparatif">
        <div className="container">
          <OffresCompare plans={plans} />
        </div>
      </section>
    )}
    </>
  );
}
