"use client";

import Link from "next/link";
import LegalPage from "./LegalPage";

export default function MentionsLegalesPage() {
  return (
    <LegalPage title="Mentions légales et conditions d'utilisation" updated="8 novembre 2026">
      <h2>1. Éditeur du site</h2>
      <p>
        Le site et la plateforme Previa (vidéosurveillance intelligente par analyse comportementale vidéo) sont édités
        par l&apos;équipe Previa, basée à Ouagadougou (Burkina Faso). Pour toute question, utilisez la page{" "}
        <Link href="/a-propos#contact">Contact</Link>.
      </p>

      <h2>2. Hébergement</h2>
      <p>Le site, l&apos;interface de programmation et les données sont hébergés par des prestataires techniques :</p>
      <ul>
        <li>Vercel : hébergement du site web ;</li>
        <li>Render : hébergement de l&apos;interface de programmation (API) ;</li>
        <li>Supabase : authentification et base de données ;</li>
        <li>Resend : envoi des e-mails (confirmation d&apos;adresse, code de vérification, notifications).</li>
      </ul>

      <h2>3. Objet et accès au service</h2>
      <p>
        Previa propose des abonnements donnant accès à une solution de vidéosurveillance intelligente. La création d&apos;un
        compte est gratuite. Pour souscrire un abonnement, vous devez confirmer votre adresse e-mail puis régler la
        première tranche de l&apos;offre choisie.
      </p>

      <h2>4. Abonnement, paiement et code d&apos;activation</h2>
      <ul>
        <li>
          Le prix de la première année est réglé en trois tranches ; l&apos;abonnement des années suivantes est
          renouvelable à votre initiative, sans prélèvement automatique.
        </li>
        <li>
          Un code d&apos;activation personnel est associé à votre abonnement. Il vous est communiqué dans votre espace, après
          vérification par un code reçu par e-mail. Il ne doit pas être partagé.
        </li>
        <li>
          Le code est désactivé si l&apos;abonnement est suspendu ou terminé, ou à l&apos;expiration de l&apos;abonnement.
        </li>
      </ul>

      <h2>5. Obligations de l&apos;utilisateur</h2>
      <p>
        Vous vous engagez à fournir des informations exactes, à protéger vos identifiants et votre code d&apos;activation, et
        à utiliser la solution dans le respect des lois en vigueur, notamment en matière de vie privée et d&apos;installation
        de caméras.
      </p>

      <h2>6. Propriété intellectuelle</h2>
      <p>
        Les marques, logos, textes, images et logiciels de Previa sont protégés. Toute reproduction ou réutilisation sans
        autorisation écrite est interdite.
      </p>

      <h2>7. Responsabilité</h2>
      <p>
        Previa met en œuvre les moyens raisonnables pour assurer la disponibilité du service, sans garantir l&apos;absence
        d&apos;interruption. Previa n&apos;est pas responsable de l&apos;usage qui est fait de la solution par ses
        utilisateurs.
      </p>

      <h2>8. Données personnelles</h2>
      <p>
        Le traitement de vos données est décrit dans notre <Link href="/confidentialite">politique de confidentialité</Link>.
      </p>

      <h2>9. Modification et contact</h2>
      <p>
        Ces conditions peuvent évoluer ; la date de mise à jour figure en haut de page. Pour toute question, écrivez-nous
        via la page <Link href="/a-propos#contact">Contact</Link>.
      </p>
    </LegalPage>
  );
}
