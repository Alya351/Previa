"use client";

import Link from "next/link";
import LegalPage from "./LegalPage";

export default function ConfidentialitePage() {
  return (
    <LegalPage title="Politique de confidentialité" updated="8 novembre 2026">
      <h2>1. Données que nous collectons</h2>
      <ul>
        <li>Identité et contact : prénom, nom, adresse e-mail, téléphone, pays, entreprise (le cas échéant) ;</li>
        <li>Compte : mot de passe (géré par le service d&apos;authentification, jamais lisible par Previa), type de client ;</li>
        <li>Abonnement : offre choisie, durée, dates, tranches réglées, historique des paiements ;</li>
        <li>Messages envoyés via le formulaire de contact ou de demande de devis ;</li>
        <li>Notifications et journaux d&apos;e-mails envoyés (destinataire, objet, statut).</li>
      </ul>

      <h2>2. Pourquoi nous les utilisons</h2>
      <ul>
        <li>Créer et sécuriser votre compte, confirmer votre adresse e-mail ;</li>
        <li>Gérer votre abonnement, vos paiements et votre code d&apos;activation ;</li>
        <li>Vous envoyer les e-mails liés au service (code de vérification, notifications, réponses à vos demandes) ;</li>
        <li>Répondre à vos messages et demandes de devis.</li>
      </ul>

      <h2>3. Code d&apos;activation et sécurité</h2>
      <p>
        Le code d&apos;activation est stocké chiffré. Il n&apos;est jamais envoyé par e-mail : il s&apos;affiche dans votre
        espace après saisie d&apos;un code de vérification reçu par e-mail, valable dix minutes.
      </p>

      <h2>4. Partage avec des tiers</h2>
      <p>
        Vos données ne sont pas vendues. Elles sont traitées par nos prestataires techniques (hébergement, base de
        données, authentification, envoi d&apos;e-mails) uniquement pour faire fonctionner le service.
      </p>

      <h2>5. Durée de conservation</h2>
      <p>
        Vos données sont conservées tant que votre compte existe. À la suppression du compte, vos abonnements sont
        terminés, vos codes désactivés et l&apos;accès est fermé ; l&apos;historique nécessaire à la gestion des
        paiements peut être conservé.
      </p>

      <h2>6. Vos droits</h2>
      <p>
        Vous pouvez demander l&apos;accès à vos données, leur rectification ou la suppression de votre compte en nous
        écrivant via la page <Link href="/a-propos#contact">Contact</Link>.
      </p>

      <h2>7. Cookies et stockage local</h2>
      <p>
        Le site utilise le stockage de votre navigateur pour des besoins techniques : session de connexion, thème clair ou
        sombre, langue et mémorisation de votre dernière offre consultée. Aucun suivi publicitaire n&apos;est utilisé.
      </p>

      <h2>8. Contact</h2>
      <p>
        Pour toute question sur cette politique, utilisez la page <Link href="/a-propos#contact">Contact</Link>. Voir aussi nos{" "}
        <Link href="/mentions-legales">conditions d&apos;utilisation</Link>.
      </p>
    </LegalPage>
  );
}
