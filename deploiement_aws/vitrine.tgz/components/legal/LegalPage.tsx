"use client";

import type { ReactNode } from "react";
import Navbar from "@/components/home/Navbar";
import Footer from "@/components/home/Footer";

type Props = {
  title: string;
  updated: string;
  children: ReactNode;
};

/** Gabarit commun des pages légales (mentions légales, confidentialité). */
export default function LegalPage({ title, updated, children }: Props) {
  return (
    <>
      <Navbar />
      <main>
        <section className="hero lg-intro">
          <div className="container">
            <article className="lg-card">
              <header className="lg-head">
                <h1 className="lg-title">{title}</h1>
                <p className="lg-updated">Dernière mise à jour : {updated}</p>
              </header>
              <div className="lg-body">{children}</div>
            </article>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
