"use client";

import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { IconAlertTriangle, IconCheck } from "@/components/home/icons";

type Toast = { id: string; message: string; kind: "success" | "error" };

const ToastContext = createContext<{ show: (message: string) => void; error: (message: string) => void } | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const push = useCallback(
    (message: string, kind: Toast["kind"]) => {
      const id = `t-${Date.now()}-${Math.random()}`;
      setToasts((prev) => [...prev, { id, message, kind }]);
      window.setTimeout(() => dismiss(id), kind === "error" ? 6000 : 3600);
    },
    [dismiss]
  );
  const show = useCallback((message: string) => push(message, "success"), [push]);
  const error = useCallback((message: string) => push(message, "error"), [push]);

  return (
    <ToastContext.Provider value={{ show, error }}>
      {children}

      <AnimatePresence>
        {toasts.length > 0 && (
          <motion.div
            className="ad-toast-veil"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            aria-hidden
          />
        )}
      </AnimatePresence>

      <div className="ad-toasts" aria-live="polite">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              className={`ad-toast ${t.kind === "error" ? "ad-toast--error" : ""}`}
              initial={{ opacity: 0, y: 16, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.94 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            >
              <span className="ad-toast-icon">
                {t.kind === "error" ? <IconAlertTriangle width={26} height={26} /> : <IconCheck width={26} height={26} />}
              </span>
              <h3 className="ad-toast-title">{t.kind === "error" ? "Erreur" : "Succès !"}</h3>
              <p className="ad-toast-message">{t.message}</p>
              <button type="button" className="ad-toast-btn" onClick={() => dismiss(t.id)}>
                Continuer
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within ToastProvider");
  return ctx;
}
