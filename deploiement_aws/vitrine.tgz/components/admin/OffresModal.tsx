"use client";

import { useEffect, useState } from "react";
import { IconPackage } from "@/components/home/icons";
import { readAdminToken } from "@/lib/adminAuth";
import { api, ApiError, type PlanApi } from "@/lib/api";
import { useToast } from "./ToastContext";
import FormModal from "./FormModal";

type Draft = {
  prixParticulier: string;
  prixEntreprise: string;
  prixRenouvellement: string;
  cameras: string;
  payable: boolean;
  actif: boolean;
};

const priceText = (v: number | null) => (v != null ? String(v) : "");
const priceValue = (v: string) => (v.trim() === "" ? null : Number(v));

const toDraft = (p: PlanApi): Draft => ({
  prixParticulier: priceText(p.prix_particulier),
  prixEntreprise: priceText(p.prix_entreprise),
  prixRenouvellement: priceText(p.prix_renouvellement),
  cameras: String(p.cameras_max),
  payable: p.payable_en_ligne,
  actif: p.actif ?? true,
});

/** Fenêtre « Offres » : prix, limite de caméras et disponibilité de chaque plan Previa. */
export default function OffresModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { show, error } = useToast();
  const [plans, setPlans] = useState<PlanApi[]>([]);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [page, setPage] = useState(0);

  const load = async () => {
    const t = readAdminToken();
    if (!t) return;
    try {
      const list = await api.admin.plans(t);
      setPlans(list);
      setDrafts(Object.fromEntries(list.map((p) => [p.id, toDraft(p)])));
    } catch {
      /* silencieux : la fenêtre reste utilisable, juste vide */
    }
  };

  useEffect(() => {
    if (open) {
      setPage(0);
      void load();
    }
  }, [open]);

  const setDraft = (id: string, patch: Partial<Draft>) =>
    setDrafts((s) => ({ ...s, [id]: { ...s[id], ...patch } }));

  const save = async (id: string) => {
    const t = readAdminToken();
    const d = drafts[id];
    if (!t || !d) return;
    const cameras = Number(d.cameras);
    if (!Number.isFinite(cameras) || cameras < 1) {
      error("Le nombre de caméras doit être un entier positif.");
      return;
    }
    setSavingId(id);
    try {
      await api.admin.updatePlan(t, id, {
        prix_particulier: priceValue(d.prixParticulier),
        prix_entreprise: priceValue(d.prixEntreprise),
        prix_renouvellement: priceValue(d.prixRenouvellement),
        cameras_max: cameras,
        payable_en_ligne: d.payable,
        actif: d.actif,
      });
      show("Offre mise à jour.");
      await load();
    } catch (err) {
      error(err instanceof ApiError ? err.message : "Mise à jour impossible.");
    } finally {
      setSavingId(null);
    }
  };

  const first = Math.max(0, Math.min(page, plans.length - 2));

  return (
    <FormModal open={open} onClose={onClose} icon={<IconPackage width={44} height={44} />} title="Offres" maxWidth={440}>
      <div className="of-viewport">
      <ul className="of-list" style={{ transform: `translateX(-${page * 100}%)` }}>
        {plans.map((p) => {
          const d = drafts[p.id] ?? toDraft(p);
          return (
            <li key={p.id} className="of-row">
              <div className="of-row-head">
                <b>{p.nom}</b>
                <span className={`of-badge ${d.actif ? "is-on" : ""}`}>{d.actif ? "Active" : "Inactive"}</span>
              </div>

              <div className="of-fields">
                <label className="of-field">
                  Prix particuliers (FCFA)
                  <input
                    type="number"
                    min={0}
                    placeholder="Sur devis"
                    value={d.prixParticulier}
                    onChange={(e) => setDraft(p.id, { prixParticulier: e.target.value })}
                  />
                </label>
                <label className="of-field">
                  Prix entreprises (FCFA)
                  <input
                    type="number"
                    min={0}
                    placeholder="Sur devis"
                    value={d.prixEntreprise}
                    onChange={(e) => setDraft(p.id, { prixEntreprise: e.target.value })}
                  />
                </label>
                <label className="of-field">
                  Dès l&apos;année 2 (FCFA / an)
                  <input
                    type="number"
                    min={0}
                    placeholder="Sur devis"
                    value={d.prixRenouvellement}
                    onChange={(e) => setDraft(p.id, { prixRenouvellement: e.target.value })}
                  />
                </label>
                <label className="of-field">
                  Caméras max
                  <input
                    type="number"
                    min={1}
                    value={d.cameras}
                    onChange={(e) => setDraft(p.id, { cameras: e.target.value })}
                  />
                </label>
              </div>

              <div className="of-toggles">
                <label className="of-toggle">
                  <input
                    type="checkbox"
                    checked={d.payable}
                    onChange={(e) => setDraft(p.id, { payable: e.target.checked })}
                  />
                  Payable en ligne
                </label>
                <label className="of-toggle">
                  <input
                    type="checkbox"
                    checked={d.actif}
                    onChange={(e) => setDraft(p.id, { actif: e.target.checked })}
                  />
                  Offre active
                </label>
              </div>

              <button type="button" className="of-save" disabled={savingId === p.id} onClick={() => save(p.id)}>
                {savingId === p.id ? "Enregistrement…" : "Enregistrer"}
              </button>
            </li>
          );
        })}
      </ul>
      </div>
      {plans.length > 1 && (
        <nav className="of-pager" aria-label="Pages des offres">
          <button
            type="button"
            className="of-arrow"
            aria-label="Offre précédente"
            disabled={page === 0}
            onClick={() => setPage((n) => Math.max(0, n - 1))}
          >
            ‹
          </button>
          {[first, first + 1].map((i) => (
            <button
              key={i}
              type="button"
              className={`of-page ${i === page ? "is-on" : ""}`}
              aria-current={i === page ? "page" : undefined}
              onClick={() => setPage(i)}
            >
              {i + 1}
            </button>
          ))}
          <button
            type="button"
            className="of-arrow"
            aria-label="Offre suivante"
            disabled={page === plans.length - 1}
            onClick={() => setPage((n) => Math.min(plans.length - 1, n + 1))}
          >
            ›
          </button>
        </nav>
      )}
    </FormModal>
  );
}
