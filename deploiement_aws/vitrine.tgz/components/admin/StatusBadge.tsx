const LABELS: Record<string, string> = {
  actif: "Actif",
  actifs: "Actifs",
  expire: "Expiré",
  expirant: "Expire bientôt",
  suspendu: "Suspendu",
  en_attente: "En attente",
  validee: "Validée",
  refusee: "Refusée",
  disponible: "Disponible",
  supprime: "Supprimé",
  en_attente_code: "En attente du code",
  termine: "Terminé",
  sans_abonnement: "Sans abonnement",
  code_envoye: "Code envoyé",
  code_genere: "Code généré",
  sans_code: "Sans code",
  devis: "Devis",
  message: "Message",
  traite: "Traité",
  non_traite: "Non traité",
};

const CLASS_FOR: Record<string, string> = {
  actif: "ad-badge--actif",
  validee: "ad-badge--validee",
  disponible: "ad-badge--disponible",
  en_attente: "ad-badge--attente",
  expirant: "ad-badge--expirant",
  refusee: "ad-badge--refusee",
  expire: "ad-badge--expire",
  suspendu: "ad-badge--suspendu",
  supprime: "ad-badge--supprime",
  en_attente_code: "ad-badge--attente",
  termine: "ad-badge--supprime",
  sans_abonnement: "ad-badge--supprime",
  code_envoye: "ad-badge--actif",
  code_genere: "ad-badge--validee",
  sans_code: "ad-badge--attente",
  devis: "ad-badge--validee",
  message: "ad-badge--supprime",
  traite: "ad-badge--actif",
  non_traite: "ad-badge--attente",
};

export default function StatusBadge({ status }: { status: string }) {
  return <span className={`ad-badge ${CLASS_FOR[status] ?? ""}`}>{LABELS[status] ?? status}</span>;
}
