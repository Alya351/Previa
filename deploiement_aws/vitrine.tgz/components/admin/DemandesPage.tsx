"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import { IconSend } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { fullName } from "@/lib/adminData";
import EmptyState from "./EmptyState";
import Pagination from "./Pagination";
import { useFitRows } from "./useFitRows";

export default function DemandesPage() {
  const { demandes, getClient } = useAdminData();
  const [page, setPage] = useState(1);
  const visibles = demandes;

  const { ref, rows: pageSize, rootStyle } = useFitRows({ list: "tbody", item: "tbody tr" });

  const totalPages = Math.max(1, Math.ceil(visibles.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = visibles.slice((current - 1) * pageSize, current * pageSize);

  return (
    <div ref={ref} style={rootStyle}>
      <motion.div className="ad-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        {visibles.length === 0 ? (
          <EmptyState icon={<IconSend width={22} height={22} />} text="Aucune demande pour le moment" />
        ) : (
          <div className="ad-table-wrap">
            <table className="ad-table">
              <thead>
                <tr>
                  <th>Client</th>
                  <th>Date</th>
                  <th>Abonnement</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((d) => {
                  const c = getClient(d.clientId);
                  return (
                    <tr key={d.id} className="ad-table-row">
                      <td>
                        <Link href={`/prevadm/demandes/${d.id}`} className="ad-table-link-name">
                          <span className="ad-table-name">{c ? fullName(c) : "—"}</span>
                        </Link>
                      </td>
                      <td>{d.date}</td>
                      <td>{d.formule}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      <Pagination page={current} totalPages={totalPages} onChange={setPage} />
    </div>
  );
}
