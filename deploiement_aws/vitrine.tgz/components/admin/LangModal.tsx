"use client";

import { useEffect, useState } from "react";
import { IconCheck, IconChevronRight, IconSettings } from "@/components/home/icons";
import { useLang, type Lang } from "@/lib/i18n/LangProvider";
import { ModalShell } from "./FormModal";
import { Flag } from "./Flags";

const LANGS: { code: Lang; name: string; native: string }[] = [
  { code: "fr", name: "Français", native: "Langue par défaut" },
  { code: "en", name: "English", native: "Interface traduite" },
];

/** Choix de la langue : carte blanche, panneau en creux à deux pilules, gros bouton bleu entouré de deux flèches. */
export default function LangModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang, setLang } = useLang();
  const [pick, setPick] = useState<Lang>(lang);

  useEffect(() => {
    if (open) setPick(lang);
  }, [open, lang]);

  const current = LANGS.find((l) => l.code === pick)!;
  const step = () => setPick((p) => (p === "fr" ? "en" : "fr"));
  const apply = () => {
    setLang(pick);
    onClose();
  };

  return (
    <ModalShell open={open} onClose={onClose} label="Langue" maxWidth={380} className="fm-lang">
      <div className="fm-lang-top">
        <span className="fm-lang-tag">
          <IconSettings width={18} height={18} />
          Langue
        </span>
        <span className="fm-lang-chip">
          <Flag code={lang} className="fm-flag fm-flag--xs" />
          Actuelle
        </span>
      </div>

      <div className="fm-lang-hero">
        <span className="fm-lang-code">
          <Flag code={pick} className="fm-flag" />
        </span>
        <div>
          <strong data-no-translate>{current.name}</strong>
          <p>Langue de l&apos;interface</p>
        </div>
      </div>

      <div className="fm-lang-bar" aria-hidden>
        <span style={{ width: pick === "fr" ? "50%" : "100%" }} />
      </div>

      <div className="fm-lang-panel" role="radiogroup" aria-label="Langue">
        {LANGS.map((l) => (
          <button
            key={l.code}
            type="button"
            role="radio"
            aria-checked={pick === l.code}
            className={`fm-lang-row${pick === l.code ? " is-on" : ""}`}
            onClick={() => setPick(l.code)}
          >
            <span className="fm-lang-dot">
              <Flag code={l.code} className="fm-flag fm-flag--sm" />
            </span>
            <span className="fm-lang-name">
              <b data-no-translate>{l.name}</b>
              <small>{l.native}</small>
            </span>
            {pick === l.code && <IconCheck width={18} height={18} />}
          </button>
        ))}
      </div>

      <div className="fm-lang-actions">
        <button type="button" className="fm-lang-round" aria-label="Langue précédente" onClick={step}>
          <IconChevronRight width={18} height={18} style={{ transform: "rotate(180deg)" }} />
        </button>
        <button type="button" className="fm-lang-apply" onClick={apply}>
          Appliquer
        </button>
        <button type="button" className="fm-lang-round" aria-label="Langue suivante" onClick={step}>
          <IconChevronRight width={18} height={18} />
        </button>
      </div>
    </ModalShell>
  );
}
