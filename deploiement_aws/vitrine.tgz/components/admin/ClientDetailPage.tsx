"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { IconChevronRight, IconEdit, IconTrash } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { fullName, initialsOfName } from "@/lib/adminData";
import { ApiError } from "@/lib/api";
import StatusBadge from "./StatusBadge";
import DetailTable from "./DetailTable";
import ConfirmDialog from "./ConfirmDialog";
import { useToast } from "./ToastContext";

export default function ClientDetailPage({ id }: { id: string }) {
  const router = useRouter();
  const { getClient, updateClient, deleteClient } = useAdminData();
  const { show, error } = useToast();
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState({ prenom: "", nom: "", email: "", telephone: "" });

  const client = getClient(id);

  if (!client) {
    return (
      <div className="ad-card">
        <p>Client introuvable.</p>
        <Link href="/prevadm/clients" className="ad-table-link">
          Retour à la liste
        </Link>
      </div>
    );
  }

  const supprime = client.statut === "supprime";

  const openEdit = () => {
    setForm({ prenom: client.prenom, nom: client.nom, email: client.email, telephone: client.telephone ?? "" });
    setEditing(true);
  };

  return (
    <div>
      <Link href="/prevadm/clients" className="ad-back-link">
        <span className="ad-back-link-icon">
          <IconChevronRight width={13} height={13} style={{ transform: "rotate(180deg)" }} />
        </span>
        Retour aux clients
      </Link>

      <motion.div className="ad-card ad-card--profile" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} style={{ marginBottom: 16 }}>
        <div className="ad-profile-head">
          <span className="ad-profile-avatar">{initialsOfName(client.prenom, client.nom)}</span>
          <div>
            <h2>{fullName(client)}</h2>
            <p>{client.email}</p>
          </div>
          <span style={{ marginLeft: "auto" }}>
            <StatusBadge status={client.statut} />
          </span>
        </div>
      </motion.div>

      <motion.div className="ad-card ad-card--narrow" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: 0.05 }}>
        <div className="ad-card-head">
          <h2>Informations personnelles</h2>
        </div>
        <DetailTable
          rows={[
            { label: "Nom", value: client.nom },
            { label: "Prénom", value: client.prenom },
            { label: "Email", value: client.email },
            { label: "Téléphone", value: client.telephone ?? "Non renseigné" },
            { label: "Inscription", value: client.dateInscription },
          ]}
        />
        {!supprime && (
          <div className="ad-detail-actions">
            <button type="button" className="btn btn-secondary" onClick={openEdit}>
              <IconEdit width={15} height={15} />
              Modifier
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ color: "var(--au-danger)" }}
              onClick={() => setDeleting(true)}
            >
              <IconTrash width={15} height={15} />
              Supprimer
            </button>
          </div>
        )}
      </motion.div>

      <ConfirmDialog
        open={editing}
        title="Modifier le client"
        text={`Mettez à jour les informations de ${fullName(client)}.`}
        confirmLabel="Enregistrer"
        onCancel={() => setEditing(false)}
        disabled={busy}
        onConfirm={async () => {
          setBusy(true);
          try {
            await updateClient(client.id, form);
            show(`Informations de ${form.prenom} ${form.nom} mises à jour.`);
            setEditing(false);
          } catch (err) {
            error(err instanceof ApiError ? err.message : "Mise à jour impossible.");
          } finally {
            setBusy(false);
          }
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div className="au-field-row-2">
            <div>
              <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text)" }}>Prénom</label>
              <input
                className="es-input"
                style={{ width: "100%", marginTop: 6 }}
                value={form.prenom}
                onChange={(e) => setForm((f) => ({ ...f, prenom: e.target.value }))}
              />
            </div>
            <div>
              <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text)" }}>Nom</label>
              <input
                className="es-input"
                style={{ width: "100%", marginTop: 6 }}
                value={form.nom}
                onChange={(e) => setForm((f) => ({ ...f, nom: e.target.value }))}
              />
            </div>
          </div>
          <div>
            <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text)" }}>Email</label>
            <input
              className="es-input"
              type="email"
              style={{ width: "100%", marginTop: 6 }}
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            />
          </div>
          <div>
            <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text)" }}>Téléphone</label>
            <input
              className="es-input"
              style={{ width: "100%", marginTop: 6 }}
              value={form.telephone}
              onChange={(e) => setForm((f) => ({ ...f, telephone: e.target.value }))}
            />
          </div>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={deleting}
        title="Supprimer ce client définitivement ?"
        text={`${fullName(client)} ne pourra plus se connecter. Le compte et son historique restent conservés pour les traces.`}
        danger
        confirmLabel="Supprimer définitivement"
        onCancel={() => setDeleting(false)}
        disabled={busy}
        onConfirm={async () => {
          setBusy(true);
          try {
            await deleteClient(client.id);
            show(`${fullName(client)} a été supprimé.`);
            setDeleting(false);
            router.push("/prevadm/clients");
          } catch (err) {
            error(err instanceof ApiError ? err.message : "Suppression impossible.");
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}
