"use client";

import type { ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { IconAlertTriangle, IconCheck } from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function ConfirmDialog({
  open,
  title,
  text,
  confirmLabel = "Confirmer",
  danger,
  disabled,
  children,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  text: string;
  confirmLabel?: string;
  danger?: boolean;
  disabled?: boolean;
  children?: ReactNode;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="ad-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onCancel}
        >
          <motion.div
            className={`ad-dialog ${danger ? "ad-dialog--danger" : ""}`}
            role="alertdialog"
            aria-modal="true"
            initial={{ opacity: 0, scale: 0.94, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.28, ease: EASE }}
            onClick={(e) => e.stopPropagation()}
          >
            <span className={`ad-dialog-icon ${danger ? "ad-dialog-icon--danger" : ""}`}>
              {danger ? <IconAlertTriangle width={20} height={20} /> : <IconCheck width={20} height={20} />}
            </span>
            <h3>{title}</h3>
            <p>{text}</p>
            {children && <div className="ad-dialog-body">{children}</div>}
            <div className="ad-dialog-actions">
              <button type="button" className="btn btn-secondary" onClick={onCancel}>
                Annuler
              </button>
              <button
                type="button"
                className="btn btn-primary"
                style={danger ? { background: "var(--au-danger)", boxShadow: "none" } : undefined}
                disabled={disabled}
                onClick={onConfirm}
              >
                {confirmLabel}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
