import type { SVGProps } from "react";

/** Drapeau français (bleu, blanc, rouge). */
export function FlagFR(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 30 20" role="img" aria-label="Drapeau français" {...props}>
      <rect width="10" height="20" fill="#0055a4" />
      <rect x="10" width="10" height="20" fill="#ffffff" />
      <rect x="20" width="10" height="20" fill="#ef4135" />
    </svg>
  );
}

// 9 rangées de 6 et 5 étoiles alternées, comme sur le drapeau américain.
const STARS = Array.from({ length: 9 }, (_, row) => {
  const count = row % 2 === 0 ? 6 : 5;
  return Array.from({ length: count }, (_, i) => ({
    x: 3.2 + i * 6.2 + (row % 2 === 0 ? 0 : 3.1),
    y: 2.6 + row * 3.7,
  }));
}).flat();

/** Drapeau américain (13 bandes, cantonnement bleu étoilé). */
export function FlagUS(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 190 100" role="img" aria-label="Drapeau américain" {...props}>
      <rect width="190" height="100" fill="#ffffff" />
      {Array.from({ length: 7 }, (_, i) => (
        <rect key={i} y={i * 2 * (100 / 13)} width="190" height={100 / 13} fill="#b22234" />
      ))}
      <rect width="76" height={7 * (100 / 13)} fill="#3c3b6e" />
      {STARS.map((s, i) => (
        <circle key={i} cx={s.x} cy={s.y} r="1.35" fill="#ffffff" />
      ))}
    </svg>
  );
}

export function Flag({ code, ...props }: { code: "fr" | "en" } & SVGProps<SVGSVGElement>) {
  return code === "fr" ? <FlagFR {...props} /> : <FlagUS {...props} />;
}
