"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "motion/react";
import { IconArrowRight, IconMail } from "@/components/home/icons";
import { TextField, PasswordField } from "@/components/auth/fields";
import ConfirmCard from "@/components/auth/ConfirmCard";
import { setAdminUser } from "@/lib/adminAuth";
import { api, ApiError } from "@/lib/api";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function AdminLoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState<{ email?: string; password?: string; general?: string }>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  // Ouvre la session au clic sur « Continuer » (ou au bout du délai) : l'enregistrer plus tôt
  // remplacerait aussitôt la page de connexion — et la carte de confirmation — par le tableau de bord.
  const enter = useRef<(() => void) | null>(null);

  const validate = () => {
    const next: typeof errors = {};
    if (!EMAIL_RE.test(email)) next.email = "Adresse e-mail invalide.";
    if (password.length < 1) next.password = "Le mot de passe est requis.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate() || status !== "idle") return;
    setStatus("submitting");
    setErrors({});

    try {
      const res = await api.admin.login(email.trim(), password);

      let done = false;
      enter.current = () => {
        if (done) return;
        done = true;
        setAdminUser({
          id: res.compte.id,
          nom: res.compte.nom,
          prenom: res.compte.prenom,
          email: res.compte.email,
          token: res.token,
        });
        router.push("/prevadm");
      };
      setStatus("success");
      window.setTimeout(() => enter.current?.(), 2200);
    } catch (err: any) {
      setStatus("idle");
      const msg =
        err instanceof ApiError
          ? err.message
          : "Échec de l'authentification. Vérifiez vos identifiants administrateur.";
      setErrors({ general: msg });
    }
  };

  if (status === "success") {
    return (
      <ConfirmCard
        open
        title="Connexion administrateur réussie"
        text="Vous allez être redirigé vers le centre de pilotage."
        cta="Continuer"
        onContinue={() => enter.current?.()}
      />
    );
  }

  return (
    <form className="au-form" onSubmit={handleSubmit} noValidate>
      {errors.general && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            padding: "10px 14px",
            borderRadius: "8px",
            backgroundColor: "rgba(220, 38, 38, 0.12)",
            border: "1px solid rgba(220, 38, 38, 0.35)",
            color: "#ef4444",
            fontSize: "0.85rem",
            marginBottom: "12px",
          }}
        >
          {errors.general}
        </motion.div>
      )}

      <TextField
        label="Adresse e-mail administrateur"
        type="email"
        placeholder="admin@previa.app"
        value={email}
        onChange={(val) => {
          setEmail(val);
          if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
        }}
        onBlur={() =>
          email &&
          setErrors((s) => ({
            ...s,
            email: EMAIL_RE.test(email) ? undefined : "Adresse e-mail invalide.",
          }))
        }
        error={errors.email}
        success={EMAIL_RE.test(email)}
        autoComplete="email"
        icon={<IconMail width={16} height={16} />}
      />

      <PasswordField
        label="Mot de passe"
        value={password}
        onChange={(val) => {
          setPassword(val);
          if (errors.general) setErrors((e) => ({ ...e, general: undefined }));
        }}
        error={errors.password}
        autoComplete="current-password"
      />

      <div className="au-forgot-row au-remember-row">
        <label className="au-remember">
          <input
            type="checkbox"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
          />
          <span className="au-checkbox-box" aria-hidden />
          Se souvenir de moi
        </label>
        <a href="#" className="au-link-muted" onClick={(e) => e.preventDefault()}>
          Mot de passe oublié ?
        </a>
      </div>

      <button
        type="submit"
        className="btn btn-primary au-submit"
        disabled={status === "submitting"}
      >
        {status === "submitting" ? (
          <>
            <span className="au-spinner" aria-hidden />
            Accès au centre de pilotage...
          </>
        ) : (
          <>
            Se connecter au back-office
            <motion.span className="au-submit-arrow" aria-hidden>
              <IconArrowRight width={17} height={17} />
            </motion.span>
          </>
        )}
      </button>
    </form>
  );
}
