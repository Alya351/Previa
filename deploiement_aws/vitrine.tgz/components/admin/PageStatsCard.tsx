"use client";

import { motion } from "motion/react";

export type PageStat = {
  /** Identifiant du filtre appliqué quand on clique sur la carte. */
  key: string;
  label: string;
  value: number;
  tone?: "default" | "accent" | "warn" | "danger";
};

/** Bandeau de chiffres clés en verre dépoli. Chaque carte est un bouton :
 *  un clic filtre la liste située en dessous (un second clic retire le filtre). */
export default function PageStatsCard({
  title,
  stats,
  active,
  onSelect,
}: {
  title: string;
  stats: PageStat[];
  active?: string;
  onSelect?: (key: string) => void;
}) {
  return (
    <motion.div
      className="ad-infostrip"
      role="group"
      aria-label={`${title} — filtrer la liste`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {stats.map((s) => (
        <button
          type="button"
          className={`ad-infostrip-item ${active === s.key ? "is-active" : ""}`}
          key={s.key}
          aria-pressed={active === s.key}
          onClick={() => onSelect?.(s.key)}
        >
          <span className={`ad-infostrip-value ${s.tone && s.tone !== "default" ? `ad-infostrip-value--${s.tone}` : ""}`}>
            {s.value}
          </span>
          <span className="ad-infostrip-label">{s.label}</span>
        </button>
      ))}
    </motion.div>
  );
}
