"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import { IconLayers } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { fullName } from "@/lib/adminData";
import StatusBadge from "./StatusBadge";
import EmptyState from "./EmptyState";
import { ALL, useAdminFilter } from "@/lib/adminFilter";
import PageStatsCard from "./PageStatsCard";
import Pagination from "./Pagination";
import { useFitRows } from "./useFitRows";

export function AbonnementsInfoCard() {
  const { abonnements } = useAdminData();
  const { value, toggle } = useAdminFilter("abonnements");
  const stats = [
    { key: "en_attente_code", label: "en attente du code", value: abonnements.filter((a) => a.statut === "en_attente_code").length, tone: "warn" as const },
    { key: "actif", label: "actifs", value: abonnements.filter((a) => a.statut === "actif").length, tone: "accent" as const },
    { key: "expirant", label: "expirant bientôt", value: abonnements.filter((a) => a.statut === "expirant").length, tone: "warn" as const },
    { key: "expire", label: "expirés", value: abonnements.filter((a) => a.statut === "expire").length, tone: "danger" as const },
    { key: "suspendu", label: "suspendus", value: abonnements.filter((a) => a.statut === "suspendu").length, tone: "danger" as const },
  ];
  return <PageStatsCard title="Abonnements" stats={stats} active={value} onSelect={toggle} />;
}

export default function AbonnementsPage() {
  const { abonnements, getClient } = useAdminData();
  const [page, setPage] = useState(1);
  const { value: filter, setValue: setFilter } = useAdminFilter("abonnements");
  const visibles = filter === ALL ? abonnements : abonnements.filter((a) => a.statut === filter);

  useEffect(() => setPage(1), [filter]);
  useEffect(() => () => setFilter(ALL), [setFilter]);
  const { ref, rows: pageSize, rootStyle } = useFitRows({ list: "tbody", item: "tbody tr" });

  const totalPages = Math.max(1, Math.ceil(visibles.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = visibles.slice((current - 1) * pageSize, current * pageSize);

  return (
    <div ref={ref} style={rootStyle}>
      <motion.div className="ad-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        {visibles.length === 0 ? (
          <EmptyState icon={<IconLayers width={22} height={22} />} text="Aucun abonnement dans cette catégorie" />
        ) : (
          <div className="ad-table-wrap">
            <table className="ad-table">
              <thead>
                <tr>
                  <th>Client</th>
                  <th>Formule</th>
                  <th>Début</th>
                  <th>Fin</th>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((a) => {
                  const c = getClient(a.clientId);
                  return (
                    <tr key={a.id} className="ad-table-row">
                      <td>
                        <Link href={`/prevadm/abonnements/${a.id}`} className="ad-table-link-name">
                          <span className="ad-table-name">{c ? fullName(c) : "—"}</span>
                        </Link>
                      </td>
                      <td>{a.formule}</td>
                      <td>{a.dateDebut}</td>
                      <td>{a.dateFin}</td>
                      <td>
                        <StatusBadge status={a.statut} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      <Pagination page={current} totalPages={totalPages} onChange={setPage} />
    </div>
  );
}
