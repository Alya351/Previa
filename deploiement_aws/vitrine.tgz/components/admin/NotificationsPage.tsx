"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "motion/react";
import { IconBell, IconSend, IconLayers, IconSettings } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import EmptyState from "./EmptyState";
import MessagesPage from "./MessagesPage";
import { ALL, useAdminFilter } from "@/lib/adminFilter";
import PageStatsCard from "./PageStatsCard";
import Pagination from "./Pagination";
import { useFitRows } from "./useFitRows";

export function NotificationsInfoCard() {
  const { notifications, messages } = useAdminData();
  const { value, setValue, toggle } = useAdminFilter("notifications");
  const stats = [
    { key: ALL, label: "total", value: notifications.length },
    { key: "non_lues", label: "non lues", value: notifications.filter((n) => !n.read).length, tone: "accent" as const },
    { key: "demande", label: "demandes", value: notifications.filter((n) => n.kind === "demande").length },
    { key: "abonnement", label: "abonnements", value: notifications.filter((n) => n.kind === "abonnement").length },
    { key: "messages", label: "messages", value: messages.filter((m) => !m.traite).length },
  ];
  return (
    <PageStatsCard
      title="Notifications"
      stats={stats}
      active={value}
      onSelect={(k) => (k === ALL ? setValue(ALL) : toggle(k))}
    />
  );
}

const ICON_FOR = {
  demande: IconSend,
  abonnement: IconLayers,
  systeme: IconSettings,
} as const;

const SEGMENTS = [
  { id: ALL, label: "Toutes" },
  { id: "non_lues", label: "Non lues" },
  { id: "lues", label: "Lues" },
] as const;

export default function NotificationsPage() {
  const { notifications, markAllNotificationsRead } = useAdminData();
  const { value: segment, setValue: setSegment } = useAdminFilter("notifications");
  const [page, setPage] = useState(1);
  const { ref, rows: pageSize, rootStyle } = useFitRows({ list: ".ad-notiflist", item: ".ad-notifrow", fallbackRow: 84 });

  const filtered = useMemo(() => {
    if (segment === "non_lues") return notifications.filter((n) => !n.read);
    if (segment === "lues") return notifications.filter((n) => n.read);
    if (segment === "demande" || segment === "abonnement") return notifications.filter((n) => n.kind === segment);
    return notifications;
  }, [notifications, segment]);

  useEffect(() => setPage(1), [segment]);
  useEffect(() => () => setSegment(ALL), [setSegment]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = filtered.slice((current - 1) * pageSize, current * pageSize);

  // La carte « messages » du bandeau ouvre les messages de contact / devis à la place des notifications.
  if (segment === "messages") return <MessagesPage />;

  return (
    <div ref={ref} style={rootStyle}>
      <motion.div className="ad-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <div className="ad-card-head">
          <h2>Vos notifications</h2>
          <button type="button" className="ad-table-link" onClick={markAllNotificationsRead}>
            Tout marquer comme lu
          </button>
        </div>

        <div className="ad-segmented" role="tablist" aria-label="Filtrer les notifications">
          {SEGMENTS.map((s) => (
            <button
              key={s.id}
              type="button"
              role="tab"
              aria-selected={segment === s.id}
              className={`ad-segmented-btn ${segment === s.id ? "is-active" : ""}`}
              onClick={() => setSegment(s.id)}
            >
              {s.label}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <EmptyState icon={<IconBell width={22} height={22} />} text="Aucune notification dans cette catégorie" />
        ) : (
          <div className="ad-notiflist">
            {paged.map((n, i) => {
              const Icon = ICON_FOR[n.kind];
              return (
                <motion.div
                  key={n.id}
                  className="ad-notifrow"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.03 }}
                >
                  <span className="ad-notifrow-icon">
                    <Icon width={19} height={19} />
                  </span>
                  <div className="ad-notifrow-body">
                    <div className="ad-notifrow-head">
                      <p className="ad-notifrow-title">
                        {!n.read && <span className="ad-notifrow-bullet" aria-hidden />}
                        {n.title}
                      </p>
                      <span className="ad-notifrow-date">{n.date}</span>
                    </div>
                    <p className="ad-notifrow-text">{n.text}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </motion.div>

      <Pagination page={current} totalPages={totalPages} onChange={setPage} />
    </div>
  );
}
