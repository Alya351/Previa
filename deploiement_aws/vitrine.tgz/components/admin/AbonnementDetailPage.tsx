"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import { IconChevronRight } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { fullName, initialsOfName } from "@/lib/adminData";
import { ApiError } from "@/lib/api";
import StatusBadge from "./StatusBadge";
import DetailTable from "./DetailTable";
import { durationLabel } from "@/components/espace/types";
import ConfirmDialog from "./ConfirmDialog";
import { useToast } from "./ToastContext";

type Action = null | "suspendre" | "terminer" | "prolonger" | "reactiver";

export default function AbonnementDetailPage({ id }: { id: string }) {
  const { getAbonnementById, getClient, prolongerAbonnement, suspendreAbonnement, reactiverAbonnement, terminerAbonnement } =
    useAdminData();
  const { show, error } = useToast();
  const [confirm, setConfirm] = useState<Action>(null);
  // Modèle annuel : une prolongation manuelle ajoute toujours 1 an.
  const dureeMois = 12;
  const [busy, setBusy] = useState(false);

  const abonnement = getAbonnementById(id);
  const client = abonnement ? getClient(abonnement.clientId) : undefined;

  if (!abonnement || !client) {
    return (
      <div className="ad-card">
        <p>Abonnement introuvable.</p>
        <Link href="/prevadm/abonnements" className="ad-table-link">
          Retour à la liste
        </Link>
      </div>
    );
  }

  const s = abonnement.statut;
  const canProlong = s === "actif" || s === "expirant" || s === "expire" || s === "suspendu";
  const canSuspend = s === "actif" || s === "expirant";
  const canReactivate = s === "suspendu";
  const canTerminate = s !== "termine";

  const run = async (action: Exclude<Action, null>) => {
    if (busy) return;
    setBusy(true);
    const name = fullName(client);
    try {
      if (action === "suspendre") {
        await suspendreAbonnement(abonnement.id);
        show(`Abonnement de ${name} suspendu.`);
      } else if (action === "terminer") {
        await terminerAbonnement(abonnement.id);
        show(`Abonnement de ${name} terminé.`);
      } else if (action === "reactiver") {
        await reactiverAbonnement(abonnement.id);
        show(`Abonnement de ${name} réactivé.`);
      } else {
        await prolongerAbonnement(abonnement.id, dureeMois);
        show(`Abonnement de ${name} prolongé d'un an.`);
      }
      setConfirm(null);
    } catch (err) {
      error(err instanceof ApiError ? err.message : "L'action a échoué.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <Link href="/prevadm/abonnements" className="ad-back-link">
        <span className="ad-back-link-icon">
          <IconChevronRight width={13} height={13} style={{ transform: "rotate(180deg)" }} />
        </span>
        Retour aux abonnements
      </Link>

      <motion.div className="ad-card ad-card--profile" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} style={{ marginBottom: 16 }}>
        <div className="ad-profile-head">
          <span className="ad-profile-avatar">{initialsOfName(client.prenom, client.nom)}</span>
          <div>
            <h2>{fullName(client)}</h2>
            <p>{client.email}</p>
          </div>
          <span style={{ marginLeft: "auto" }}>
            <StatusBadge status={abonnement.statut} />
          </span>
        </div>
      </motion.div>

      <motion.div className="ad-card ad-card--narrow" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: 0.05 }}>
        <div className="ad-card-head">
          <h2>Détails de l&apos;abonnement</h2>
        </div>
        <DetailTable
          rows={[
            {
              label: "Client",
              value: (
                <Link href={`/prevadm/clients/${client.id}`} className="ad-table-link">
                  {fullName(client)}
                </Link>
              ),
            },
            { label: "Formule", value: abonnement.formule },
            { label: "Début", value: abonnement.dateDebut },
            { label: "Fin", value: abonnement.dateFin },
            { label: "Statut", value: <StatusBadge status={abonnement.statut} /> },
          ]}
        />

        {s === "en_attente_code" ? (
          <div className="ad-detail-actions">
            <Link href={`/prevadm/demandes/${abonnement.id}`} className="btn btn-primary">
              Traiter la demande (code d&apos;activation)
            </Link>
            {canTerminate && (
              <button type="button" className="btn btn-secondary" onClick={() => setConfirm("terminer")}>
                Terminer
              </button>
            )}
          </div>
        ) : (
          <div className="ad-detail-actions">
            {canProlong && (
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  setConfirm("prolonger");
                }}
              >
                Prolonger
              </button>
            )}
            {canReactivate && (
              <button type="button" className="btn btn-secondary" onClick={() => setConfirm("reactiver")}>
                Réactiver
              </button>
            )}
            {canSuspend && (
              <button type="button" className="btn btn-secondary" onClick={() => setConfirm("suspendre")}>
                Suspendre
              </button>
            )}
            {canTerminate && (
              <button type="button" className="btn btn-secondary" onClick={() => setConfirm("terminer")}>
                Terminer
              </button>
            )}
          </div>
        )}
      </motion.div>

      {abonnement.periodes.length > 0 && (
        <motion.div className="ad-card ad-card--narrow" style={{ marginTop: 16 }} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: 0.1 }}>
          <div className="ad-card-head">
            <h2>Historique des abonnements</h2>
          </div>
          <div className="ad-table-wrap">
            <table className="ad-table">
              <thead>
                <tr>
                  <th>Période</th>
                  <th>Formule</th>
                  <th>Début</th>
                  <th>Fin</th>
                </tr>
              </thead>
              <tbody>
                {abonnement.periodes.map((p) => (
                  <tr key={p.id}>
                    <td>
                      {durationLabel(p.dureeMois)}{p.source === "manuel" ? " (manuel)" : ""}
                    </td>
                    <td>{p.formule}</td>
                    <td>{p.debut}</td>
                    <td>{p.fin}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      <ConfirmDialog
        open={confirm !== null}
        title={
          confirm === "suspendre"
            ? "Suspendre cet abonnement ?"
            : confirm === "terminer"
              ? "Terminer cet abonnement ?"
              : confirm === "reactiver"
                ? "Réactiver cet abonnement ?"
                : "Prolonger cet abonnement"
        }
        text={
          confirm === "suspendre"
            ? `L'accès de ${fullName(client)} sera suspendu jusqu'à réactivation.`
            : confirm === "terminer"
              ? `L'abonnement de ${fullName(client)} sera définitivement marqué comme terminé.`
              : confirm === "reactiver"
                ? `L'abonnement de ${fullName(client)} redeviendra actif (la date de fin ne change pas).`
                : `Ajouter 1 an à l'abonnement de ${fullName(client)} (actuellement jusqu'au ${abonnement.dateFin}), sans paiement.`
        }
        danger={confirm === "terminer"}
        disabled={busy}
        confirmLabel={
          confirm === "suspendre"
            ? "Suspendre"
            : confirm === "terminer"
              ? "Terminer"
              : confirm === "reactiver"
                ? "Réactiver"
                : "Prolonger d'un an"
        }
        onCancel={() => setConfirm(null)}
        onConfirm={() => confirm && run(confirm)}
      >
      </ConfirmDialog>
    </div>
  );
}
