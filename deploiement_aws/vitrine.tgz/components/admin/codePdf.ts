import { tr, currentLang } from "@/lib/i18n/translate";

export type CodePdfData = {
  reference: string;
  clientName: string;
  clientEmail: string;
  formule: string;
  dateDemande: string;
  dateEnvoi?: string;
  dateExpiration: string;
  /** Code en clair (8 chiffres), récupéré auprès de l'API au moment de générer le PDF. */
  code: string;
};

const BLUE: [number, number, number] = [0, 158, 227];
const DARK: [number, number, number] = [22, 50, 63];
const MUTED: [number, number, number] = [107, 125, 136];

/** Génère et télécharge le PDF du code d'activation d'une demande. */
export async function downloadCodePdf(data: CodePdfData) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const marginX = 56;
  let y = 64;

  const code = data.code.replace(/(\d{4})(\d{4})/, "$1 $2");
  const emisLe = new Intl.DateTimeFormat(currentLang() === "en" ? "en-GB" : "fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date());

  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(...BLUE);
  doc.text("Previa", marginX, y);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  doc.text(tr("Surveillance intelligente. Anticipation renforcée."), marginX, y + 14);
  doc.text(tr(`Émis le ${emisLe}`), pageWidth - marginX, y, { align: "right" });

  y += 30;
  doc.setDrawColor(...BLUE);
  doc.setLineWidth(1.4);
  doc.line(marginX, y, pageWidth - marginX, y);

  y += 36;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.setTextColor(...DARK);
  doc.text(tr("Code d'activation"), marginX, y);

  y += 16;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...MUTED);
  doc.text(tr(`Demande #${data.reference}`), marginX, y);

  y += 28;
  const boxHeight = 70;
  doc.setFillColor(242, 250, 253);
  doc.setDrawColor(...BLUE);
  doc.setLineDashPattern([3, 2], 0);
  doc.roundedRect(marginX, y, pageWidth - marginX * 2, boxHeight, 8, 8, "FD");
  doc.setLineDashPattern([], 0);

  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  doc.text(tr("CODE D'ACTIVATION"), pageWidth / 2, y + 24, { align: "center" });
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.setTextColor(...DARK);
  doc.text(code, pageWidth / 2, y + 50, { align: "center" });

  y += boxHeight + 34;

  const rows: [string, string][] = [
    [tr("Client"), data.clientName],
    [tr("E-mail"), data.clientEmail],
    [tr("Abonnement"), tr(data.formule)],
    [tr("Date de la demande"), tr(data.dateDemande)],
    [tr("Date d'envoi"), data.dateEnvoi ? tr(data.dateEnvoi) : "—"],
    [tr("Date d'expiration"), tr(data.dateExpiration)],
  ];

  doc.setFontSize(10.5);
  for (const [label, value] of rows) {
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...MUTED);
    doc.text(label, marginX, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...DARK);
    doc.text(value, pageWidth - marginX, y, { align: "right" });
    doc.setDrawColor(238, 242, 245);
    doc.setLineWidth(0.6);
    doc.line(marginX, y + 6, pageWidth - marginX, y + 6);
    y += 24;
  }

  y += 20;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(...MUTED);
  doc.text(
    doc.splitTextToSize(
      tr(
        "Ce code d'activation Previa est personnel et à usage unique. Il permet l'inscription du premier administrateur sur la plateforme. Ne le partagez pas."
      ),
      pageWidth - marginX * 2
    ),
    pageWidth / 2,
    y,
    { align: "center" }
  );

  doc.save(`code-amorcage-${data.reference}.pdf`);
}
