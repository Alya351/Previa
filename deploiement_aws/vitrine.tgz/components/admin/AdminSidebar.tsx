"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "motion/react";
import Logo from "@/components/home/Logo";
import {
  IconGrid,
  IconUsers,
  IconSend,
  IconLayers,
  IconBell,
  IconClock,
  IconDownload,
  IconArrowRight,
} from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";

const MENU = [
  { href: "/prevadm", label: "Dashboard", icon: IconGrid },
  { href: "/prevadm/clients", label: "Clients", icon: IconUsers },
  { href: "/prevadm/demandes", label: "Demandes", icon: IconSend, badgeKey: "demandes" },
  { href: "/prevadm/abonnements", label: "Abonnements", icon: IconLayers },
  { href: "/prevadm/notifications", label: "Notifications", icon: IconBell, badgeKey: "notifications" },
  { href: "/prevadm/historique", label: "Historique", icon: IconClock },
] as const;

/** Barre latérale du Superadmin : logo, menu, raccourcis et carte « application ». */
export default function AdminSidebar() {
  const pathname = usePathname();
  const { demandes, unreadCount } = useAdminData();
  // Demandes dont le code n'a pas encore été envoyé au client.
  const pendingCount = demandes.filter((d) => !d.codeEnvoye).length;
  const badgeValue: Record<string, number> = { demandes: pendingCount, notifications: unreadCount };

  return (
    <motion.aside
      className="ad-sidebar"
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className="ad-side-inner">
        <Link href="/prevadm" className="ad-side-logo" aria-label="Previa — Superadministration">
          <Logo height={26} />
        </Link>

        <nav className="ad-side-nav" aria-label="Navigation Superadmin">
          <p className="ad-side-label">Menu</p>
          <ul className="ad-side-list">
            {MENU.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.href || (item.href !== "/prevadm" && pathname.startsWith(item.href));
              const badge = "badgeKey" in item ? badgeValue[item.badgeKey] : 0;
              return (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    className={`ad-side-item ${active ? "is-active" : ""}`}
                    aria-current={active ? "page" : undefined}
                  >
                    <Icon width={18} height={18} />
                    <span className="ad-side-item-label">{item.label}</span>
                    {badge > 0 && <span className="ad-side-badge">{badge}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>

        </nav>

        <div className="ad-side-promo">
          <span className="ad-side-promo-ring ad-side-promo-ring--a" aria-hidden />
          <span className="ad-side-promo-ring ad-side-promo-ring--b" aria-hidden />
          <span className="ad-side-promo-icon">
            <IconDownload width={16} height={16} />
          </span>
          <p className="ad-side-promo-title">Téléchargez l&apos;application Previa</p>
          <p className="ad-side-promo-sub">Surveillance intelligente, partout.</p>
          <Link href="/telechargement" className="ad-side-promo-btn">
            Télécharger
            <IconArrowRight width={14} height={14} />
          </Link>
        </div>
      </div>
    </motion.aside>
  );
}
