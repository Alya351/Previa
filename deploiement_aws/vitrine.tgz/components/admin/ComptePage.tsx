"use client";

import { useEffect, useState, type ReactNode } from "react";
import { useSearchParams } from "next/navigation";
import { motion } from "motion/react";
import {
  IconLock,
  IconMail,
  IconPackage,
  IconSettings,
  IconTarget,
  IconUser,
  IconUsers,
} from "@/components/home/icons";
import { useAdminUser, setAdminUser, readAdminToken } from "@/lib/adminAuth";
import { api, ApiError } from "@/lib/api";
import { useToast } from "./ToastContext";
import { useAdminData } from "./AdminDataContext";
import FormModal, { FormField, FormSubmit } from "./FormModal";
import AdminsModal from "./AdminsModal";
import LangModal from "./LangModal";
import OffresModal from "./OffresModal";

const EASE = [0.22, 1, 0.36, 1] as const;

type Panel = "profil" | "securite" | "preferences" | "equipe" | "activite" | "offres";

/** Carte pleine largeur : badge-goutte à gauche, titre + description à droite ; un clic ouvre le détail. */
function PinCard({
  index,
  variant,
  icon,
  title,
  description,
  onOpen,
}: {
  index: number;
  variant: "sky" | "navy" | "azure" | "steel";
  icon: ReactNode;
  title: string;
  description: string;
  onOpen: () => void;
}) {
  return (
    <motion.button
      type="button"
      className={`cp-tile cp-tile--pin cp-tile--${variant}`}
      onClick={onOpen}
      aria-label={`${title} — ${description}`}
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.06 * index, ease: EASE }}
    >
      <span className="cp-pin" aria-hidden>
        {icon}
      </span>
      <span className="cp-pin-body">
        <strong className="cp-pin-title">{title}</strong>
        <span className="cp-pin-rule" aria-hidden />
        <span className="cp-pin-desc">{description}</span>
      </span>
    </motion.button>
  );
}

export default function ComptePage({
  initialPanel,
  mode = "parametres",
}: { initialPanel?: Panel; mode?: "compte" | "parametres" } = {}) {
  const admin = useAdminUser();
  const { historique } = useAdminData();
  const { show, error } = useToast();
  const searchParams = useSearchParams();
  const [panel, setPanel] = useState<Panel | null>(initialPanel ?? null);

  useEffect(() => {
    const open = searchParams.get("open");
    if (
      open === "profil" ||
      open === "securite" ||
      open === "preferences" ||
      open === "equipe" ||
      open === "activite" ||
      open === "offres"
    ) {
      setPanel(open);
    } else if (initialPanel) {
      setPanel(initialPanel);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [syncedEmail, setSyncedEmail] = useState<string | null>(null);

  if (admin && syncedEmail !== admin.email) {
    setSyncedEmail(admin.email);
    setNom(admin.nom);
    setPrenom(admin.prenom);
  }

  const [currentPwd, setCurrentPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");

  const [teamCount, setTeamCount] = useState<number | null>(null);
  const refreshTeamCount = () => {
    const t = readAdminToken();
    if (!t) return;
    api.admin
      .comptes(t)
      .then((list) => setTeamCount(list.length))
      .catch(() => {});
  };
  useEffect(refreshTeamCount, []);

  // R59 : chaque action loguée porte le nom de son auteur (auteur_nom, figé au moment de l'action).
  const myName = admin ? `${admin.prenom} ${admin.nom}` : "";
  const myActions = historique.filter((h) => h.auteur === myName);
  const countBy = (categorie: string) => myActions.filter((h) => h.categorie === categorie).length;

  if (!admin) return null;

  const close = () => {
    if (panel === "equipe") refreshTeamCount();
    setPanel(null);
  };
  const fail = (err: unknown, fallback: string) => error(err instanceof ApiError ? err.message : fallback);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = readAdminToken();
    if (!t) return;
    try {
      const res = await api.admin.updateMe(t, { prenom: prenom.trim(), nom: nom.trim() });
      setAdminUser({ id: res.id, nom: res.nom, prenom: res.prenom, email: res.email, token: t });
      show("Profil mis à jour.");
      close();
    } catch (err) {
      fail(err, "Mise à jour impossible.");
    }
  };

  const savePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = readAdminToken();
    if (!t) return;
    if (!currentPwd || !newPwd || newPwd !== confirmPwd) {
      error("Vérifiez les champs du mot de passe.");
      return;
    }
    try {
      const res = await api.admin.changePassword(t, currentPwd, newPwd);
      // Les autres sessions sont révoquées : on garde la nôtre avec le nouveau jeton.
      setAdminUser({ id: admin.id, nom: admin.nom, prenom: admin.prenom, email: admin.email, token: res.accessToken });
      setCurrentPwd("");
      setNewPwd("");
      setConfirmPwd("");
      show("Mot de passe mis à jour.");
      close();
    } catch (err) {
      fail(err, "Changement de mot de passe impossible.");
    }
  };


  return (
    <div className="cp-page">
      <div className="cp-tiles">
        {mode === "compte" ? (
          <>
            <PinCard
              index={0}
              variant="sky"
              icon={<IconUser width={26} height={26} />}
              title="Profil"
              description={`${admin.prenom} ${admin.nom} · ${admin.email}`}
              onOpen={() => setPanel("profil")}
            />
            <PinCard
              index={1}
              variant="navy"
              icon={<IconTarget width={26} height={26} />}
              title="Mon activité"
              description={`${myActions.length} action${myActions.length > 1 ? "s" : ""} récente${myActions.length > 1 ? "s" : ""}`}
              onOpen={() => setPanel("activite")}
            />
          </>
        ) : (
          <>
            <PinCard
              index={0}
              variant="navy"
              icon={<IconLock width={26} height={26} />}
              title="Sécurité"
              description="Mot de passe et gestion de la session."
              onOpen={() => setPanel("securite")}
            />
            <PinCard
              index={1}
              variant="azure"
              icon={<IconSettings width={26} height={26} />}
              title="Préférences"
              description="Langue de l'interface."
              onOpen={() => setPanel("preferences")}
            />
            <PinCard
              index={2}
              variant="steel"
              icon={<IconUsers width={26} height={26} />}
              title="Équipe"
              description={teamCount !== null ? `${teamCount} superadmin${teamCount > 1 ? "s" : ""}` : "Superadmins Previa"}
              onOpen={() => setPanel("equipe")}
            />
            <PinCard
              index={3}
              variant="sky"
              icon={<IconPackage width={26} height={26} />}
              title="Offres"
              description="Prix et caméras des offres."
              onOpen={() => setPanel("offres")}
            />
          </>
        )}
      </div>

      <FormModal open={panel === "profil"} onClose={close} icon={<IconUser width={44} height={44} />} title="Modifier le profil">
        <form onSubmit={saveProfile} className="fm-form">
          <FormField icon={<IconUser width={18} height={18} />} label="Prénom" value={prenom} onChange={setPrenom} autoComplete="given-name" />
          <FormField icon={<IconUser width={18} height={18} />} label="Nom" value={nom} onChange={setNom} autoComplete="family-name" />
          <FormField icon={<IconMail width={18} height={18} />} label="E-mail" value={admin.email} readOnly />
          <FormSubmit>Enregistrer</FormSubmit>
        </form>
      </FormModal>

      <FormModal open={panel === "securite"} onClose={close} icon={<IconLock width={44} height={44} />} title="Mot de passe">
        <form onSubmit={savePassword} className="fm-form">
          <FormField icon={<IconLock width={18} height={18} />} label="Mot de passe actuel" type="password" value={currentPwd} onChange={setCurrentPwd} autoComplete="current-password" />
          <FormField icon={<IconLock width={18} height={18} />} label="Nouveau mot de passe" type="password" value={newPwd} onChange={setNewPwd} autoComplete="new-password" />
          <FormField icon={<IconLock width={18} height={18} />} label="Confirmation" type="password" value={confirmPwd} onChange={setConfirmPwd} autoComplete="new-password" />
          <FormSubmit>Changer le mot de passe</FormSubmit>
        </form>
      </FormModal>

      <LangModal open={panel === "preferences"} onClose={close} />

      <AdminsModal open={panel === "equipe"} onClose={close} admin={admin} />

      <OffresModal open={panel === "offres"} onClose={close} />

      <FormModal open={panel === "activite"} onClose={close} icon={<IconTarget width={44} height={44} />} title="Mon activité">
        <ul className="cp-stat-list">
          {[
            { label: "Codes générés/envoyés", value: countBy("codes") },
            { label: "Clients modifiés", value: countBy("clients") },
            { label: "Abonnements gérés", value: countBy("abonnements") },
            { label: "Messages traités", value: countBy("messages") },
            { label: "Actions au total", value: myActions.length },
          ].map((row) => (
            <li key={row.label} className="cp-stat-row">
              <span className="cp-stat-label">{row.label}</span>
              <span className="cp-stat-value">{row.value}</span>
            </li>
          ))}
        </ul>
      </FormModal>
    </div>
  );
}
