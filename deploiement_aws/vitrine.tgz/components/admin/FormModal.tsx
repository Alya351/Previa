"use client";

import { useEffect, useId, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "motion/react";
import { IconClose, IconEye, IconEyeOff } from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Badge heptagonal posé à cheval sur le bord haut de la carte (contour blanc, cœur bleu Previa). */
function Badge({ children }: { children: ReactNode }) {
  return (
    <span className="fm-badge" aria-hidden>
      <svg viewBox="0 0 100 100" className="fm-badge-shape">
        <polygon points="50,3 86,20 95,59 70,91 30,91 5,59 14,20" className="fm-badge-outer" />
        <polygon points="50,12 79,26 87,57 66,83 34,83 13,57 21,26" className="fm-badge-inner" />
      </svg>
      <span className="fm-badge-icon">{children}</span>
    </span>
  );
}

/**
 * Faisceau lumineux qui court sur le contour de la carte ET contourne l'hexagone :
 * le tracé longe le bord haut, monte le long de l'hexagone (à quelques pixels de son bord), puis repart.
 * Il est recalculé quand la carte change de taille.
 */
const RING_LAYERS = [
  { len: 0.34, op: 0.16, color: "#3fb4f5" },
  { len: 0.26, op: 0.2, color: "#4fc3ff" },
  { len: 0.19, op: 0.26, color: "#5fcbff" },
  { len: 0.13, op: 0.34, color: "#7fd8ff" },
  { len: 0.08, op: 0.55, color: "#a8e6ff" },
  { len: 0.04, op: 0.95, color: "#ffffff" },
];

function ringPath(w: number, h: number, radius: number): string {
  const cx = w / 2;
  const r = Math.max(radius, 8);
  // Hexagone (badge de 118 px centré sur le bord haut), agrandi de 10 % pour que le faisceau le longe sans le toucher.
  const k = 1.298;
  const px = (x: number) => cx + (x - 50) * k;
  const py = (y: number) => 1 + (y - 50) * k;
  const sideX = 7.08; // abscisse (repère 0-100) où l'arête gauche coupe le bord haut de la carte
  return [
    `M ${r} 1`,
    `H ${px(sideX)}`,
    `L ${px(14)} ${py(20)}`,
    `L ${px(50)} ${py(3)}`,
    `L ${px(86)} ${py(20)}`,
    `L ${px(100 - sideX)} 1`,
    `H ${w - r}`,
    `A ${r - 1} ${r - 1} 0 0 1 ${w - 1} ${r}`,
    `V ${h - r}`,
    `A ${r - 1} ${r - 1} 0 0 1 ${w - r} ${h - 1}`,
    `H ${r}`,
    `A ${r - 1} ${r - 1} 0 0 1 1 ${h - r}`,
    `V ${r}`,
    `A ${r - 1} ${r - 1} 0 0 1 ${r} 1`,
    "Z",
  ].join(" ");
}

function RingBorder() {
  const ref = useRef<SVGSVGElement>(null);
  const [geo, setGeo] = useState({ w: 0, h: 0, d: "" });

  useLayoutEffect(() => {
    const card = ref.current?.parentElement;
    if (!card) return;
    const update = () => {
      const w = card.offsetWidth;
      const h = card.offsetHeight;
      const radius = parseFloat(getComputedStyle(card).borderTopLeftRadius) || 38;
      setGeo({ w, h, d: ringPath(w, h, radius) });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(card);
    return () => ro.disconnect();
  }, []);

  return (
    <svg ref={ref} className="fm-ring" width={geo.w} height={geo.h} aria-hidden>
      {geo.d &&
        RING_LAYERS.map((l) => (
          <path
            key={l.len}
            d={geo.d}
            pathLength={1}
            style={{ "--L": l.len, stroke: l.color, strokeOpacity: l.op } as CSSProperties}
          />
        ))}
    </svg>
  );
}

/** Coque commune : portail dans <body>, arrière-plan flouté, fermeture par clic extérieur ou Échap. */
export function ModalShell({
  open,
  onClose,
  label,
  maxWidth,
  className,
  children,
}: {
  open: boolean;
  onClose: () => void;
  label: string;
  maxWidth: number;
  className: string;
  children: ReactNode;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // Pendant qu'une fenêtre est ouverte, la page derrière ne défile pas (pas de barre de défilement qui clignote).
  useEffect(() => {
    if (!open) return;
    document.documentElement.classList.add("fm-open");
    return () => document.documentElement.classList.remove("fm-open");
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!mounted) return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="fm-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
        >
          <span className="fm-liquid" aria-hidden>
            <i className="fm-blob fm-blob--1" />
            <i className="fm-blob fm-blob--2" />
            <i className="fm-blob fm-blob--3" />
            <i className="fm-glass" />
          </span>
          <motion.div
            className={className}
            role="dialog"
            aria-modal="true"
            aria-label={label}
            style={{ maxWidth }}
            initial={{ opacity: 0, scale: 0.94, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.3, ease: EASE }}
            onClick={(e) => e.stopPropagation()}
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}

/** Fenêtre de formulaire « carte bleue » : badge hexagonal, bouton fermer rond, titre en capitales espacées. */
export default function FormModal({
  open,
  onClose,
  icon,
  title,
  children,
  maxWidth = 380,
}: {
  open: boolean;
  onClose: () => void;
  icon: ReactNode;
  title: string;
  children: ReactNode;
  maxWidth?: number;
}) {
  return (
    <ModalShell open={open} onClose={onClose} label={title} maxWidth={maxWidth} className="fm-card">
      <RingBorder />
      <Badge>{icon}</Badge>
      <button type="button" className="fm-close" aria-label="Fermer" onClick={onClose}>
        <IconClose width={14} height={14} />
      </button>
      <h3 className="fm-title">{title}</h3>
      {children}
    </ModalShell>
  );
}

/** Champ en pilule blanche : pictogramme bleu à gauche, libellé en capitales comme texte d'invite. */
export function FormField({
  icon,
  label,
  value,
  onChange,
  type = "text",
  autoComplete,
  readOnly,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  onChange?: (v: string) => void;
  type?: string;
  autoComplete?: string;
  readOnly?: boolean;
}) {
  const id = useId();
  const [shown, setShown] = useState(false);
  const isPassword = type === "password";
  return (
    <label className={`fm-field${readOnly ? " is-readonly" : ""}`} htmlFor={id}>
      <span className="fm-field-icon">{icon}</span>
      <input
        id={id}
        type={isPassword && shown ? "text" : type}
        value={value}
        placeholder={label}
        aria-label={label}
        autoComplete={autoComplete}
        readOnly={readOnly}
        onChange={(e) => onChange?.(e.target.value)}
      />
      {isPassword && (
        <button
          type="button"
          className="fm-field-eye"
          aria-label={shown ? "Masquer le mot de passe" : "Afficher le mot de passe"}
          onClick={() => setShown((s) => !s)}
        >
          {shown ? <IconEyeOff width={16} height={16} /> : <IconEye width={16} height={16} />}
        </button>
      )}
    </label>
  );
}

/** Bouton d'envoi : petite pilule blanche, texte bleu en capitales. */
export function FormSubmit({ children, disabled }: { children: ReactNode; disabled?: boolean }) {
  return (
    <button type="submit" className="fm-submit" disabled={disabled}>
      {children}
    </button>
  );
}
