"use client";

import { IconChevronRight } from "@/components/home/icons";

/** Boutons de navigation entre les pages d'une liste (jamais de défilement). */
export default function Pagination({
  page,
  totalPages,
  onChange,
}: {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  return (
    <nav className="ad-pagination" aria-label="Pagination">
      <button
        type="button"
        className="ad-page-btn ad-page-btn--nav"
        disabled={page === 1}
        onClick={() => onChange(Math.max(1, page - 1))}
        aria-label="Page précédente"
      >
        <IconChevronRight width={14} height={14} style={{ transform: "rotate(180deg)" }} />
      </button>
      {Array.from({ length: totalPages }, (_, i) => (
        <button
          key={i}
          type="button"
          className={`ad-page-btn ${page === i + 1 ? "is-active" : ""}`}
          aria-current={page === i + 1 ? "page" : undefined}
          onClick={() => onChange(i + 1)}
        >
          {i + 1}
        </button>
      ))}
      <button
        type="button"
        className="ad-page-btn ad-page-btn--nav"
        disabled={page === totalPages}
        onClick={() => onChange(Math.min(totalPages, page + 1))}
        aria-label="Page suivante"
      >
        <IconChevronRight width={14} height={14} />
      </button>
    </nav>
  );
}
