"use client";

import { useAdminUser } from "@/lib/adminAuth";
import AdminAuthPage from "./AdminAuthPage";
import AdminShell from "./AdminShell";
import DashboardPage from "./DashboardPage";

export default function AdminRootGate() {
  const admin = useAdminUser();

  if (admin === undefined) return null;
  if (admin === null) return <AdminAuthPage />;

  return (
    <AdminShell title="Dashboard" subtitle={`Bonjour ${admin.prenom}, voici l'activité de votre plateforme Previa.`}>
      <DashboardPage />
    </AdminShell>
  );
}
