import type { ReactNode } from "react";

export type DetailRow = { label: string; value: ReactNode };

/** Tableau à deux colonnes (champ / valeur), stylisé comme les listes
 *  admin (.ad-table) plutôt qu'une simple liste dt/dd. */
export default function DetailTable({ rows }: { rows: DetailRow[] }) {
  return (
    <div className="ad-table-wrap ad-table-wrap--detail">
      <table className="ad-table ad-table--detail">
        <tbody>
          {rows.map((r) => (
            <tr key={r.label} className="ad-table-row">
              <td className="ad-table-name">{r.label}</td>
              <td>{r.value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
