"use client";

import { durationLabel } from "@/components/espace/types";
import { useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import {
  IconChevronRight,
  IconKeyRound,
  IconCopy,
  IconDownload,
  IconSend,
  IconEye,
  IconEyeOff,
} from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { fullName } from "@/lib/adminData";
import { ApiError } from "@/lib/api";
import StatusBadge from "./StatusBadge";
import DetailTable from "./DetailTable";
import ConfirmDialog from "./ConfirmDialog";
import { useToast } from "./ToastContext";
import { downloadCodePdf } from "./codePdf";

const EASE = [0.22, 1, 0.36, 1] as const;

function maskCode(code: string) {
  return `${code.slice(0, 2)}•• ••${code.slice(6)}`;
}

type Confirm = null | "generer" | "envoyer" | "desactiver";

export default function DemandeDetailPage({ id }: { id: string }) {
  const { demandes, getClient, getAbonnementById, genererCode, envoyerCode, voirCode, toggleActifCode } = useAdminData();
  const { show, error } = useToast();
  const [confirm, setConfirm] = useState<Confirm>(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  // Le code en clair n'est chargé qu'à la demande (icône œil, copie, PDF) — R53.
  const [plain, setPlain] = useState<string | null>(null);
  const [revealed, setRevealed] = useState(false);

  const demande = demandes.find((d) => d.id === id);
  const client = demande ? getClient(demande.clientId) : undefined;
  const abonnement = demande ? getAbonnementById(demande.id) : undefined;

  if (!demande || !client) {
    return (
      <div className="ad-card">
        <p>Demande introuvable.</p>
        <Link href="/prevadm/demandes" className="ad-table-link">
          Retour à la liste
        </Link>
      </div>
    );
  }

  const fail = (err: unknown, fallback: string) => error(err instanceof ApiError ? err.message : fallback);

  const loadCode = async (): Promise<string> => {
    if (plain) return plain;
    const code = await voirCode(demande.id);
    setPlain(code);
    return code;
  };

  const toggleReveal = async () => {
    try {
      await loadCode();
      setRevealed((v) => !v);
    } catch (err) {
      fail(err, "Impossible de récupérer le code.");
    }
  };

  const copyCode = async () => {
    try {
      const code = await loadCode();
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      fail(err, "Impossible de copier le code.");
    }
  };

  const pdf = async () => {
    try {
      const code = await loadCode();
      downloadCodePdf({
        reference: demande.reference,
        clientName: fullName(client),
        clientEmail: client.email,
        formule: demande.formule,
        dateDemande: demande.date,
        dateEnvoi: demande.dateEnvoi,
        dateExpiration: abonnement?.dateFin ?? "—",
        code,
      });
      show("PDF généré et téléchargé.");
    } catch (err) {
      fail(err, "Génération du PDF impossible.");
    }
  };

  const run = async () => {
    if (busy || !confirm) return;
    setBusy(true);
    try {
      if (confirm === "generer") {
        await genererCode(demande.id);
        show("Code d'activation généré.");
      } else if (confirm === "envoyer") {
        const first = await envoyerCode(demande.id);
        show(first ? `Code envoyé à ${client.email}. L'abonnement est actif.` : `Notification renvoyée à ${client.email}.`);
      } else {
        await toggleActifCode(demande.id, !demande.codeActif);
        show(demande.codeActif ? "Code désactivé." : "Code réactivé.");
      }
      setConfirm(null);
    } catch (err) {
      fail(err, "L'action a échoué.");
    } finally {
      setBusy(false);
    }
  };

  const sendLabel = demande.codeEnvoye ? "Renvoyer au client" : "Envoyer au client";

  return (
    <div>
      <Link href="/prevadm/demandes" className="ad-back-link">
        <span className="ad-back-link-icon">
          <IconChevronRight width={13} height={13} style={{ transform: "rotate(180deg)" }} />
        </span>
        Retour aux demandes
      </Link>

      <div className={demande.codeGenere ? "ad-detail-grid ad-detail-grid--demande" : undefined}>
        <motion.div
          className={`ad-card ${demande.codeGenere ? "" : "ad-card--narrow"}`}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="ad-card-head">
            <div>
              <h2>Demande de code d&apos;activation</h2>
              <p>Référence {demande.reference}</p>
            </div>
            <StatusBadge status={demande.codeEnvoye ? "code_envoye" : demande.codeGenere ? "code_genere" : "sans_code"} />
          </div>

          <DetailTable
            rows={[
              { label: "Client", value: fullName(client) },
              { label: "Email", value: client.email },
              { label: "Date de la demande", value: demande.date },
              { label: "Abonnement demandé", value: demande.formule },
              ...(demande.dureeMois ? [{ label: "Durée", value: durationLabel(demande.dureeMois) }] : []),
            ]}
          />

          {!demande.codeGenere && (
            <div className="ad-detail-actions">
              <button type="button" className="btn btn-primary" onClick={() => setConfirm("generer")}>
                <IconKeyRound width={16} height={16} />
                Générer le code d&apos;activation
              </button>
            </div>
          )}
        </motion.div>

        {demande.codeGenere && (
          <motion.div
            className="ad-code-card"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: EASE }}
          >
            <span style={{ fontSize: "0.78rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-faint)" }}>
              Code généré
            </span>
            <div className="ad-code-value" data-no-translate>
              {plain && revealed ? plain.replace(/(\d{4})(\d{4})/, "$1 $2") : plain ? maskCode(plain) : "•• ••••"}
            </div>
            <div className="ad-code-actions">
              <button type="button" className="btn btn-secondary" onClick={toggleReveal}>
                {revealed ? <IconEyeOff width={15} height={15} /> : <IconEye width={15} height={15} />}
                {revealed ? "Masquer le code" : "Voir le code d'activation"}
              </button>
              <button type="button" className="btn btn-secondary" onClick={copyCode}>
                <IconCopy width={15} height={15} />
                {copied ? "Copié ✓" : "Copier"}
              </button>
              <button type="button" className="btn btn-secondary" onClick={pdf}>
                <IconDownload width={15} height={15} />
                Générer PDF
              </button>
              <button type="button" className="btn btn-primary" onClick={() => setConfirm("envoyer")}>
                <IconSend width={15} height={15} />
                {sendLabel}
              </button>
              {demande.codeEnvoye && (
                <button type="button" className="btn btn-secondary" onClick={() => setConfirm("desactiver")}>
                  {demande.codeActif ? "Désactiver le code" : "Réactiver le code"}
                </button>
              )}
            </div>
          </motion.div>
        )}
      </div>

      <ConfirmDialog
        open={confirm !== null}
        title={
          confirm === "generer"
            ? "Générer le code d'activation ?"
            : confirm === "envoyer"
              ? demande.codeEnvoye
                ? "Renvoyer la notification ?"
                : "Envoyer le code au client ?"
              : demande.codeActif
                ? "Désactiver ce code ?"
                : "Réactiver ce code ?"
        }
        text={
          confirm === "generer"
            ? `Un code d'activation unique sera généré pour ${fullName(client)}.`
            : confirm === "envoyer"
              ? demande.codeEnvoye
                ? `${fullName(client)} recevra de nouveau la notification par e-mail (l'abonnement n'est pas relancé).`
                : `${fullName(client)} sera notifié par e-mail et dans l'application, et son abonnement deviendra actif.`
              : demande.codeActif
                ? `Le code de ${fullName(client)} ne sera plus reconnu par le logiciel.`
                : `Le code de ${fullName(client)} sera de nouveau reconnu par le logiciel.`
        }
        danger={confirm === "desactiver" && demande.codeActif}
        disabled={busy}
        confirmLabel={
          confirm === "generer" ? "Générer" : confirm === "envoyer" ? (demande.codeEnvoye ? "Renvoyer" : "Envoyer") : demande.codeActif ? "Désactiver" : "Réactiver"
        }
        onCancel={() => setConfirm(null)}
        onConfirm={run}
      />
    </div>
  );
}
