"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { IconArrowRight } from "@/components/home/icons";
import type { ReactNode } from "react";

const EASE = [0.22, 1, 0.36, 1] as const;

function useCountUp(target: number, duration = 900) {
  const [value, setValue] = useState(0);
  const reduce = useReducedMotion();
  const raf = useRef<number>(0);

  useEffect(() => {
    if (reduce) return;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(Math.round(eased * target));
      if (t < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [target, duration, reduce]);

  return value;
}

/** Carte de chiffre clé en verre dépoli ; `accent` = dégradé bleu Previa, `dark` = dégradé nuit. */
export default function StatCard({
  icon,
  value,
  label,
  note,
  href,
  delay = 0,
  variant = "default",
}: {
  icon: ReactNode;
  value: number;
  label: string;
  note?: string;
  href: string;
  delay?: number;
  variant?: "default" | "accent" | "dark";
}) {
  const reduce = useReducedMotion();
  const count = useCountUp(value);
  const display = reduce ? value : count;

  return (
    <motion.div
      className={`ad-kpi ${variant !== "default" ? `ad-kpi--${variant}` : ""}`}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: EASE, delay }}
      whileHover={{ y: -4 }}
    >
      <div className="ad-kpi-top">
        <span className="ad-kpi-icon">{icon}</span>
        <p className="ad-kpi-label">{label}</p>
        <Link href={href} className="ad-kpi-go" aria-label={`Ouvrir : ${label}`}>
          <IconArrowRight width={15} height={15} />
        </Link>
      </div>
      <div className="ad-kpi-value">{display}</div>
      {note && <p className="ad-kpi-note">{note}</p>}
    </motion.div>
  );
}
