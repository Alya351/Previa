"use client";

import { useEffect, type ReactNode } from "react";
import { useRouter, usePathname } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import { useAdminUser, type AdminUser } from "@/lib/adminAuth";
import AdminSidebar from "./AdminSidebar";
import AdminTopbar from "./AdminTopbar";

const EASE = [0.22, 1, 0.36, 1] as const;

function AdminShellInner({
  admin,
  title,
  subtitle,
  actions,
  navInfo,
  children,
}: {
  admin: AdminUser;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  navInfo?: ReactNode;
  children: ReactNode;
}) {
  const pathname = usePathname();

  return (
    <div className="ad-shell">
      <div className="ad-window">
        <AdminSidebar />

        <div className="ad-main">
          <AdminTopbar admin={admin} />

          <div className="ad-pagehead">
            <div className="ad-pagehead-text">
              <h1>{title}</h1>
              {subtitle && <p>{subtitle}</p>}
            </div>
            {actions && <div className="ad-pagehead-actions">{actions}</div>}
          </div>

          {navInfo}

          <AnimatePresence mode="wait">
            <motion.main
              key={pathname}
              className="ad-content"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.35, ease: EASE }}
            >
              {children}
            </motion.main>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

/** Enveloppe toutes les sous-pages /prevadm/* : protège l'accès et pose la fenêtre
 *  vitrée (barre latérale + panneau principal).
 *  `actions` : boutons alignés à droite du titre de page.
 *  `navInfo` : bandeau de chiffres clés affiché sous le titre. */
export default function AdminShell({
  title,
  subtitle,
  actions,
  navInfo,
  children,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  navInfo?: ReactNode;
  children: ReactNode;
}) {
  const admin = useAdminUser();
  const router = useRouter();

  useEffect(() => {
    if (admin === null) router.replace("/prevadm");
  }, [admin, router]);

  if (!admin) return null;

  return (
    <AdminShellInner admin={admin} title={title} subtitle={subtitle} actions={actions} navInfo={navInfo}>
      {children}
    </AdminShellInner>
  );
}
