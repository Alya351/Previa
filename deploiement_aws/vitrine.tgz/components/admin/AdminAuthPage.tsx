"use client";

import AuthPage from "@/components/auth/AuthPage";
import AdminLoginForm from "./AdminLoginForm";

/** R11 : l'inscription superadmin n'est pas publique — connexion uniquement. */
const ADMIN_COPY = {
  login: {
    title: "Bon retour, Superadministrateur.",
    subtitle: "Connectez-vous pour accéder au centre de pilotage Previa.",
  },
  register: { title: "", subtitle: "" },
};

export default function AdminAuthPage() {
  return (
    <AuthPage
      copy={ADMIN_COPY}
      LoginFormComponent={AdminLoginForm}
      allowRegister={false}
      backHref="/"
      backLabel="Retour au site"
      eyebrow="Espace superadministrateur"
    />
  );
}
