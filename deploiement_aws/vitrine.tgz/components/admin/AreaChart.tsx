"use client";

import { useId, useMemo, useState } from "react";
import { motion, useReducedMotion } from "motion/react";

const EASE = [0.22, 1, 0.36, 1] as const;

const W = 640;
const H = 250;
const PAD = { top: 22, right: 18, bottom: 34, left: 40 };

function niceMax(max: number) {
  if (max <= 0) return 10;
  const magnitude = Math.pow(10, Math.floor(Math.log10(max)) - 1) || 1;
  return Math.ceil(max / magnitude) * magnitude;
}

/** Courbe lissée (Catmull-Rom → Bézier) passant par tous les points. */
function smoothPath(pts: { x: number; y: number }[]) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
  }
  return d;
}

/** Graphique en aires lissé, dégradé bleu Previa, points survolables. */
export default function AreaChart({ data, labels }: { data: number[]; labels: string[] }) {
  const reduce = useReducedMotion();
  const uid = useId().replace(/:/g, "");
  const [hover, setHover] = useState<number | null>(null);

  const max = niceMax(Math.max(...data));
  const innerW = W - PAD.left - PAD.right;
  const innerH = H - PAD.top - PAD.bottom;

  const points = useMemo(
    () =>
      data.map((v, i) => ({
        x: PAD.left + (data.length === 1 ? innerW / 2 : (i / (data.length - 1)) * innerW),
        y: PAD.top + innerH - (v / max) * innerH,
        v,
      })),
    [data, max, innerW, innerH]
  );

  const line = smoothPath(points);
  const area = `${line} L ${points[points.length - 1].x} ${PAD.top + innerH} L ${points[0].x} ${PAD.top + innerH} Z`;
  const ticks = [0, 0.25, 0.5, 0.75, 1];
  const active = hover !== null ? points[hover] : null;

  return (
    <div className="ad-area">
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Évolution du nombre de clients" onMouseLeave={() => setHover(null)}>
        <defs>
          <linearGradient id={`${uid}-fill`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#009ee3" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#009ee3" stopOpacity="0.02" />
          </linearGradient>
          <linearGradient id={`${uid}-line`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#0a6fb5" />
            <stop offset="55%" stopColor="#009ee3" />
            <stop offset="100%" stopColor="#4fd3ff" />
          </linearGradient>
        </defs>

        {ticks.map((f) => {
          const y = PAD.top + innerH - f * innerH;
          return (
            <g key={f}>
              <line x1={PAD.left} x2={W - PAD.right} y1={y} y2={y} className="ad-area-grid" />
              <text x={PAD.left - 8} y={y + 4} textAnchor="end" className="ad-area-tick">
                {Math.round(f * max)}
              </text>
            </g>
          );
        })}

        <motion.path
          d={area}
          fill={`url(#${uid}-fill)`}
          initial={{ opacity: reduce ? 1 : 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.9, ease: EASE, delay: 0.2 }}
        />
        <motion.path
          d={line}
          fill="none"
          stroke={`url(#${uid}-line)`}
          strokeWidth={3}
          strokeLinecap="round"
          initial={{ pathLength: reduce ? 1 : 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.1, ease: EASE }}
        />

        {points.map((p, i) => (
          <g key={i} onMouseEnter={() => setHover(i)}>
            <rect x={p.x - innerW / data.length / 2} y={PAD.top} width={innerW / data.length} height={innerH} fill="transparent" />
            <circle cx={p.x} cy={p.y} r={hover === i ? 6 : 3.5} className="ad-area-dot" />
            <text x={p.x} y={H - 10} textAnchor="middle" className="ad-area-label">
              {labels[i]}
            </text>
          </g>
        ))}

        {active && (
          <g pointerEvents="none">
            <line x1={active.x} x2={active.x} y1={PAD.top} y2={PAD.top + innerH} className="ad-area-cursor" />
            <g transform={`translate(${Math.min(Math.max(active.x, 34), W - 34)}, ${Math.max(active.y - 14, 12)})`}>
              <rect x={-26} y={-20} width={52} height={22} rx={11} className="ad-area-tip" />
              <text x={0} y={-5} textAnchor="middle" className="ad-area-tip-text">
                {active.v}
              </text>
            </g>
          </g>
        )}
      </svg>
    </div>
  );
}
