"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import { IconSearch, IconUsers } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { fullName } from "@/lib/adminData";
import StatusBadge from "./StatusBadge";
import EmptyState from "./EmptyState";
import { ALL, useAdminFilter } from "@/lib/adminFilter";
import PageStatsCard from "./PageStatsCard";
import Pagination from "./Pagination";
import { useFitRows } from "./useFitRows";

export function ClientsInfoCard() {
  const { clients } = useAdminData();
  const { value, setValue, toggle } = useAdminFilter("clients");
  const stats = [
    { key: ALL, label: "total", value: clients.length },
    { key: "actif", label: "actifs", value: clients.filter((c) => c.statut === "actif").length, tone: "accent" as const },
    { key: "expire", label: "expirés", value: clients.filter((c) => c.statut === "expire").length, tone: "danger" as const },
    { key: "suspendu", label: "suspendus", value: clients.filter((c) => c.statut === "suspendu").length, tone: "warn" as const },
  ];
  return (
    <PageStatsCard
      title="Clients"
      stats={stats}
      active={value}
      onSelect={(k) => (k === ALL ? setValue(ALL) : toggle(k))}
    />
  );
}

export default function ClientsPage() {
  const { clients, getAbonnement } = useAdminData();
  const [query, setQuery] = useState("");
  const { value: filter, setValue: setFilter } = useAdminFilter("clients");
  const [page, setPage] = useState(1);
  const { ref, rows: pageSize, rootStyle } = useFitRows({ list: "tbody", item: "tbody tr" });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return clients.filter(
      (c) =>
        (filter === ALL || c.statut === filter) &&
        (!q || fullName(c).toLowerCase().includes(q) || c.email.toLowerCase().includes(q))
    );
  }, [clients, query, filter]);

  useEffect(() => setPage(1), [filter]);
  useEffect(() => () => setFilter(ALL), [setFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = filtered.slice((current - 1) * pageSize, current * pageSize);

  return (
    <div ref={ref} style={rootStyle}>
      <motion.div className="ad-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <div className="ad-toolbar ad-toolbar--in-card">
          <div className="ad-search">
            <IconSearch width={16} height={16} />
            <input
              type="search"
              placeholder="Rechercher un client…"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
            />
          </div>
        </div>
        {paged.length === 0 ? (
          <EmptyState icon={<IconUsers width={22} height={22} />} text="Aucun client ne correspond à votre recherche" />
        ) : (
          <div className="ad-table-wrap">
            <table className="ad-table">
              <thead>
                <tr>
                  <th>Client</th>
                  <th>Abonnement</th>
                  <th>Période</th>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((c) => {
                  const ab = getAbonnement(c.id);
                  return (
                    <tr key={c.id} className="ad-table-row">
                      <td>
                        <Link href={`/prevadm/clients/${c.id}`} className="ad-table-link-name">
                          <span className="ad-table-name">{fullName(c)}</span>
                          <span className="ad-table-sub">{c.email}</span>
                        </Link>
                      </td>
                      <td>{ab?.formule ?? "—"}</td>
                      <td>{ab ? `${ab.dateDebut} → ${ab.dateFin}` : "—"}</td>
                      <td>
                        <StatusBadge status={c.statut} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      <Pagination page={current} totalPages={totalPages} onChange={setPage} />
    </div>
  );
}
