"use client";

import { useCallback, useLayoutEffect, useRef, useState, type CSSProperties } from "react";

/**
 * Calcule combien de lignes tiennent dans la hauteur disponible du panneau
 * (sans jamais défiler) : le reste passe sur les pages suivantes.
 * L'espace résiduel est réparti entre les lignes (variable CSS --row-extra) pour
 * que la liste descende jusqu'en bas de la page.
 *
 *  - `list`    : sélecteur du conteneur des lignes (ex. "tbody")
 *  - `item`    : sélecteur d'une ligne (ex. "tbody tr")
 *  - `reserve` : hauteur réservée à la pagination sous la carte
 */
export function useFitRows({
  list,
  item,
  fallbackRow = 56,
  reserve = 58,
  min = 3,
}: {
  list: string;
  item: string;
  fallbackRow?: number;
  reserve?: number;
  min?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [rows, setRows] = useState(6);
  const [extra, setExtra] = useState(0);
  const extraRef = useRef(0);

  const measure = useCallback(() => {
    const root = ref.current;
    const content = root?.closest<HTMLElement>(".ad-content");
    const card = root?.querySelector<HTMLElement>(".ad-card");
    const listEl = root?.querySelector<HTMLElement>(list);
    if (!root || !content || !card || !listEl) return;

    const first = root.querySelector<HTMLElement>(item);
    // hauteur « naturelle » d'une ligne : on retire l'espace déjà ajouté
    const natural = Math.max(
      (first ? first.getBoundingClientRect().height : fallbackRow) - extraRef.current,
      1
    );
    const chrome = card.getBoundingClientRect().height - listEl.getBoundingClientRect().height;
    const available = content.clientHeight - chrome - reserve;

    const nextRows = Math.max(min, Math.floor(available / natural));
    const leftover = available - nextRows * natural;
    const nextExtra = leftover > 0 ? Math.min(leftover / nextRows, natural * 0.6) : 0;
    const rounded = Math.round(nextExtra * 10) / 10;

    extraRef.current = rounded;
    setRows((prev) => (prev === nextRows ? prev : nextRows));
    setExtra((prev) => (Math.abs(prev - rounded) < 0.5 ? prev : rounded));
  }, [list, item, fallbackRow, reserve, min]);

  useLayoutEffect(() => {
    measure();
    const content = ref.current?.closest<HTMLElement>(".ad-content");
    if (!content) return;
    const ro = new ResizeObserver(measure);
    ro.observe(content);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [measure]);

  // Re-mesure après chaque changement (lignes, espace ajouté) jusqu'à stabilité.
  useLayoutEffect(() => {
    measure();
  }, [measure, rows, extra]);

  const rootStyle = { "--row-extra": `${extra}px` } as CSSProperties;

  return { ref, rows, rootStyle, measure };
}
