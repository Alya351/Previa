"use client";

import { useEffect, useState } from "react";
import { IconLock, IconMail, IconUser, IconUsers } from "@/components/home/icons";
import { readAdminToken, type AdminUser } from "@/lib/adminAuth";
import { api, ApiError, type Compte } from "@/lib/api";
import { fmtDate } from "@/lib/adminData";
import { useToast } from "./ToastContext";
import FormModal, { FormField, FormSubmit } from "./FormModal";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Member = { id?: string; prenom: string; nom: string; email: string; cree_le?: string | null };

const initialsOf = (c: Pick<Member, "prenom" | "nom">) =>
  ((c.prenom[0] ?? "") + (c.nom[0] ?? "")).toUpperCase() || "?";

/** Fenêtre « Ajouter un superadmin » : équipe actuelle + formulaire (R11 : seul un superadmin en crée un autre). */
export default function AdminsModal({
  open,
  onClose,
  admin,
}: {
  open: boolean;
  onClose: () => void;
  admin: AdminUser;
}) {
  const { show, error } = useToast();
  const [admins, setAdmins] = useState<Compte[]>([]);
  const [form, setForm] = useState({ prenom: "", nom: "", email: "", mot_de_passe: "" });
  const [creating, setCreating] = useState(false);

  const load = async () => {
    const t = readAdminToken();
    if (!t) return;
    try {
      setAdmins(await api.admin.comptes(t));
    } catch {
      /* silencieux : on affiche au moins le compte connecté */
    }
  };

  useEffect(() => {
    if (open) void load();
  }, [open]);

  const team: Member[] = admins.length ? admins : [admin];

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = readAdminToken();
    if (!t || creating) return;
    if (!form.prenom.trim() || !form.nom.trim() || !EMAIL_RE.test(form.email) || form.mot_de_passe.length < 8) {
      error("Renseignez tous les champs (mot de passe : 8 caractères minimum).");
      return;
    }
    setCreating(true);
    try {
      await api.admin.createAdmin(t, { ...form, email: form.email.trim() });
      setForm({ prenom: "", nom: "", email: "", mot_de_passe: "" });
      show("Compte superadmin créé.");
      await load();
    } catch (err) {
      error(err instanceof ApiError ? err.message : "Création impossible.");
    } finally {
      setCreating(false);
    }
  };

  return (
    <FormModal open={open} onClose={onClose} icon={<IconUsers width={44} height={44} />} title="Équipe" maxWidth={400}>
      <ul className="fm-team" aria-label="Superadministrateurs actuels">
        {team.map((a) => (
          <li key={a.id ?? a.email}>
            <span className="fm-team-avatar">{initialsOf(a)}</span>
            <span className="fm-team-text">
              <b>
                {a.prenom} {a.nom}
                {a.email === admin.email && <span className="fm-team-you">Vous</span>}
              </b>
              <small>
                {a.email}
                {a.cree_le && ` · depuis le ${fmtDate(a.cree_le)}`}
              </small>
            </span>
          </li>
        ))}
      </ul>
      <form onSubmit={submit} className="fm-form">
        <FormField icon={<IconUser width={18} height={18} />} label="Prénom" value={form.prenom} onChange={(v) => setForm((s) => ({ ...s, prenom: v }))} />
        <FormField icon={<IconUser width={18} height={18} />} label="Nom" value={form.nom} onChange={(v) => setForm((s) => ({ ...s, nom: v }))} />
        <FormField icon={<IconMail width={18} height={18} />} label="E-mail" type="email" value={form.email} onChange={(v) => setForm((s) => ({ ...s, email: v }))} autoComplete="off" />
        <FormField icon={<IconLock width={18} height={18} />} label="Mot de passe" type="password" value={form.mot_de_passe} onChange={(v) => setForm((s) => ({ ...s, mot_de_passe: v }))} autoComplete="new-password" />
        <FormSubmit disabled={creating}>{creating ? "Création…" : "Ajouter"}</FormSubmit>
      </form>
    </FormModal>
  );
}
