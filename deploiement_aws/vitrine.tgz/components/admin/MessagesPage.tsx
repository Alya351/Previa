"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import { IconChevronDown, IconClose, IconMail, IconSearch, IconSend } from "@/components/home/icons";
import { useAdminData } from "./AdminDataContext";
import { toMessageReply, type Message, type MessageReply } from "@/lib/adminData";
import { readAdminToken } from "@/lib/adminAuth";
import { api, ApiError } from "@/lib/api";
import { useToast } from "./ToastContext";
import StatusBadge from "./StatusBadge";
import EmptyState from "./EmptyState";
import { ALL, useAdminFilter } from "@/lib/adminFilter";
import Pagination from "./Pagination";
import { useFitRows } from "./useFitRows";

const SEGMENTS = [
  { id: ALL, label: "Tous" },
  { id: "non_traite", label: "Non traités" },
  { id: "traite", label: "Traités" },
] as const;

const EASE = [0.22, 1, 0.36, 1] as const;

export default function MessagesPage() {
  const { messages } = useAdminData();
  const { value: filter, setValue: setFilter } = useAdminFilter("messages");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [openId, setOpenId] = useState<string | null>(null);
  const { ref, rows: pageSize, rootStyle } = useFitRows({ list: ".ad-notiflist", item: ".ad-notifrow", fallbackRow: 84 });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return messages.filter((m) => {
      const matchFilter = filter === ALL || (filter === "non_traite" ? !m.traite : m.traite);
      const matchQuery = !q || m.nom.toLowerCase().includes(q) || m.email.toLowerCase().includes(q);
      return matchFilter && matchQuery;
    });
  }, [messages, query, filter]);

  useEffect(() => setPage(1), [filter, query]);
  useEffect(() => () => setFilter(ALL), [setFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = filtered.slice((current - 1) * pageSize, current * pageSize);
  const openMessage = messages.find((m) => m.id === openId) ?? null;

  return (
    <div ref={ref} style={rootStyle}>
      <motion.div className="ad-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <div className="ad-toolbar ad-toolbar--in-card">
          <div className="ad-search">
            <IconSearch width={16} height={16} />
            <input
              type="search"
              placeholder="Rechercher un nom ou un e-mail…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="ad-segmented" role="tablist" aria-label="Filtrer les messages">
          {SEGMENTS.map((s) => (
            <button
              key={s.id}
              type="button"
              role="tab"
              aria-selected={filter === s.id}
              className={`ad-segmented-btn ${filter === s.id ? "is-active" : ""}`}
              onClick={() => setFilter(s.id)}
            >
              {s.label}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <EmptyState icon={<IconMail width={22} height={22} />} text="Aucun message dans cette catégorie" />
        ) : (
          <div className="ad-notiflist">
            {paged.map((m, i) => (
              <MessageListRow key={m.id} message={m} index={i} onOpen={() => setOpenId(m.id)} />
            ))}
          </div>
        )}
      </motion.div>

      <Pagination page={current} totalPages={totalPages} onChange={setPage} />

      <MessageDetailModal message={openMessage} onClose={() => setOpenId(null)} />
    </div>
  );
}

/** Ligne de la liste : ouvre la modale au clic ; le menu (type, statut, actions), sur la ligne du texte, n'ouvre pas la modale. */
function MessageListRow({ message: m, index, onOpen }: { message: Message; index: number; onOpen: () => void }) {
  const { setMessageTraite } = useAdminData();
  const { show, error } = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, [menuOpen]);

  const toggleTraite = async () => {
    setBusy(true);
    try {
      await setMessageTraite(m.id, !m.traite);
      show(m.traite ? "Message rouvert." : "Message marqué comme traité.");
    } catch (err) {
      error(err instanceof ApiError ? err.message : "L'action a échoué.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.div
      role="button"
      tabIndex={0}
      className="ad-notifrow ad-notifrow--pressable"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.03 }}
      onClick={onOpen}
      onKeyDown={(e) => e.key === "Enter" && onOpen()}
    >
      <span className="ad-notifrow-icon">
        <IconMail width={19} height={19} />
      </span>
      <div className="ad-notifrow-body">
        <div className="ad-notifrow-head">
          <p className="ad-notifrow-title">
            {!m.traite && <span className="ad-notifrow-bullet" aria-hidden />}
            {m.nom}
            <StatusBadge status={m.type} />
          </p>
          <span className="ad-notifrow-date">{m.date}</span>
        </div>
        <div className="ad-notifrow-textrow">
          <p className="ad-notifrow-text">{m.texte}</p>
          <div
            className="ad-row-menu"
            ref={menuRef}
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              className={`ad-row-menu-trigger ${menuOpen ? "is-active" : ""}`}
              aria-label="Plus d'actions"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((v) => !v)}
            >
              <IconChevronDown width={14} height={14} />
            </button>
            <AnimatePresence>
              {menuOpen && (
                <motion.div
                  className="ad-row-menu-panel"
                  initial={{ opacity: 0, y: -6, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -6, scale: 0.97 }}
                  transition={{ duration: 0.18, ease: EASE }}
                >
                  <StatusBadge status={m.type} />
                  <StatusBadge status={m.traite ? "traite" : "non_traite"} />
                  <button
                    type="button"
                    className="ad-table-link"
                    disabled={busy}
                    onClick={() => {
                      setMenuOpen(false);
                      toggleTraite();
                    }}
                  >
                    {m.traite ? "Rouvrir" : "Marquer comme traité"}
                  </button>
                  {m.type === "devis" && m.clientId && (
                    <Link href={`/prevadm/clients/${m.clientId}`} className="ad-table-link">
                      Voir la fiche client
                    </Link>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

const RING_LAYERS = [
  { len: 0.34, op: 0.16, color: "#3fb4f5" },
  { len: 0.26, op: 0.2, color: "#4fc3ff" },
  { len: 0.19, op: 0.26, color: "#5fcbff" },
  { len: 0.13, op: 0.34, color: "#7fd8ff" },
  { len: 0.08, op: 0.55, color: "#a8e6ff" },
  { len: 0.04, op: 0.95, color: "#ffffff" },
];

function roundedRectPath(w: number, h: number, r: number): string {
  return [
    `M ${r} 1`,
    `H ${w - r}`,
    `A ${r - 1} ${r - 1} 0 0 1 ${w - 1} ${r}`,
    `V ${h - r}`,
    `A ${r - 1} ${r - 1} 0 0 1 ${w - r} ${h - 1}`,
    `H ${r}`,
    `A ${r - 1} ${r - 1} 0 0 1 1 ${h - r}`,
    `V ${r}`,
    `A ${r - 1} ${r - 1} 0 0 1 ${r} 1`,
    "Z",
  ].join(" ");
}

/** Faisceau lumineux qui parcourt le contour de la carte (même animation que les fenêtres d'authentification). */
function CardRing() {
  const ref = useRef<SVGSVGElement>(null);
  const [geo, setGeo] = useState({ w: 0, h: 0, d: "" });

  useLayoutEffect(() => {
    const card = ref.current?.parentElement;
    if (!card) return;
    const update = () => {
      const w = card.offsetWidth;
      const h = card.offsetHeight;
      const radius = parseFloat(getComputedStyle(card).borderRadius) || 24;
      setGeo({ w, h, d: roundedRectPath(w, h, Math.max(radius, 8)) });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(card);
    return () => ro.disconnect();
  }, []);

  return (
    <svg ref={ref} className="fm-ring" width={geo.w} height={geo.h} aria-hidden>
      {geo.d &&
        RING_LAYERS.map((l) => (
          <path
            key={l.len}
            d={geo.d}
            pathLength={1}
            style={{ "--L": l.len, stroke: l.color, strokeOpacity: l.op } as CSSProperties}
          />
        ))}
    </svg>
  );
}

function defaultObjet(m: Message): string {
  return m.type === "devis" ? "Votre demande de devis Previa" : "Votre message à Previa";
}

function MessageDetailModal({ message, onClose }: { message: Message | null; onClose: () => void }) {
  const { replyMessage } = useAdminData();
  const { show, error } = useToast();
  const [objet, setObjet] = useState("");
  const [reply, setReply] = useState("");
  const [replies, setReplies] = useState<MessageReply[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setReply("");
    setReplies([]);
    setObjet(message ? defaultObjet(message) : "");
    if (!message) return;
    const t = readAdminToken();
    if (!t) return;
    let live = true;
    api.admin
      .messageReplies(t, message.id)
      .then((rows) => live && setReplies(rows.map(toMessageReply)))
      .catch(() => {});
    return () => {
      live = false;
    };
  }, [message]);

  const fail = (err: unknown, fallback: string) => error(err instanceof ApiError ? err.message : fallback);

  const sendReply = async () => {
    if (!message || !reply.trim()) return;
    setBusy(true);
    try {
      const sentTexte = reply.trim();
      const sentObjet = objet.trim();
      await replyMessage(message.id, sentTexte, sentObjet);
      setReplies((prev) => [
        ...prev,
        { id: `local-${prev.length}`, auteur: "Vous", objet: sentObjet, texte: sentTexte, date: "à l'instant" },
      ]);
      setReply("");
      show(`Réponse envoyée à ${message.email}.`);
    } catch (err) {
      fail(err, "L'envoi de la réponse a échoué.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AnimatePresence>
      {message && (
        <motion.div
          className="ad-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
        >
          <motion.div
            className="ad-dialog ad-dialog--wide"
            role="dialog"
            aria-modal="true"
            aria-label={`Message de ${message.nom}`}
            initial={{ opacity: 0, scale: 0.94, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.28, ease: EASE }}
            onClick={(e) => e.stopPropagation()}
          >
            <CardRing />
            <button type="button" className="ad-dialog-close" aria-label="Fermer" onClick={onClose}>
              <IconClose width={14} height={14} />
            </button>

            <div className="ad-compose-fields">
              <div className="ad-compose-row">
                <span className="ad-compose-chip">De</span>
                <span className="ad-compose-row-value">Équipe Previa</span>
              </div>
              <div className="ad-compose-row">
                <span className="ad-compose-chip">À</span>
                <span className="ad-compose-row-value">
                  {message.nom} &lt;{message.email}&gt;
                </span>
              </div>
              <div className="ad-compose-row">
                <span className="ad-compose-chip">Objet</span>
                <input value={objet} maxLength={200} onChange={(e) => setObjet(e.target.value)} />
              </div>
            </div>

            <div className="ad-thread">
              <div className="ad-thread-msg ad-thread-msg--in">{message.texte}</div>

              {replies.map((r) => (
                <div key={r.id} className="ad-thread-msg ad-thread-msg--out">
                  {r.texte}
                </div>
              ))}

              <div className="ad-thread-compose">
                <textarea
                  placeholder={`Votre réponse à ${message.nom}…`}
                  value={reply}
                  maxLength={4000}
                  autoFocus
                  onChange={(e) => setReply(e.target.value)}
                />
              </div>
            </div>

            <div className="ad-compose-send-row">
              <button
                type="button"
                className="btn btn-primary"
                disabled={busy || !reply.trim()}
                onClick={sendReply}
              >
                <IconSend width={15} height={15} />
                Envoyer
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
