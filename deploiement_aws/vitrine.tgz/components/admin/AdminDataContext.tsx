"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useAdminUser, readAdminToken } from "@/lib/adminAuth";
import { api, ApiError, type DashboardApi } from "@/lib/api";
import {
  toAbonnement,
  toClient,
  toDemande,
  toHistorique,
  toMessage,
  toNotif,
  type Abonnement,
  type Client,
  type Demande,
  type HistoriqueEntry,
  type Message,
  type NotifAdmin,
} from "@/lib/adminData";

type AdminDataValue = {
  clients: Client[];
  abonnements: Abonnement[];
  demandes: Demande[];
  notifications: NotifAdmin[];
  historique: HistoriqueEntry[];
  messages: Message[];
  dashboard: DashboardApi | null;
  unreadCount: number;
  unreadMessagesCount: number;
  loading: boolean;
  getClient: (id: string) => Client | undefined;
  getAbonnement: (clientId: string) => Abonnement | undefined;
  getAbonnementById: (id: string) => Abonnement | undefined;
  refreshData: () => Promise<void>;

  deleteClient: (id: string) => Promise<void>;
  updateClient: (
    id: string,
    data: Partial<Pick<Client, "nom" | "prenom" | "email" | "telephone">>
  ) => Promise<void>;

  /** R22 : génération manuelle du code. */
  genererCode: (demandeId: string) => Promise<void>;
  /** R4/R52 : premier envoi = abonnement actif ; e-mail réel. Renvoie true au premier envoi. */
  envoyerCode: (demandeId: string) => Promise<boolean>;
  /** R53 : le code en clair (l'interface le masque par défaut). */
  voirCode: (demandeId: string) => Promise<string>;
  toggleActifCode: (demandeId: string, active: boolean) => Promise<void>;

  prolongerAbonnement: (id: string, mois: number) => Promise<void>;
  suspendreAbonnement: (id: string) => Promise<void>;
  reactiverAbonnement: (id: string) => Promise<void>;
  terminerAbonnement: (id: string) => Promise<void>;

  markAllNotificationsRead: () => Promise<void>;
  setMessageTraite: (id: string, traite: boolean) => Promise<void>;
  replyMessage: (id: string, texte: string, objet?: string) => Promise<void>;
};

const AdminDataContext = createContext<AdminDataValue | null>(null);

export function AdminDataProvider({ children }: { children: ReactNode }) {
  const admin = useAdminUser();
  const [clients, setClients] = useState<Client[]>([]);
  const [abonnements, setAbonnements] = useState<Abonnement[]>([]);
  const [demandes, setDemandes] = useState<Demande[]>([]);
  const [notifications, setNotifications] = useState<NotifAdmin[]>([]);
  const [historique, setHistorique] = useState<HistoriqueEntry[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [dashboard, setDashboard] = useState<DashboardApi | null>(null);
  const [loading, setLoading] = useState(true);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const token = () => admin?.token || readAdminToken();

  const refreshData = useCallback(async () => {
    const t = readAdminToken();
    if (!t) return;
    const [cl, dem, abo, notif, hist, msg, dash] = await Promise.allSettled([
      api.admin.clients(t),
      api.admin.demandes(t),
      api.admin.abonnements(t),
      api.admin.notifications(t),
      api.admin.historique(t),
      api.admin.messages(t),
      api.admin.dashboard(t),
    ]);
    if (!mounted.current) return;
    if (cl.status === "fulfilled") setClients(cl.value.items.map(toClient));
    if (dem.status === "fulfilled") setDemandes(dem.value.items.map(toDemande));
    if (abo.status === "fulfilled") setAbonnements(abo.value.items.map(toAbonnement));
    if (notif.status === "fulfilled") setNotifications(notif.value.notifications.map(toNotif));
    if (hist.status === "fulfilled") setHistorique(hist.value.items.map(toHistorique));
    if (msg.status === "fulfilled") setMessages(msg.value.map(toMessage));
    if (dash.status === "fulfilled") setDashboard(dash.value);
    setLoading(false);
  }, []);

  // Chargement initial, puis rafraîchissement régulier (nouvelles demandes, notifications…).
  useEffect(() => {
    if (!admin) return;
    void refreshData();
    const id = window.setInterval(() => void refreshData(), 30000);
    return () => window.clearInterval(id);
  }, [admin, refreshData]);

  /** Exécute une action puis recharge les données ; laisse remonter l'erreur de l'API à l'appelant. */
  const act = useCallback(
    async <T,>(fn: (t: string) => Promise<T>): Promise<T> => {
      const t = token();
      if (!t) throw new ApiError("Session superadmin requise.", 401);
      const res = await fn(t);
      await refreshData();
      return res;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [refreshData, admin?.token]
  );

  const value = useMemo<AdminDataValue>(
    () => ({
      clients,
      abonnements,
      demandes,
      notifications,
      historique,
      messages,
      dashboard,
      unreadCount: notifications.filter((n) => !n.read).length,
      unreadMessagesCount: messages.filter((m) => !m.traite).length,
      loading,
      getClient: (id) => clients.find((c) => c.id === id),
      getAbonnement: (clientId) => {
        const list = abonnements.filter((a) => a.clientId === clientId);
        return list.find((a) => a.statut !== "termine") ?? list[0];
      },
      getAbonnementById: (id) => abonnements.find((a) => a.id === id),
      refreshData,

      deleteClient: (id) => act((t) => api.admin.deleteClient(t, id)).then(() => undefined),
      updateClient: (id, data) =>
        act((t) =>
          api.admin.updateClient(t, id, {
            prenom: data.prenom,
            nom: data.nom,
            email: data.email,
            telephone: data.telephone,
          })
        ).then(() => undefined),

      genererCode: (id) => act((t) => api.admin.generateCode(t, id)).then(() => undefined),
      envoyerCode: (id) => act((t) => api.admin.sendCode(t, id)).then((d) => !!d.premier_envoi),
      voirCode: async (id) => {
        const t = token();
        if (!t) throw new ApiError("Session superadmin requise.", 401);
        return (await api.admin.revealCode(t, id)).code;
      },
      toggleActifCode: (id, active) => act((t) => api.admin.toggleCode(t, id, active)).then(() => undefined),

      prolongerAbonnement: (id, mois) => act((t) => api.admin.prolonger(t, id, mois)).then(() => undefined),
      suspendreAbonnement: (id) => act((t) => api.admin.suspendre(t, id)).then(() => undefined),
      reactiverAbonnement: (id) => act((t) => api.admin.reactiver(t, id)).then(() => undefined),
      terminerAbonnement: (id) => act((t) => api.admin.terminer(t, id)).then(() => undefined),

      markAllNotificationsRead: async () => {
        setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
        const t = token();
        if (t) await api.admin.readAllNotifications(t).catch(() => {});
      },
      setMessageTraite: (id, traite) => act((t) => api.admin.setMessageTraite(t, id, traite)).then(() => undefined),
      replyMessage: (id, texte, objet) => act((t) => api.admin.replyMessage(t, id, texte, objet)).then(() => undefined),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [clients, abonnements, demandes, notifications, historique, messages, dashboard, loading, refreshData, act]
  );

  return <AdminDataContext.Provider value={value}>{children}</AdminDataContext.Provider>;
}

export function useAdminData() {
  const ctx = useContext(AdminDataContext);
  if (!ctx) throw new Error("useAdminData must be used within AdminDataProvider");
  return ctx;
}
