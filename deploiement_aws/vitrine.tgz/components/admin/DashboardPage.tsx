"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import { IconUsers, IconSend, IconLayers, IconAlertTriangle, IconClock } from "@/components/home/icons";
import { fmtDate } from "@/lib/adminData";
import { readAdminToken } from "@/lib/adminAuth";
import { api } from "@/lib/api";
import { useAdminData } from "./AdminDataContext";
import StatCard from "./StatCard";
import AreaChart from "./AreaChart";
import StatusBadge from "./StatusBadge";

const RANGES = ["7j", "30j", "3m", "12m"] as const;
type Range = (typeof RANGES)[number];

/** Étiquette d'axe : jour de la semaine (7 j), jour/mois (30 j, 3 m) ou mois (12 m). */
function labelFor(iso: string, range: Range) {
  const d = new Date(iso);
  if (range === "7j") return new Intl.DateTimeFormat("fr-FR", { weekday: "short" }).format(d).replace(".", "");
  if (range === "12m") return new Intl.DateTimeFormat("fr-FR", { month: "short" }).format(d).replace(".", "");
  return new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "2-digit" }).format(d);
}

const pad = (n: number) => String(n).padStart(2, "0");

/** Horloge numérique lumineuse (mise à jour chaque seconde, côté client uniquement). */
function LiveClock() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const date = now
    ? new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long" }).format(now)
    : "";

  return (
    <div className="ad-clock">
      <div className="ad-clock-digits" aria-label="Heure actuelle">
        <span>{now ? pad(now.getHours()) : "--"}</span>
        <i>:</i>
        <span>{now ? pad(now.getMinutes()) : "--"}</span>
        <i>:</i>
        <span>{now ? pad(now.getSeconds()) : "--"}</span>
      </div>
      <p className="ad-clock-date">{date}</p>
    </div>
  );
}

function Meter({
  label,
  value,
  detail,
  tone,
}: {
  label: string;
  value: number;
  detail: string;
  tone: "blue" | "cyan" | "navy";
}) {
  return (
    <div className="ad-meter">
      <div className="ad-meter-head">
        <span className="ad-meter-label">{label}</span>
        <span className="ad-meter-pill">{value} %</span>
      </div>
      <div className="ad-meter-track">
        <motion.span
          className={`ad-meter-fill ad-meter-fill--${tone}`}
          initial={{ width: 0 }}
          animate={{ width: `${Math.max(value, 3)}%` }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
        />
      </div>
      <span className="ad-meter-detail">{detail}</span>
    </div>
  );
}

export default function DashboardPage() {
  const { dashboard } = useAdminData();
  const [range, setRange] = useState<Range>("30j");
  const [series, setSeries] = useState<{ values: number[]; labels: string[] }>({ values: [0, 0], labels: ["", ""] });

  // Évolution réelle du nombre de clients inscrits (courbe cumulée).
  useEffect(() => {
    const t = readAdminToken();
    if (!t) return;
    let cancelled = false;
    api.admin
      .growth(t, range, 7)
      .then((res) => {
        if (cancelled) return;
        setSeries({
          values: res.points.map((p) => p.clients),
          labels: res.points.map((p) => labelFor(p.date, range)),
        });
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [range, dashboard?.total_clients]);

  const d = dashboard;
  const totalClients = d?.total_clients ?? 0;
  const clientsActifs = d?.clients_actifs ?? 0;
  const sansCode = d?.demandes_sans_code ?? 0;
  const abonnementsActifs = d?.abonnements_actifs ?? 0;
  const expirent = d?.expirent_bientot ?? 0;
  const codesEnvoyes = d?.codes_envoyes ?? 0;
  const ind = d?.indicateurs ?? { clients_actifs_pct: 0, codes_envoyes_pct: 0, abonnements_actifs_pct: 0 };
  const dernieres = d?.activite_recente.slice(0, 3) ?? [];

  return (
    <div className="ad-dash">
      <div className="ad-kpis">
        <StatCard
          variant="accent"
          icon={<IconUsers width={18} height={18} />}
          value={totalClients}
          label="Total clients"
          note={`${clientsActifs} actif${clientsActifs > 1 ? "s" : ""}`}
          href="/prevadm/clients"
        />
        <StatCard
          icon={<IconSend width={18} height={18} />}
          value={sansCode}
          label="Demandes sans code"
          note={`${codesEnvoyes} code${codesEnvoyes > 1 ? "s" : ""} envoyé${codesEnvoyes > 1 ? "s" : ""}`}
          href="/prevadm/demandes"
          delay={0.06}
        />
        <StatCard
          icon={<IconLayers width={18} height={18} />}
          value={abonnementsActifs}
          label="Abonnements actifs"
          note={`${ind.abonnements_actifs_pct} % du total`}
          href="/prevadm/abonnements"
          delay={0.12}
        />
        <StatCard
          variant="dark"
          icon={<IconAlertTriangle width={18} height={18} />}
          value={expirent}
          label="Expirent bientôt"
          note="À renouveler"
          href="/prevadm/abonnements"
          delay={0.18}
        />
      </div>

      <div className="ad-dash-grid">
        <div className="ad-card">
          <div className="ad-card-head">
            <div>
              <h2>Évolution des clients</h2>
              <p>Nombre de clients inscrits dans le temps</p>
            </div>
            <div className="ad-filter-group">
              {RANGES.map((r) => (
                <button
                  key={r}
                  type="button"
                  className={`ad-filter-btn ${range === r ? "is-active" : ""}`}
                  onClick={() => setRange(r)}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <AreaChart data={series.values} labels={series.labels} />
        </div>

        <div className="ad-card ad-live">
          <div className="ad-card-head">
            <div>
              <h2>Activité en direct</h2>
              <p>Dernières demandes de codes</p>
            </div>
            <Link href="/prevadm/demandes" className="ad-link-more">
              Tout voir
            </Link>
          </div>
          <LiveClock />
          <ul className="ad-live-list">
            {dernieres.length === 0 && <li className="ad-live-empty">Aucune demande pour le moment.</li>}
            {dernieres.map((x) => (
              <li key={x.id}>
                <Link href={`/prevadm/demandes/${x.id}`} className="ad-live-item">
                  <span className="ad-live-icon">
                    <IconClock width={14} height={14} />
                  </span>
                  <span className="ad-live-name">
                    {x.client}
                    <small>{fmtDate(x.date)}</small>
                  </span>
                  <StatusBadge status={x.code_envoye ? "code_envoye" : x.code_genere ? "code_genere" : "sans_code"} />
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="ad-card ad-meters">
        <div className="ad-card-head">
          <div>
            <h2>Indicateurs de la plateforme</h2>
            <p>Part de clients actifs, de codes envoyés et d&apos;abonnements en cours</p>
          </div>
        </div>
        <div className="ad-meters-grid">
          <Meter
            label="Clients actifs"
            value={ind.clients_actifs_pct}
            detail={`${clientsActifs} sur ${totalClients}`}
            tone="blue"
          />
          <Meter
            label="Codes envoyés"
            value={ind.codes_envoyes_pct}
            detail={`${codesEnvoyes} code${codesEnvoyes > 1 ? "s" : ""}`}
            tone="cyan"
          />
          <Meter
            label="Abonnements actifs"
            value={ind.abonnements_actifs_pct}
            detail={`${abonnementsActifs} en cours`}
            tone="navy"
          />
        </div>
      </div>
    </div>
  );
}
