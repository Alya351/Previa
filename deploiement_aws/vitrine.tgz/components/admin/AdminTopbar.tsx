"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import { useTheme } from "next-themes";
import { useMounted } from "@/components/home/useMounted";
import {
  IconSearch,
  IconMail,
  IconChevronDown,
  IconUser,
  IconSettings,
  IconLogOut,
  IconHome,
  IconSun,
  IconMoon,
} from "@/components/home/icons";
import { clearAdminUser, initialsOfAdmin, type AdminUser } from "@/lib/adminAuth";
import { useAdminData } from "./AdminDataContext";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Sélecteur de thème : deux boutons, Clair / Sombre. */
function ThemeSwitch() {
  const { resolvedTheme, setTheme } = useTheme();
  const mounted = useMounted();
  const isDark = mounted && resolvedTheme === "dark";

  return (
    <div className="ad-theme" role="group" aria-label="Thème de l'interface">
      <button
        type="button"
        className={`ad-theme-btn ${!isDark ? "is-active" : ""}`}
        aria-pressed={!isDark}
        title="Thème clair"
        onClick={() => setTheme("light")}
      >
        <IconSun width={16} height={16} />
        <span>Clair</span>
      </button>
      <button
        type="button"
        className={`ad-theme-btn ${isDark ? "is-active" : ""}`}
        aria-pressed={isDark}
        title="Thème sombre"
        onClick={() => setTheme("dark")}
      >
        <IconMoon width={16} height={16} />
        <span>Sombre</span>
      </button>
    </div>
  );
}

export default function AdminTopbar({ admin }: { admin: AdminUser }) {
  const router = useRouter();
  const { notifications, unreadCount, markAllNotificationsRead } = useAdminData();
  const [notifOpen, setNotifOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false);
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, []);

  const handleLogout = () => {
    clearAdminUser();
    router.push("/prevadm");
  };

  return (
    <motion.header
      className="ad-topbar"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: EASE }}
    >
      <div className="ad-search">
        <IconSearch width={16} height={16} />
        <input type="search" placeholder="Rechercher…" aria-label="Rechercher" />
        <kbd className="ad-search-kbd">⌘ K</kbd>
      </div>

      <div className="ad-topbar-actions">
        <ThemeSwitch />

        <div className="es-notif" ref={notifRef}>
          <button
            type="button"
            className="icon-btn es-notif-btn"
            aria-label="Messages et notifications"
            onClick={() => {
              setNotifOpen((v) => !v);
              setUserOpen(false);
              if (!notifOpen) markAllNotificationsRead();
            }}
          >
            <IconMail width={18} height={18} />
            {unreadCount > 0 && <span className="es-notif-dot">{unreadCount}</span>}
          </button>
          <AnimatePresence>
            {notifOpen && (
              <motion.div
                className="es-panel es-notif-panel"
                initial={{ opacity: 0, y: -8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.97 }}
                transition={{ duration: 0.2, ease: EASE }}
              >
                <span className="es-panel-title">Notifications</span>
                <div className="es-notif-list">
                  {notifications.length === 0 && <p className="es-notif-empty">Aucune notification.</p>}
                  {notifications.slice(0, 6).map((n) => (
                    <div key={n.id} className={`es-notif-item es-notif-item--${n.kind === "abonnement" ? "danger" : "success"}`}>
                      <span className={`es-notif-icon es-notif-icon--${n.kind === "abonnement" ? "danger" : "success"}`} aria-hidden />
                      <div>
                        <p className="es-notif-item-title">{n.title}</p>
                        <p className="es-notif-item-text">{n.text}</p>
                        <span className="es-notif-item-date">{n.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="es-user" ref={userRef}>
          <button type="button" className="ad-userbtn" onClick={() => { setUserOpen((v) => !v); setNotifOpen(false); }}>
            <span className="es-avatar">{initialsOfAdmin(admin)}</span>
            <IconChevronDown width={14} height={14} />
          </button>
          <AnimatePresence>
            {userOpen && (
              <motion.div
                className="es-panel es-user-panel"
                initial={{ opacity: 0, y: -8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.97 }}
                transition={{ duration: 0.2, ease: EASE }}
              >
                <div className="es-user-panel-head">
                  <span className="es-avatar es-avatar--lg">{initialsOfAdmin(admin)}</span>
                  <div>
                    <p className="es-user-panel-name">{admin.prenom} {admin.nom}</p>
                    <p className="es-user-panel-email">{admin.email}</p>
                  </div>
                </div>
                <Link
                  href="/prevadm/compte"
                  className="es-user-panel-logout"
                  style={{ color: "var(--text)" }}
                  onClick={() => setUserOpen(false)}
                >
                  <IconUser width={16} height={16} />
                  Mon compte
                </Link>
                <Link href="/prevadm/parametres" className="es-user-panel-logout" style={{ color: "var(--text)" }} onClick={() => setUserOpen(false)}>
                  <IconSettings width={16} height={16} />
                  Paramètres
                </Link>
                <Link href="/" className="es-user-panel-logout" style={{ color: "var(--text)" }} onClick={() => setUserOpen(false)}>
                  <IconHome width={16} height={16} />
                  Site Previa
                </Link>
                <button type="button" className="es-user-panel-logout" onClick={handleLogout}>
                  <IconLogOut width={16} height={16} />
                  Déconnexion
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.header>
  );
}
