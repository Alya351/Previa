"use client";

import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { IconLayers as IconHistory } from "@/components/home/icons";
import { ALL, useAdminFilter } from "@/lib/adminFilter";
import { useAdminData } from "./AdminDataContext";
import EmptyState from "./EmptyState";
import PageStatsCard from "./PageStatsCard";
import Pagination from "./Pagination";
import { useFitRows } from "./useFitRows";

const CATEGORIES = {
  demandes: "Historique des demandes",
  codes: "Historique des codes d'activation générés",
  abonnements: "Historique des abonnements",
} as const;

export function HistoriqueInfoCard() {
  const { historique } = useAdminData();
  const { value, setValue, toggle } = useAdminFilter("historique");
  const stats = [
    { key: ALL, label: "total", value: historique.length },
    { key: "demandes", label: "demandes", value: historique.filter((h) => h.categorie === "demandes").length },
    { key: "codes", label: "codes", value: historique.filter((h) => h.categorie === "codes").length, tone: "accent" as const },
    { key: "abonnements", label: "abonnements", value: historique.filter((h) => h.categorie === "abonnements").length },
  ];
  return (
    <PageStatsCard
      title="Historique"
      stats={stats}
      active={value}
      onSelect={(k) => (k === ALL ? setValue(ALL) : toggle(k))}
    />
  );
}

export default function HistoriquePage() {
  const { historique } = useAdminData();
  const { value: filter, setValue: setFilter } = useAdminFilter("historique");
  const [page, setPage] = useState(1);
  const { ref, rows: pageSize, rootStyle } = useFitRows({ list: "tbody", item: "tbody tr" });

  useEffect(() => setPage(1), [filter]);
  useEffect(() => () => setFilter(ALL), [setFilter]);

  const visibles = filter === ALL ? historique : historique.filter((h) => h.categorie === filter);

  const totalPages = Math.max(1, Math.ceil(visibles.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = visibles.slice((current - 1) * pageSize, current * pageSize);

  return (
    <div ref={ref} style={rootStyle}>
      <motion.div className="ad-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        {filter in CATEGORIES && (
          <div className="ad-card-head">
            <h2>{CATEGORIES[filter as keyof typeof CATEGORIES]}</h2>
          </div>
        )}
        {visibles.length === 0 ? (
          <EmptyState icon={<IconHistory width={22} height={22} />} text="Aucune entrée dans l'historique" />
        ) : (
          <div className="ad-table-wrap">
            <table className="ad-table">
              <thead>
                <tr>
                  <th>Action</th>
                  <th>Concerné</th>
                  <th>Auteur</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((h) => (
                  <tr key={h.id} className="ad-table-row">
                    <td className="ad-table-name">{h.action}</td>
                    <td>{h.cible}</td>
                    <td>{h.auteur}</td>
                    <td>{h.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      <Pagination page={current} totalPages={totalPages} onChange={setPage} />
    </div>
  );
}
