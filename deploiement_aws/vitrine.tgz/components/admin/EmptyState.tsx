import type { ReactNode } from "react";

export default function EmptyState({ icon, text }: { icon: ReactNode; text: string }) {
  return (
    <div className="ad-empty">
      <span className="ad-empty-icon">{icon}</span>
      <p>{text}</p>
    </div>
  );
}
