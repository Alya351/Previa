"use client";

import Navbar from "@/components/home/Navbar";
import Footer from "@/components/home/Footer";
import Vision from "./Vision";
import Equipe from "./Equipe";
import Partenaires from "./Partenaires";
import Engagement from "./Engagement";
import Intro from "@/components/contact/Intro";
import Faq from "@/components/contact/Faq";

export default function AProposPage() {
  return (
    <>
      <Navbar />
      <main>
        <Vision />
        <Equipe />
        <Partenaires />
        <Engagement />
        <Intro />
        <Faq />
      </main>
      <Footer />
    </>
  );
}
