"use client";

import Link from "next/link";
import { motion, useReducedMotion, type Variants } from "motion/react";
import { IconEye, IconTarget, IconBell, IconLock, IconChevronRight } from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

const VALUES = [
  { title: "Anticiper", text: "Repérer les signes avant l'intrusion, pas après.", icon: IconEye },
  { title: "Discerner", text: "Distinguer un vrai danger d'un simple passage.", icon: IconTarget },
  { title: "Alerter", text: "Prévenir la bonne personne, à la seconde utile.", icon: IconBell },
  { title: "Respecter", text: "Vos images et vos données restent les vôtres.", icon: IconLock },
] as const;

const stage: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1 } },
};
const cardV: Variants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: EASE } },
};

export default function Engagement() {
  const reduce = useReducedMotion();

  return (
    <section className="section ap-engagement">
      <div className="container">
        <motion.div
          className="ap-engage-panel"
          initial={{ opacity: 0, y: reduce ? 0 : 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.9, ease: EASE }}
        >
          <span className="ap-visual-blob ap-visual-blob--a" aria-hidden />
          <span className="ap-visual-blob ap-visual-blob--b" aria-hidden />

          <div className="ap-engage-head">
            <motion.span
              className="eyebrow"
              style={{ justifyContent: "center" }}
              initial={{ opacity: 0, y: reduce ? 0 : 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.6, delay: reduce ? 0 : 0.1 }}
            >
              Notre engagement
            </motion.span>

            <motion.h2
              className="ap-title ap-engage-title"
              initial={{ opacity: 0, y: reduce ? 0 : 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.7, delay: reduce ? 0 : 0.2, ease: EASE }}
            >
              Un coup d&apos;avance sur l&apos;intrusion
            </motion.h2>
          </div>

          <motion.div
            className="ap-values-grid"
            variants={reduce ? undefined : stage}
            initial={reduce ? undefined : "hidden"}
            whileInView={reduce ? undefined : "show"}
            viewport={{ once: true, amount: 0.05 }}
          >
            {VALUES.map((v) => {
              const Icon = v.icon;
              return (
                <motion.div
                  className="ap-value-card"
                  key={v.title}
                  variants={reduce ? undefined : cardV}
                >
                  <span className="ap-value-icon">
                    <Icon width={20} height={20} />
                  </span>
                  <h3 className="ap-value-title">{v.title}</h3>
                  <p className="ap-value-text">{v.text}</p>
                </motion.div>
              );
            })}
          </motion.div>

          <motion.div
            className="ap-final"
            initial={{ opacity: 0, y: reduce ? 0 : 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.7, delay: reduce ? 0 : 0.15, ease: EASE }}
          >
            <Link
              href="#contact"
              className="btn btn-primary ap-final-cta"
              onClick={(e) => {
                // défilement fluide vers le formulaire de contact
                const target = document.getElementById("contact");
                if (!target) return;
                e.preventDefault();
                target.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
                history.replaceState(null, "", "#contact");
              }}
            >
              Contactez-nous
              <IconChevronRight width={17} height={17} />
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
