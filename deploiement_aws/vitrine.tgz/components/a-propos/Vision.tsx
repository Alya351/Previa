"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useInView, useReducedMotion } from "motion/react";
import Logo from "@/components/home/Logo";

const EASE = [0.22, 1, 0.36, 1] as const;

/* Positions des nœuds sur l'arc (viewBox 1400 × 560, centre 700,570, rayon 450). */
const STEPS = [
  { n: "01", title: "Voir", text: "Les images sont capturées par les caméras.", x: 19.43, y: 76.96, at: 0, side: "left" },
  { n: "02", title: "Analyser", text: "L'intelligence artificielle analyse les comportements.", x: 33, y: 33.57, at: 0.278, side: "up" },
  { n: "03", title: "Comprendre", text: "Previa identifie les situations inhabituelles ou à risque.", x: 67, y: 33.57, at: 0.722, side: "up" },
  { n: "04", title: "Agir", text: "Les utilisateurs peuvent réagir rapidement.", x: 80.57, y: 76.96, at: 1, side: "right" },
] as const;

const QUOTE = { hidden: {}, show: { transition: { staggerChildren: 0.16, delayChildren: 0.05 } } };
const RISE = {
  hidden: { opacity: 0, y: 18 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: EASE } },
};
const POP = {
  hidden: { opacity: 0, scale: 0.5, rotate: -10 },
  show: { opacity: 1, scale: 1, rotate: 0, transition: { duration: 0.65, ease: [0.34, 1.56, 0.64, 1] as const } },
};
const LINE_L = {
  hidden: { scaleX: 0 },
  show: { scaleX: 1, transition: { duration: 0.9, ease: EASE } },
};
const LINE_R = LINE_L;
const BAR = {
  hidden: { scaleX: 0 },
  show: { scaleX: 1, transition: { duration: 0.6, ease: EASE } },
};

function QuoteMark({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="4.4 6 16.2 12" width="26" height="20" aria-hidden>
      <path d="M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z" fill="currentColor" />
    </svg>
  );
}

/**
 * Affichage sur ordinateur : "quote" (citation, comme sur mobile) ou "arc" (arc interactif).
 * Le code de l'arc est conservé : repasser à "arc" suffit pour le retrouver.
 */
const DESKTOP_VARIANT: "arc" | "quote" = "arc";

const ARC = "M272 431 A450 450 0 0 1 1128 431";

export default function Vision() {
  const reduce = useReducedMotion();
  const stageRef = useRef<HTMLDivElement>(null);
  const inView = useInView(stageRef, { amount: 0.5 });
  // -1 = aucune étape, 0..3 = étape mise en avant (pastille + bulle)
  const [step, setStep] = useState(-1);
  const [paused, setPaused] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [restart, setRestart] = useState(0); // relance le minuteur du cycle automatique

  useEffect(() => {
    if (reduce || paused || !inView) return;
    const id = setInterval(() => setStep((s) => (s >= STEPS.length - 1 ? -1 : s + 1)), 3200);
    return () => clearInterval(id);
  }, [reduce, paused, inView, restart]);

  // Un clic n'importe où ailleurs que sur une pastille referme la bulle.
  useEffect(() => {
    const onDown = (e: PointerEvent) => {
      const el = e.target as HTMLElement | null;
      if (el?.closest(".ap-arc-node")) return;
      setStep(-1);
      setPaused(false);
      setHovering(false);
      setRestart((n) => n + 1);
      if (document.activeElement instanceof HTMLElement && document.activeElement.closest(".ap-arc-node")) {
        document.activeElement.blur();
      }
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, []);

  const active = step >= 0 ? STEPS[step] : null;
  const progress = active ? active.at : 0;

  const focusStep = (i: number) => {
    setPaused(true);
    setHovering(true);
    setStep(i);
  };
  const release = () => {
    setPaused(false);
    setHovering(false);
  };
  // Automatique : la lumière met ~1,1 s à rejoindre la pastille suivante.
  const travel = hovering || reduce ? 0 : 1.1;
  const arrive = active && active.at > 0 ? travel : 0;

  return (
    <section className={`section ap-vision${DESKTOP_VARIANT === "quote" ? " is-quote" : ""}`}>
      <div className="container">
        <div className="ap-vision-head">
          <motion.span
            className="eyebrow"
            style={{ justifyContent: "center" }}
            initial={{ opacity: 0, y: reduce ? 0 : 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6 }}
          >
            Notre vision
          </motion.span>
          <motion.p
            className="ap-vision-phrase"
            initial={{ opacity: 0, y: reduce ? 0 : 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.75, delay: reduce ? 0 : 0.1, ease: EASE }}
          >
            Ne plus seulement voir.{" "}
            <span className="accent-word">Comprendre ce qui se passe.</span>
          </motion.p>
          <motion.p
            className="ap-vision-lead"
            initial={{ opacity: 0, y: reduce ? 0 : 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.6, delay: reduce ? 0 : 0.25, ease: EASE }}
          >
            Née d&apos;un besoin réel : aller au-delà de l&apos;enregistrement.
          </motion.p>
        </div>

        {/* Ordinateur : arc orienté vers le haut */}
        <div className="ap-arc" ref={stageRef} onMouseLeave={release}>
          <span className="ap-arc-disc" aria-hidden />

          <svg className="ap-arc-svg" viewBox="0 0 1400 560" aria-hidden>
            <defs>
              <linearGradient id="apArcGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="#7cc4ee" />
                <stop offset="1" stopColor="#1a6fb5" />
              </linearGradient>
            </defs>
            <path d={ARC} className="ap-arc-band" />
            <motion.path
              d={ARC}
              className="ap-arc-track"
              initial={{ pathLength: reduce ? 1 : 0 }}
              whileInView={{ pathLength: 1 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 1.6, ease: EASE }}
            />
            <motion.path
              d={ARC}
              className="ap-arc-progress"
              pathLength={1}
              strokeDasharray={1}
              initial={false}
              animate={{ strokeDashoffset: 1 - progress, opacity: progress > 0 ? 1 : 0 }}
              transition={{ duration: hovering ? 0.6 : 1.1, ease: hovering ? EASE : "easeInOut" }}
            />
            <motion.path
              d={ARC}
              className="ap-arc-head"
              pathLength={1}
              strokeDasharray="0.014 2"
              initial={false}
              animate={{ strokeDashoffset: -(progress - 0.007), opacity: step >= 0 ? 1 : 0 }}
              transition={{ duration: hovering ? 0.6 : 1.1, ease: hovering ? EASE : "easeInOut" }}
            />
          </svg>

          {STEPS.map((s, i) => (
            <motion.button
              key={s.n}
              type="button"
              className={`ap-arc-node is-${s.side} at-${i}${step === i ? " is-on" : ""}${step > i ? " is-done" : ""}`}
              style={{ left: `${s.x}%`, top: `${s.y}%`, ["--i" as string]: i }}
              initial={{ opacity: 0, scale: reduce ? 1 : 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.6, delay: reduce ? 0 : 0.5 + i * 0.25, ease: EASE }}
              onMouseEnter={() => focusStep(i)}
              onFocus={() => focusStep(i)}
              onBlur={release}
              aria-label={`${s.n} ${s.title}`}
            >
              <span
                className="ap-arc-dot"
                style={{ transitionDelay: step === i ? `${arrive}s` : "0s" }}
              >
                {s.n}
              </span>
              <span className="ap-arc-label">{s.title}</span>
              <AnimatePresence>
                {step === i && (
                  <motion.span
                    key="bulle"
                    className="ap-arc-bubble"
                    initial={{ opacity: 0, scale: reduce ? 1 : 0.8, y: reduce ? 0 : 8 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: reduce ? 1 : 0.9, transition: { duration: 0.2, delay: 0 } }}
                    transition={{ duration: 0.4, ease: EASE, delay: arrive }}
                  >
                    <strong>{s.title}</strong>
                    {s.text}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          ))}

          <motion.div
            className="ap-arc-center"
            initial={{ opacity: 0, scale: reduce ? 1 : 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.9, delay: reduce ? 0 : 0.3, ease: EASE }}
          >
            <motion.div
              animate={reduce ? undefined : { scale: [1, 1.035, 1] }}
              transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <Logo height={46} />
            </motion.div>
          </motion.div>
        </div>

        {/* Mobile / tablette : citation, sans carte */}
        <motion.figure
          className="ap-m-quote"
          variants={reduce ? undefined : QUOTE}
          initial={reduce ? undefined : "hidden"}
          whileInView={reduce ? undefined : "show"}
          viewport={{ once: true, amount: 0.35 }}
        >
          <span className="ap-m-quote-top" aria-hidden>
            <motion.span className="ap-m-qbadge" variants={reduce ? undefined : POP}>
              <QuoteMark className="ap-m-qmark" />
            </motion.span>
            <motion.i variants={reduce ? undefined : LINE_L} />
          </span>
          <motion.p className="ap-m-quote-main" variants={reduce ? undefined : RISE}>
            Ne plus seulement voir.
            <strong>Comprendre ce qui se passe.</strong>
          </motion.p>
          <motion.span className="ap-m-quote-bar" aria-hidden variants={reduce ? undefined : BAR} />
          <motion.p className="ap-m-quote-text" variants={reduce ? undefined : RISE}>
            Previa donne aux caméras la capacité de repérer <strong>ce qui sort de l&apos;ordinaire</strong> et
            d&apos;alerter à temps, pour <strong>agir avant l&apos;intrusion</strong>.
          </motion.p>
          <span className="ap-m-quote-end" aria-hidden>
            <motion.i variants={reduce ? undefined : LINE_R} />
            <motion.span className="ap-m-qbadge" variants={reduce ? undefined : POP}>
              <QuoteMark className="ap-m-qmark ap-m-qmark--close" />
            </motion.span>
          </span>
        </motion.figure>
      </div>
    </section>
  );
}
