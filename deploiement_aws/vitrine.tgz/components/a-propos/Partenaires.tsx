"use client";

import { motion, useReducedMotion } from "motion/react";

const EASE = [0.22, 1, 0.36, 1] as const;

const PARTNERS = [
  { name: "Orange", src: "/partenaires/Orange.png" },
  { name: "Orange Summer Challenge", src: "/partenaires/OSC.png" },
  { name: "Meta", src: "/partenaires/Meta.png" },
  { name: "AWS", src: "/partenaires/aws.png" },
  { name: "NVIDIA", src: "/partenaires/NVIDIA.jpg" },
  { name: "Canva", src: "/partenaires/CANVA.png" },
] as const;

export default function Partenaires() {
  const reduce = useReducedMotion();

  return (
    <section id="partenaires" className="section ap-partners">
      <div className="container">
        <motion.div
          className="ap-partners-head"
          initial={{ opacity: 0, y: reduce ? 0 : 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.7, ease: EASE }}
        >
          <span className="eyebrow" style={{ justifyContent: "center" }}>
            Nos partenaires
          </span>
        </motion.div>

        <div className="ap-marquee" aria-label="Nos partenaires">
          <div className={`ap-marquee-track${reduce ? " is-static" : ""}`}>
            {[0, 1].map((copy) => (
              <ul className="ap-marquee-list" key={copy} aria-hidden={copy === 1}>
                {PARTNERS.map((p) => (
                  <li className="ap-marquee-item" key={p.name}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.src} alt={copy === 0 ? p.name : ""} draggable={false} />
                  </li>
                ))}
              </ul>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
