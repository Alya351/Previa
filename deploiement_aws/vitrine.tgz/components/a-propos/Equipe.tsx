"use client";

import { useState } from "react";
import type { KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  IconUser,
  IconLayers,
  IconTarget,
  IconMail,
  IconPhone,
  IconMapPin,
  IconWhatsApp,
  IconTikTok,
} from "@/components/home/icons";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Vraies personnes, vraie orthographe, vraies photos (depuis /public). */
const TEAM = [
  {
    name: "DRABO Djamilatou",
    role: "Ingénieure de conception en Intelligence Artificielle",
    photo: "/DRABO%20Djamilatou.jpeg",
    email: "afoussatoudrabo@gmail.com",
    phone: "77-21-67-37",
    location: "Ouagadougou",
  },
  {
    name: "KABA Fanta",
    role: "Ingénieure de conception en Génie des Systèmes Numériques",
    photo: "/KABA%20Fanta.jpg",
    email: "amanefantak@gmail.com",
    phone: "02-79-30-18",
    location: "Ouagadougou",
  },
  {
    name: "KIEMDE Alya",
    role: "Ingénieure de conception en Génie des Systèmes Numériques",
    photo: "/KIEMDE%20Alya.jpg",
    email: "alyakiemde@gmail.com",
    phone: "51-23-43-57",
    location: "Ouagadougou",
  },
  {
    name: "NADEMBEGA Romaric",
    role: "Ingénieur de conception en réseaux et sécurité des systèmes d'information",
    photo: "/Romaric%20NADEMBEGA.jpg",
    email: "romaricnadembega11@gmail.com",
    phone: "76-90-01-42",
    location: "Ouagadougou",
  },
] as const;

const STATS = [
  { icon: IconUser, value: "4", label: "Membres" },
  { icon: IconLayers, value: "1", label: "Vision" },
  { icon: IconTarget, value: "∞", label: "Potentiel" },
] as const;

export default function Equipe() {
  const reduce = useReducedMotion();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="equipe" className="section ap-equipe">
      <div className="container">
        <div className="ap-equipe-head">
          <motion.span
            className="eyebrow"
            style={{ justifyContent: "center" }}
            initial={{ opacity: 0, y: reduce ? 0 : 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6 }}
          >
            À propos de l&apos;équipe
          </motion.span>

          <motion.div
            className="ap-equipe-text-frame"
            initial={{ opacity: 0, y: reduce ? 0 : 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.7, delay: reduce ? 0 : 0.12, ease: EASE }}
          >
            <span className="ap-equipe-rule" aria-hidden />
            <p className="ap-equipe-lead">
              Derrière Previa, une <span className="accent-word">équipe passionnée</span> par
              la technologie et convaincue qu&apos;elle peut contribuer à rendre notre
              environnement plus sûr.
            </p>
            <span className="ap-equipe-rule" aria-hidden />
          </motion.div>

          <motion.div
            className="ap-stats"
            initial={{ opacity: 0, y: reduce ? 0 : 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.6, delay: reduce ? 0 : 0.26, ease: EASE }}
          >
            {STATS.map((s) => {
              const Icon = s.icon;
              return (
                <div className="ap-stat" key={s.label}>
                  <span className="ap-stat-icon">
                    <Icon width={20} height={20} />
                  </span>
                  <span className="ap-stat-value">{s.value}</span>
                  <span className="ap-stat-label">{s.label}</span>
                </div>
              );
            })}
          </motion.div>
        </div>

        <div className="ap-team-grid">
          {TEAM.map((m, i) => {
            const isFlipped = openIndex === i;
            const toggle = () => setOpenIndex(isFlipped ? null : i);
            const onKeyDown = (e: KeyboardEvent) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                toggle();
              }
            };
            return (
              <motion.article
                key={m.name}
                className="ap-team-card"
                initial={{ opacity: 0, y: reduce ? 0 : 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.55, delay: reduce ? 0 : i * 0.1, ease: EASE }}
              >
                <div
                  className={`ap-team-stage${isFlipped ? " is-flipped" : ""}`}
                  role="button"
                  tabIndex={0}
                  aria-pressed={isFlipped}
                  aria-label={
                    isFlipped
                      ? `Revenir à la photo de ${m.name}`
                      : `Afficher la carte de visite de ${m.name}`
                  }
                  onClick={toggle}
                  onKeyDown={onKeyDown}
                >
                  {/* Face avant : photo + nom/poste centrés */}
                  <div className="ap-team-layer ap-team-layer-front">
                    <div className="ap-team-photo">
                      <img
                        src={m.photo}
                        alt={m.name}
                        className="ap-team-img"
                        loading="lazy"
                        decoding="async"
                        draggable={false}
                      />
                      <motion.span
                        className="ap-team-curtain"
                        aria-hidden
                        initial={{ scaleX: reduce ? 0 : 1 }}
                        whileInView={{ scaleX: 0 }}
                        viewport={{ once: true, amount: 0.6 }}
                        transition={{
                          duration: 0.75,
                          delay: reduce ? 0 : i * 0.1,
                          ease: EASE,
                        }}
                      />
                    </div>
                    <div className="ap-team-body">
                      <span className="ap-team-name">{m.name}</span>
                      <span className="ap-team-role">{m.role}</span>
                    </div>
                  </div>

                  {/* Face arrière : carte de visite */}
                  <div className="ap-team-layer ap-team-layer-back">
                    <div className="biz-card">
                      <svg
                        className="biz-card-shape"
                        viewBox="0 0 350 200"
                        preserveAspectRatio="none"
                        aria-hidden
                      >
                        <path
                          d="M176,0 C258,18 196,92 258,122 C320,152 258,188 340,200 L350,200 L350,0 Z"
                          fill="#8fd3f4"
                        />
                        <path
                          d="M196,0 C270,18 214,90 272,120 C332,150 276,186 356,200 L350,200 L350,0 Z"
                          fill="#1c92e0"
                        />
                      </svg>

                      <div className="biz-card-social">
                        <a
                          href="https://whatsapp.com"
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label="Previa sur WhatsApp"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <IconWhatsApp width={14} height={14} />
                        </a>
                        <a
                          href="https://tiktok.com"
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label="Previa sur TikTok"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <IconTikTok width={13} height={13} />
                        </a>
                      </div>

                      <div className="biz-card-content">
                        <span className="biz-card-name">{m.name}</span>
                        <ul className="biz-card-rows">
                          <li className="biz-card-row">
                            <span className="biz-card-row-icon">
                              <IconMapPin width={11} height={11} />
                            </span>
                            <span className="biz-card-row-text">{m.location}</span>
                          </li>
                          <li className="biz-card-row">
                            <span className="biz-card-row-icon">
                              <IconPhone width={11} height={11} />
                            </span>
                            <span className="biz-card-row-text">{m.phone}</span>
                          </li>
                          <li className="biz-card-row">
                            <span className="biz-card-row-icon">
                              <IconMail width={11} height={11} />
                            </span>
                            <a
                              className="biz-card-row-text"
                              href={`mailto:${m.email}`}
                              onClick={(e) => e.stopPropagation()}
                            >
                              {m.email}
                            </a>
                          </li>
                        </ul>
                      </div>

                      <span className="biz-card-logo-badge">
                        <img
                          src="/logo-previa.png"
                          alt="Previa"
                          className="biz-card-logo"
                          draggable={false}
                        />
                      </span>
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
