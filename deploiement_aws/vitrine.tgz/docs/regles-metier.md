# Previa — Règles métier (source de vérité)

> Document de référence pour le backend. Toutes les règles ci-dessous ont été
> **validées**. En cas de doute pendant le développement, ce document fait foi.
> Le backend est écrit par l'équipe elle-même dans `backend/`.

---

## 1. Stack technique

| Couche | Choix |
|---|---|
| Langage | Python 3.12 |
| API | FastAPI + Uvicorn (gunicorn en production) |
| Base de données | Supabase (PostgreSQL) |
| Authentification | Supabase Auth (e-mail/mot de passe, Google, Apple, Facebook, mot de passe oublié) |
| Accès aux données | SQLAlchemy 2 + Alembic (migrations) |
| Validation | Pydantic |
| E-mails | Resend (aussi utilisé comme SMTP de Supabase Auth) |
| Tests / qualité | pytest, ruff |
| Hébergement | Render (connexion base via le pooler Supabase, port 6543) |

Le front appelle déjà une API sous `/api/v1/...` (voir `lib/api.ts`) : ce contrat
est conservé autant que possible.

---

## 2. Acteurs

| Acteur | Rôle |
|---|---|
| **Visiteur** | Consulte le site vitrine, écrit via le formulaire de contact, s'inscrit ou se connecte. |
| **Client** (rôle `utilisateur`) | Choisit une offre (Clé en main / Intégration), paie la 1re année en 3 tranches, reçoit et consulte son code, renouvelle. |
| **Superadmin** (rôle `superadmin`) | Génère et envoie les codes, gère clients et abonnements. Plusieurs superadmins possibles. |
| **Logiciel Previa installé** | Vérifie le code d'activation (chantier ultérieur, hors périmètre du backend actuel). |

Il n'y a que **deux rôles**. Le premier superadmin est créé par script ou
insertion directe en base : **l'inscription publique de superadmin est fermée**.

---

## 3. Parcours nominal

```
Client : inscription (e-mail confirmé) → choisit offre (+ profil particulier/entreprise) → paie la tranche 1/3
   └─> abonnement créé, statut « En attente du code »
Superadmin : ouvre la demande → « Générer le code d'activation » → « Envoyer au client »
   └─> premier envoi : abonnement « Actif », début = date d'envoi
Client : notification (e-mail + in-app) → lien vers l'étape OTP
   → OTP reçu par e-mail (10 min) → enveloppe → code + carte récapitulative
```

- Il n'y a **plus de validation ni de refus** par le superadmin.
- Un paiement qui échoue ne crée **aucune** demande ni aucun abonnement.
- Le client n'a **aucun bouton d'activation** : l'abonnement est actif dès le premier envoi.

---

## 4. Règles métier

### 4.1 Abonnement

| # | Règle |
|---|---|
| R1 | Un client a **au plus un abonnement** « actif », « suspendu » ou « en attente du code » à la fois. |
| R2 | Le **paiement crée l'abonnement** au statut « En attente du code ». |
| R3 | Le prix est un **prix tout compris de la 1re année** (1 an), fixé par offre et par profil (**particulier** ou **entreprise**). Il se paie en **3 tranches** (1/3 par quadrimestre) : la 1re à la commande (elle crée l'abonnement), les 2/3 et 3/3 depuis l'espace client (le reliquat d'arrondi est porté par la dernière). Dès l'**année 2**, le renouvellement est annuel au tarif `prix_renouvellement` (150 000 FCFA / an), possible une fois les 3 tranches réglées : s'il reste un reliquat, le client le **solde en même temps** que le renouvellement (deux paiements, un seul parcours). Le client peut aussi **solder d'un coup** toutes les tranches restantes. |
| R4 | Le **premier envoi** du code fait passer l'abonnement à « Actif » et fixe le **début** (= date d'envoi). La **fin** = début + durée. |
| R5 | Un **renvoi** du code ne relance pas l'abonnement : il ne fait que renotifier le client. |
| R6 | Le **renouvellement** ajoute une période au **même abonnement** et garde le **même code**. Il repousse la fin. |
| R7 | Un client peut **changer d'offre** au renouvellement ; la nouvelle offre s'applique à la nouvelle période. |
| R8 | Renouvellement d'un abonnement « actif » : la nouvelle période commence à la **fin de la précédente**. Depuis « expiré » : elle commence à la **date du paiement**. |
| R9 | « **Expiré** » est renouvelable (même abonnement, même code). « **Terminé** » est **définitif** : un nouvel achat crée un **nouvel abonnement et un nouveau code**. |
| R10 | Un abonnement « en attente du code » ne peut pas être renouvelé. |
| R11 | Suspendre ne modifie **pas** la date de fin (le temps continue de courir). Le superadmin peut prolonger à la main pour compenser. |
| R12 | **Réactiver** un abonnement suspendu le remet « Actif » ; si sa fin est déjà dépassée, il devient « Expiré ». |
| R13 | Le statut « Expiré » se **calcule à la lecture** (fin dépassée). Aucune tâche planifiée n'est nécessaire pour ce statut. |
| R14 | « **Expire bientôt** » = fin dans moins de **30 jours** (statut dérivé, non stocké). |
| R15 | Le superadmin peut **prolonger à la main d'un an** (modèle annuel : une période = 12 mois) : c'est une période de source « manuel », sans paiement. Même règle pour l'abonnement créé à la main après un devis. |
| R16a | **Tranches 2/3 et 3/3** : l'échéance est le début de l'abonnement + 4 mois par tranche écoulée (rien tant que le code n'est pas envoyé). Un **rappel** (in-app + e-mail) part **7 jours avant** l'échéance, une **relance** à l'échéance, et l'abonnement est **suspendu automatiquement** si la tranche reste impayée **7 jours** après l'échéance. |
| R16b | Une suspension **pour impayé** est **levée automatiquement** au règlement de la tranche. Une suspension décidée par le superadmin n'est jamais levée automatiquement. Rappels et suspension s'évaluent à la lecture de l'abonnement et par la tâche quotidienne (`POST /api/v1/internal/daily`), sans doublon. |
| R16 | Chaque **paiement conserve le prix payé** (les prix des offres peuvent changer ensuite). |

### 4.2 Code d'activation

| # | Règle |
|---|---|
| R20 | Le code est une **clé de licence** liée à l'abonnement (pas « à usage unique »), avec une **limite de caméras** donnée par l'offre courante. |
| R21 | **Un seul code par abonnement.** |
| R22 | Le **superadmin génère** le code **à la main** (bouton « Générer le code d'activation » dans la fiche demande). Aucun refus n'existe. |
| R23 | Le code **expire avec l'abonnement**. |
| R24 | Code **actif** = abonnement actif **et** code non désactivé manuellement. Les deux motifs de désactivation restent distincts. |
| R25 | **Suspendre ou terminer** un abonnement **désactive** son code ; **réactiver** l'abonnement le réactive (sauf désactivation manuelle). |
| R26 | Le code n'est **jamais** dans un e-mail. L'e-mail annonce seulement qu'il est disponible. |
| R27 | Le code est **stocké chiffré de façon réversible** (pour pouvoir être réaffiché) **et** avec une **empreinte** (pour la vérification par le logiciel). |

### 4.3 Accès du client au code (OTP)

| # | Règle |
|---|---|
| R30 | Parcours : notification (e-mail + in-app) → lien vers l'étape OTP → OTP → enveloppe → code. |
| R31 | L'OTP est envoyé **par e-mail**, valable **10 minutes**, avec un **popup centré** qui prévient le client. Un **compteur en petits carrés** affiche le temps restant. |
| R32 | Le compteur se base sur l'**heure d'expiration fournie par le serveur**. |
| R33 | **5 essais maximum**, puis verrouillage de **15 minutes**. |
| R34 | Un nouvel OTP **invalide l'ancien** ; **3 envois par heure** au maximum. |
| R35 | Après une OTP valide, le serveur délivre un **jeton de lecture valable 10 minutes**. Le code n'est renvoyé **que** avec ce jeton. |
| R36 | Le code n'est conservé **qu'en mémoire de la page** : rechargement ou départ du navigateur ⇒ **nouvel OTP**. |
| R37 | Le **PDF/reçu** n'est accessible **qu'après OTP**. |
| R38 | **Sans OTP**, le client voit le **statut et les dates** de son abonnement. Seuls le **code** et le **PDF** exigent l'OTP. |
| R39 | **Aucun code de démonstration** affiché en production. |
| R40 | L'écran affiche, après le code, une **carte récapitulative** (offre, début, fin, caméras). Pas de bouton d'activation. |

### 4.4 Superadmin

| # | Règle |
|---|---|
| R50 | La page **« Demandes »** est conservée : **tableau seul** (Client, Date, Abonnement), sans cartes de statistiques ni colonne de statut. |
| R51 | Sur une demande, le bouton **« Générer le code d'activation »** remplace l'ancien « Valider ». Il n'y a **plus** de bouton Refuser. |
| R52 | « **Envoyer au client** » envoie un **vrai e-mail** de notification (jamais le code lui-même). |
| R53 | Le superadmin voit le code **masqué**, avec une **icône œil** pour l'afficher. Cette consultation n'est **pas journalisée** (choix assumé). |
| R54 | Il peut **suspendre, réactiver, prolonger, terminer** un abonnement et **modifier ou supprimer** un client. |
| R55 | Il peut **désactiver/réactiver un code** seul (voir R24). |
| R56 | Le bouton **« Vider la base de données » est supprimé** de l'interface. |
| R57 | Le dashboard remplace « Demandes traitées % » par **« codes envoyés »** ; « Demandes en attente » devient **« demandes sans code »**. |
| R58 | Une **notification de rappel** est créée si une demande reste **sans code depuis plus de 48 heures**. |
| R59 | Les actions du superadmin sont enregistrées dans l'**historique** (sauf la consultation du code, R53). |

### 4.5 Offre Entreprise (sur devis)

| # | Règle |
|---|---|
| R60 | Une offre **sans prix en ligne** (`payable_en_ligne` faux ou prix vides) affiche **« Demander un devis »**. Les offres actuelles (PREVIA Clé en main : 570 000 / 670 000 FCFA ; PREVIA Intégration : 500 000 / 600 000 FCFA) sont payables en ligne. |
| R61 | « Demander un devis » exige d'être **connecté** (rattache la demande à un compte). Sinon, le superadmin crée le compte à la main. |
| R62 | Le superadmin **crée ensuite l'abonnement à la main** (périodes de source « manuel », sans paiement), puis suit le parcours normal (générer, envoyer). |
| R63 | `plans.prix_particulier`, `prix_entreprise` et `prix_renouvellement` peuvent être **vides** ; `plans.payable_en_ligne` indique si l'offre se paie sur le site. |

### 4.6 Comptes et suppression

| # | Règle |
|---|---|
| R70 | L'**e-mail doit être confirmé** avant un paiement. |
| R71 | Un client possède un seul statut stocké : celui de son **abonnement**. L'état du client se **déduit** (sauf « supprimé »). |
| R72 | La **suppression d'un client est douce** (`deleted_at`) : ses abonnements passent à « Terminé », ses codes sont désactivés, l'historique est conservé. |
| R73 | Un client supprimé est aussi **désactivé dans Supabase Auth**, et **chaque requête** vérifie que le profil n'est ni supprimé ni bloqué. |
| R74 | Le consentement aux conditions (avec sa date) est conservé à l'inscription. |
| R75 | Il n'y a **pas de remboursement** (le paiement est simulé). |
| R76 | Toutes les dates sont stockées en **UTC** (`timestamptz`). |

---

## 5. États et gestes autorisés

| Statut de l'abonnement | Générer le code | Envoyer | Renouveler | Suspendre | Terminer |
|---|---|---|---|---|---|
| En attente du code | Oui (un seul code) | Oui, si le code existe | Non | Non | Oui |
| Actif | Non | Renvoyer seulement | Oui (même offre ou autre) | Oui | Oui |
| Suspendu | Non | Non | Non | (déjà) | Oui |
| Expiré | Non | Non | Oui | Non | Oui |
| Terminé | Non | Non | Non (nouvel abonnement) | Non | (déjà) |

Statuts stockés : `en_attente_code`, `actif`, `suspendu`, `termine`.
Statuts **dérivés** à la lecture : `expire` (fin dépassée) et `expire_bientot` (< 30 jours).

---

## 6. Modèle de données (10 tables + journal des e-mails)

| Table | Champs principaux |
|---|---|
| `profiles` | id (= utilisateur Supabase Auth), rôle, prénom, nom, e-mail, téléphone, pays du numéro, entreprise, type de client (particulier/entreprise), consentement (date), `deleted_at` |
| `plans` | nom, prix mensuel (peut être vide), `payable_en_ligne`, caméras maximum, options, « logiciel seul » ou non |
| `subscriptions` | client, offre courante, statut, début, fin (dénormalisée depuis la dernière période) |
| `subscription_periods` | abonnement, offre de la période, durée (mois), début, fin, source (`paiement` ou `manuel`), paiement (facultatif) |
| `subscriptions` (tranches) | `prix_total` de la 1re année et `tranches_payees` (0..3) ; chaque `payments` porte sa `tranche` (vide = renouvellement annuel) |
| `payments` | client, abonnement, moyen (carte / Mobile Money), opérateur, montant payé (prix conservé), statut, référence lisible `PV-AAAA-…` |
| `bootstrap_codes` | abonnement (unique), code chiffré, empreinte, désactivé manuellement, généré le, **envoyé le** (premier envoi), dernier renvoi |
| `otp_challenges` | client, code haché, expire à, essais, verrouillé jusqu'à |
| `notifications` | destinataire (client ou superadmin), type, titre, texte, lien, lue, date |
| `audit_log` | auteur, action, cible, catégorie, date |
| `contact_messages` | nom, e-mail, téléphone, message, type (`message` ou `devis`), compte lié (facultatif) |
| `email_log` | destinataire, sujet, texte, statut (`envoye`, `console`, `echec`), erreur, date — trace de tous les e-mails (jamais le code) |

Chaîne : `paiement → abonnement (+ période) → code → envoi → abonnement actif`.

On **ne stocke jamais** : numéro de carte, CVV, code d'activation en clair, OTP en clair.

---

## 7. Sécurité

- Supabase Auth gère les mots de passe et les connexions sociales.
- Le rôle est contrôlé **côté serveur** à chaque route (`utilisateur` / `superadmin`).
- **RLS activé sur toutes les tables**, sans politique : l'API (rôle privilégié) applique
  les droits ; aucun accès direct depuis l'extérieur.
- CORS restreint, limitation de débit, aucun secret dans Git (`.env` ignoré).
- Le blocage de l'accès au code est **côté serveur** (R35), pas seulement dans l'interface.

---

## 8. Décisions encore ouvertes

| Sujet | État |
|---|---|
| **Domaine d'envoi des e-mails** | À décider : domaine vérifié chez Resend, ou SMTP (ex. Gmail) en attendant. En développement, tests vers sa propre adresse. |
| Vérification du code par le **logiciel installé** | Chantier distinct, plus tard. |

---

## 9. Front : état d'avancement

Fait (branché sur l'API, dossier `backend/`) :

- Client : offre + **profil** (particulier/entreprise) + prix de la 1re année en 3 tranches, paiement (carte / Mobile Money simulé), suivi « en attente du code »,
  notification, **popup OTP**, saisie OTP avec **compteur en petits carrés**, enveloppe et code, **carte récapitulative**,
  reçu PDF (après OTP), historique des paiements, **renouvellement**, « Demander un devis » (offre Entreprise),
  confirmation d'e-mail, mot de passe oublié.
- Superadmin : dashboard réel (chiffres, courbe, activité), liste des demandes (tableau seul), fiche demande
  (« Générer le code d'activation », « Envoyer au client » = e-mail réel, œil, copie, PDF, désactivation du code),
  abonnements (prolonger, suspendre, réactiver, terminer, historique des périodes), clients (modifier, supprimer),
  notifications, historique, création d'un autre superadmin.
- Supprimé : étape « Activer Previa », statuts « en attente / refusée », boutons Valider / Refuser, « Vider la base de données »,
  inscription publique du Superadmin, données de démonstration et mode hors-ligne (`localApi`).

Reste à faire :

- Connexions Google / Apple / Facebook (boutons encore cosmétiques) : Google prévu avec Supabase Auth ; Apple et Facebook à décider.
- Envoi réel des e-mails en production : clé Resend et domaine vérifié.
- Déploiement (Render), URL publique du front, appel quotidien de la tâche de rappels et ping de `/health/db`.

La page « Messages » du superadmin est faite (onglet de la page Notifications).

---

## 10. Étapes du backend (toutes réalisées, sauf le déploiement — voir `backend/README.md`)

1. Environnement : dossier `backend/`, Python 3.12, environnement virtuel, FastAPI qui répond sur `/health`.
2. Projet Supabase, connexion à la base, variables d'environnement.
3. Schéma des tables et migrations (Alembic).
4. Authentification et rôles.
5. Offres, paiement simulé, création de l'abonnement et de la période.
6. Génération du code (chiffrement + empreinte) et envoi.
7. OTP et jeton de lecture du code.
8. Espace superadmin : clients, demandes, abonnements, notifications, historique.
9. Renouvellement, suspension, réactivation, expiration à la lecture, rappels.
10. Sécurité (RLS, limitation de débit, CORS), tests.
11. Branchement du front, déploiement sur Render, dépôt GitHub.
