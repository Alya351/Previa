/**
 * Offre choisie sur la page Offres avant (ou sans) connexion.
 *
 * Le choix est mémorisé dans le navigateur puis repris par l'espace client (/code-amorcage) :
 * le visiteur se connecte ou s'inscrit, et retrouve son offre déjà sélectionnée. Le stockage local
 * (et non l'URL) survit au détour par le lien de confirmation d'e-mail.
 */

const KEY = "previa_plan_intent";
const TTL_MS = 24 * 60 * 60 * 1000;

export function setPlanIntent(planId: string, clientType?: "particulier" | "entreprise") {
  try {
    window.localStorage.setItem(KEY, JSON.stringify({ planId, clientType, at: Date.now() }));
  } catch {
    /* stockage indisponible : le client choisira son offre dans l'espace */
  }
}

/** Offre mémorisée (si récente), sans l'effacer. */
export function readPlanIntent(): string | null {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return null;
    const { planId, at } = JSON.parse(raw) as { planId?: string; at?: number };
    if (!planId || typeof at !== "number" || Date.now() - at > TTL_MS) {
      window.localStorage.removeItem(KEY);
      return null;
    }
    return planId;
  } catch {
    return null;
  }
}

/** Profil (particulier / entreprise) mémorisé avec l'offre, s'il y en a un. */
export function readPlanIntentClientType(): "particulier" | "entreprise" | null {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return null;
    const { clientType } = JSON.parse(raw) as { clientType?: string };
    return clientType === "particulier" || clientType === "entreprise" ? clientType : null;
  } catch {
    return null;
  }
}

export function clearPlanIntent() {
  try {
    window.localStorage.removeItem(KEY);
  } catch {
    /* rien à faire */
  }
}
