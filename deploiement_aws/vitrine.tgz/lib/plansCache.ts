import { api, type PlanApi } from "./api";

/**
 * Offres affichées immédiatement : le serveur (Render) peut mettre une minute à se réveiller, on ne fait donc
 * jamais attendre le visiteur. Ordre : dernières offres reçues (stockage local) → offres par défaut, puis
 * remplacement par la réponse de l'API dès qu'elle arrive.
 */
const KEY = "previa_plans_cache";

/** Miroir du seed du backend (backend/app/seed.py), utilisé tant que l'API n'a pas répondu. */
export const DEFAULT_PLANS: PlanApi[] = [
  {
    id: "cle-en-main",
    nom: "PREVIA Clé en main",
    prix_particulier: 570000,
    prix_entreprise: 670000,
    prix_renouvellement: 150000,
    payable_en_ligne: true,
    cameras_max: 3,
    logiciel_seul: false,
    options: ["3 caméras fournies", "Kit PREVIA et installation"],
    support: "1re année d'abonnement",
    recommande: true,
  },
  {
    id: "integration",
    nom: "PREVIA Intégration",
    prix_particulier: 500000,
    prix_entreprise: 600000,
    prix_renouvellement: 150000,
    payable_en_ligne: true,
    cameras_max: 3,
    logiciel_seul: true,
    options: ["Sur vos caméras existantes", "Kit PREVIA et installation"],
    support: "1re année d'abonnement",
    recommande: false,
  },
];

export function readCachedPlans(): PlanApi[] | null {
  try {
    const raw = window.localStorage.getItem(KEY);
    const list = raw ? (JSON.parse(raw) as PlanApi[]) : null;
    return Array.isArray(list) && list.length > 0 ? list : null;
  } catch {
    return null;
  }
}

/** Récupère les offres, les mémorise pour la prochaine visite et les renvoie. */
export async function fetchPlans(): Promise<PlanApi[]> {
  const list = await api.plans();
  try {
    window.localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    /* stockage indisponible : sans conséquence */
  }
  return list;
}

/** Réveille le serveur dès l'arrivée sur le site, pour qu'il soit prêt quand le visiteur ouvre les offres. */
export function warmPlans() {
  fetchPlans().catch(() => undefined);
}
