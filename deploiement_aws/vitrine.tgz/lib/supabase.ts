"use client";

/**
 * Supabase Auth (côté navigateur). Actif seulement si NEXT_PUBLIC_AUTH_PROVIDER=supabase
 * et si l'URL + la clé publique (anon / publishable) sont renseignées ; sinon le site
 * utilise l'authentification locale de l'API Previa.
 *
 * Deux clients indépendants (comme les deux sessions du site) : le client et le superadmin
 * peuvent être connectés en même temps dans le même navigateur.
 */

import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

/** Adresse publique du site pour les liens reçus par e-mail (NEXT_PUBLIC_SITE_URL), sinon l'adresse courante. */
export function siteUrl(): string {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim().replace(/\/+$/, "");
  return configured || window.location.origin;
}

export const SUPABASE_ENABLED = process.env.NEXT_PUBLIC_AUTH_PROVIDER === "supabase" && !!URL && !!KEY;

export type AuthLinkKind = "signup" | "recovery" | "email_change" | "error" | null;

let clientSb: SupabaseClient | null = null;
let adminSb: SupabaseClient | null = null;
let linkKind: AuthLinkKind = null;
let linkError = "";

/** Lu AVANT la création du client : supabase-js efface le fragment d'URL après avoir lu la session. */
function captureLink() {
  if (typeof window === "undefined") return;
  const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
  if (hash.get("error")) {
    linkKind = "error";
    linkError = hash.get("error_code") === "otp_expired" ? "Ce lien a expiré. Demandez-en un nouveau." : "Lien invalide.";
    return;
  }
  const type = hash.get("type");
  if (hash.get("access_token") && (type === "signup" || type === "recovery" || type === "email_change")) {
    linkKind = type;
  }
}

/** Client de l'espace client (gère aussi le retour des liens e-mail et de Google/Apple/Facebook). */
export function clientAuth(): SupabaseClient {
  if (!clientSb) {
    captureLink();
    clientSb = createClient(URL, KEY, {
      auth: { storageKey: "previa-sb-client", persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    });
  }
  return clientSb;
}

/** Client du superadmin : jamais de détection de session dans l'URL. */
export function adminAuth(): SupabaseClient {
  if (!adminSb) {
    adminSb = createClient(URL, KEY, {
      auth: { storageKey: "previa-sb-admin", persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    });
  }
  return adminSb;
}

/** Type du lien e-mail qui vient d'ouvrir la page (confirmation, mot de passe oublié…). */
export function pendingLink(): { kind: AuthLinkKind; error: string } {
  clientAuth();
  return { kind: linkKind, error: linkError };
}

/** Jeton valide (rafraîchi au besoin) de la session concernée, ou null si elle n'existe plus. */
export async function freshToken(scope: "client" | "admin"): Promise<string | null> {
  const sb = scope === "admin" ? adminAuth() : clientAuth();
  const { data } = await sb.auth.getSession();
  return data.session?.access_token ?? null;
}

/** Traduit une erreur Supabase Auth en message clair (français). */
export function authMessage(err: { message?: string; code?: string; status?: number }): string {
  switch (err.code) {
    case "invalid_credentials":
      return "Email ou mot de passe incorrect.";
    case "email_not_confirmed":
      return "Adresse e-mail non confirmée. Ouvrez le lien reçu par e-mail.";
    case "user_banned":
      return "Ce compte n'est plus actif. Contactez l'équipe Previa.";
    case "weak_password":
      return "Mot de passe trop faible (8 caractères minimum).";
    case "over_request_rate_limit":
    case "over_email_send_rate_limit":
      return "Trop de tentatives. Réessayez dans quelques minutes.";
    case "same_password":
      return "Le nouveau mot de passe doit être différent de l'ancien.";
    case "user_already_exists":
    case "email_exists":
      return "Un compte existe déjà avec cette adresse e-mail.";
    default:
      return err.status === 429 ? "Trop de tentatives. Réessayez dans quelques minutes." : "Une erreur est survenue. Veuillez réessayer.";
  }
}
