"use client";

import { useEffect, useState } from "react";
import { api } from "./api";
import { SUPABASE_ENABLED, adminAuth, freshToken } from "./supabase";

export type AdminUser = {
  id?: string;
  nom: string;
  prenom: string;
  email: string;
  role: "SUPERADMIN" | "admin";
  token?: string;
};

const ADMIN_KEY = "previa_admin_user";
const ADMIN_TOKEN_KEY = "previa_admin_token";
const ADMIN_EVENT = "previa-admin-auth-change";

export function readAdminToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(ADMIN_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function readStoredAdmin(): AdminUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(ADMIN_KEY);
    if (!raw) return null;
    const user = JSON.parse(raw) as AdminUser;
    user.token = user.token || readAdminToken() || undefined;
    return user;
  } catch {
    return null;
  }
}

export function setAdminUser(
  user: Omit<AdminUser, "role"> & { role?: string; token?: string }
) {
  try {
    const admin: AdminUser = {
      ...user,
      role: "SUPERADMIN",
    };
    window.localStorage.setItem(ADMIN_KEY, JSON.stringify(admin));
    if (user.token) {
      window.localStorage.setItem(ADMIN_TOKEN_KEY, user.token);
    }
  } catch {}
  window.dispatchEvent(new Event(ADMIN_EVENT));
}

export function clearAdminUser() {
  const token = readAdminToken();
  try {
    window.localStorage.removeItem(ADMIN_KEY);
    window.localStorage.removeItem(ADMIN_TOKEN_KEY);
  } catch {}
  window.dispatchEvent(new Event(ADMIN_EVENT));
  void token; // les jetons superadmin expirent seuls ; aucune route de révocation n'est nécessaire
  if (SUPABASE_ENABLED) adminAuth().auth.signOut().catch(() => {});
}

let syncBound = false;

/** Garde le jeton superadmin stocké aligné sur la session Supabase (rafraîchissement, déconnexion). */
function bindAdminSync() {
  if (!SUPABASE_ENABLED || syncBound || typeof window === "undefined") return;
  syncBound = true;
  adminAuth().auth.onAuthStateChange((event, session) => {
    setTimeout(() => {
      try {
        if (event === "SIGNED_OUT") {
          if (window.localStorage.getItem(ADMIN_TOKEN_KEY)) {
            window.localStorage.removeItem(ADMIN_KEY);
            window.localStorage.removeItem(ADMIN_TOKEN_KEY);
            window.dispatchEvent(new Event(ADMIN_EVENT));
          }
          return;
        }
        const stored = window.localStorage.getItem(ADMIN_TOKEN_KEY);
        if (session && stored && stored !== session.access_token) {
          window.localStorage.setItem(ADMIN_TOKEN_KEY, session.access_token);
          const raw = window.localStorage.getItem(ADMIN_KEY);
          if (raw) window.localStorage.setItem(ADMIN_KEY, JSON.stringify({ ...JSON.parse(raw), token: session.access_token }));
        }
      } catch {}
    }, 0);
  });
}

/**
 * Session Superadmin (indépendante de la session client).
 * Permet à l'administrateur d'accéder en permanence à /prevadm.
 */
export function useAdminUser() {
  const [user, setUser] = useState<AdminUser | null | undefined>(undefined);

  useEffect(() => {
    bindAdminSync();
    const sync = async () => {
      const stored = readStoredAdmin();
      let token = readAdminToken();
      if (SUPABASE_ENABLED && token) {
        // Jeton rafraîchi si expiré ; plus de session Supabase = déconnexion.
        const fresh = await freshToken("admin");
        if (!fresh) {
          clearAdminUser();
          setUser(null);
          return;
        }
        token = fresh;
      }

      // Si un profil admin est stocké localement, on le maintient immédiatement actif
      if (stored) {
        setUser(stored);
      } else {
        setUser(null);
        return;
      }

      // Si un token admin est disponible, vérifier et rafraîchir auprès du serveur
      if (token) {
        try {
          const fresh = await api.admin.getMe(token);
          if (fresh && fresh.role === "admin") {
            const updated: AdminUser = {
              id: fresh.id,
              nom: fresh.nom || stored.nom,
              prenom: fresh.prenom || stored.prenom,
              email: fresh.email || stored.email,
              role: "SUPERADMIN",
              token,
            };
            window.localStorage.setItem(ADMIN_KEY, JSON.stringify(updated));
            setUser(updated);
          }
        } catch (err: unknown) {
          // Jeton refusé (expiré, compte supprimé) : on ferme la session. Coupure réseau : on garde l'admin local.
          if ((err as { status?: number })?.status === 401 || (err as { status?: number })?.status === 403) {
            clearAdminUser();
            setUser(null);
          }
        }
      }
    };

    const onChange = () => {
      setUser(readStoredAdmin() ?? null);
    };

    sync();

    window.addEventListener(ADMIN_EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(ADMIN_EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  return user;
}

export function initialsOfAdmin(user: AdminUser) {
  return (user.prenom[0] ?? "").toUpperCase() + (user.nom[0] ?? "").toUpperCase();
}
