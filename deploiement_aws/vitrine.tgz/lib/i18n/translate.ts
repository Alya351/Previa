import { EXACT, PATTERNS } from "./dict/index";

const MONTHS_ABBR: Record<string, string> = {
  "janv.": "Jan", "févr.": "Feb", mars: "Mar", "avr.": "Apr", mai: "May", juin: "Jun",
  "juil.": "Jul", août: "Aug", "sept.": "Sep", "oct.": "Oct", "nov.": "Nov", "déc.": "Dec",
};
const MONTHS_FULL: Record<string, string> = {
  janvier: "January", février: "February", mars: "March", avril: "April", mai: "May", juin: "June",
  juillet: "July", août: "August", septembre: "September", octobre: "October", novembre: "November", décembre: "December",
};
const DAYS: Record<string, string> = {
  lundi: "Monday", mardi: "Tuesday", mercredi: "Wednesday", jeudi: "Thursday",
  vendredi: "Friday", samedi: "Saturday", dimanche: "Sunday",
};

const ABBR_RE = new RegExp(
  `(\\d{1,2}) (${Object.keys(MONTHS_ABBR).map((m) => m.replace(".", "\\.")).join("|")}) (\\d{4})`,
  "g"
);
const FULL_RE = new RegExp(`(\\d{1,2})(?:er)? (${Object.keys(MONTHS_FULL).join("|")}) (\\d{4})`, "gi");
const DAY_RE = new RegExp(
  `^(${Object.keys(DAYS).join("|")}) (\\d{1,2}) (${Object.keys(MONTHS_FULL).join("|")})$`,
  "i"
);

function translateDates(s: string): string {
  let r = s.replace(ABBR_RE, (_, d, m, y) => `${MONTHS_ABBR[m]} ${d}, ${y}`);
  r = r.replace(FULL_RE, (_, d, m, y) => `${MONTHS_FULL[m.toLowerCase()]} ${d}, ${y}`);
  r = r.replace(DAY_RE, (_, day, d, m) => `${DAYS[day.toLowerCase()]}, ${MONTHS_FULL[m.toLowerCase()]} ${d}`);
  return r;
}

/** Traduit une chaîne française vers l'anglais ; renvoie la chaîne inchangée si inconnue. */
export function translate(fr: string): string {
  const lead = fr.match(/^\s*/)![0];
  const trail = fr.match(/\s*$/)![0];
  const core = fr.trim().replace(/\s+/g, " ");
  if (!core) return fr;

  const hit = EXACT[core];
  if (hit !== undefined) return lead + hit + trail;

  for (const [re, fn] of PATTERNS) {
    const m = core.match(re);
    if (m) return lead + fn(...m.slice(1)) + trail;
  }

  const dated = translateDates(core);
  if (dated !== core) {
    const again = EXACT[dated];
    return lead + (again ?? dated) + trail;
  }
  return fr;
}

/** Langue courante de l'interface (lue sur <html lang>). */
export const currentLang = (): "fr" | "en" =>
  typeof document !== "undefined" && document.documentElement.lang === "en" ? "en" : "fr";

/** Traduit seulement si l'interface est en anglais (pour les contenus générés hors DOM : PDF…). */
export const tr = (fr: string): string => (currentLang() === "en" ? translate(fr) : fr);
