import { translate } from "./translate";

/**
 * Traduction du DOM : le site est rédigé en français ; en mode anglais, chaque
 * nœud texte et chaque attribut d'interface est remplacé par sa traduction,
 * et l'original est conservé pour revenir au français sans rechargement.
 */
const ATTRS = ["placeholder", "title", "aria-label", "alt"];
const SKIP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "CODE", "TEXTAREA"]);

type Rec = { fr: string; en: string };
const textRecs = new WeakMap<Text, Rec>();
const attrRecs = new WeakMap<Element, Record<string, Rec>>();

let observer: MutationObserver | null = null;
let active = false;
let titleRec: Rec | null = null;

const skipped = (el: Element | null) =>
  !!el && (SKIP.has(el.tagName) || !!el.closest("[data-no-translate]"));

function applyText(n: Text) {
  if (skipped(n.parentElement)) return;
  const cur = n.nodeValue ?? "";
  const rec = textRecs.get(n);
  const fr = rec && cur === rec.en ? rec.fr : cur;
  const en = translate(fr);
  if (en !== fr) {
    textRecs.set(n, { fr, en });
    if (cur !== en) n.nodeValue = en;
  } else {
    textRecs.delete(n);
  }
}

function applyAttrs(el: Element) {
  if (el.closest("[data-no-translate]")) return;
  let recs = attrRecs.get(el);
  for (const a of ATTRS) {
    const cur = el.getAttribute(a);
    if (cur === null) continue;
    const rec = recs?.[a];
    const fr = rec && cur === rec.en ? rec.fr : cur;
    const en = translate(fr);
    if (en !== fr) {
      if (!recs) attrRecs.set(el, (recs = {}));
      recs[a] = { fr, en };
      if (cur !== en) el.setAttribute(a, en);
    } else if (recs) {
      delete recs[a];
    }
  }
}

function applyTitle() {
  const cur = document.title;
  const fr = titleRec && cur === titleRec.en ? titleRec.fr : cur;
  const en = translate(fr);
  if (en !== fr) {
    titleRec = { fr, en };
    if (cur !== en) document.title = en;
  } else {
    titleRec = null;
  }
}

function walk(root: Node) {
  if (root.nodeType === Node.TEXT_NODE) return applyText(root as Text);
  if (root.nodeType !== Node.ELEMENT_NODE) return;
  const el = root as Element;
  applyAttrs(el);
  if (skipped(el)) return;
  const tw = document.createTreeWalker(el, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let n: Node | null = tw.nextNode();
  while (n) {
    if (n.nodeType === Node.TEXT_NODE) applyText(n as Text);
    else applyAttrs(n as Element);
    n = tw.nextNode();
  }
}

function restore(root: Node) {
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let n: Node | null = tw.currentNode;
  while (n) {
    if (n.nodeType === Node.TEXT_NODE) {
      const t = n as Text;
      const rec = textRecs.get(t);
      if (rec && t.nodeValue === rec.en) t.nodeValue = rec.fr;
      textRecs.delete(t);
    } else if (n.nodeType === Node.ELEMENT_NODE) {
      const el = n as Element;
      const recs = attrRecs.get(el);
      if (recs) {
        for (const [a, rec] of Object.entries(recs)) {
          if (el.getAttribute(a) === rec.en) el.setAttribute(a, rec.fr);
        }
        attrRecs.delete(el);
      }
    }
    n = tw.nextNode();
  }
  if (titleRec && document.title === titleRec.en) document.title = titleRec.fr;
  titleRec = null;
}

function attach() {
  if (!observer || !active) return;
  observer.observe(document.body, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: ATTRS,
  });
  observer.observe(document.head, { subtree: true, childList: true, characterData: true });
}

export function startTranslating() {
  if (active) return;
  active = true;
  walk(document.body);
  applyTitle();

  observer = new MutationObserver((mutations) => {
    if (!observer) return;
    // On se déconnecte pendant nos propres écritures pour ne pas nous re-déclencher.
    observer.disconnect();
    for (const m of mutations) {
      if (m.type === "characterData") {
        const t = m.target;
        if (t.parentElement?.closest("head")) applyTitle();
        else applyText(t as Text);
      } else if (m.type === "attributes") {
        applyAttrs(m.target as Element);
      } else if (m.type === "childList") {
        if (m.target === document.head || (m.target as Element).tagName === "TITLE") applyTitle();
        m.addedNodes.forEach((node) => walk(node));
      }
    }
    attach();
  });
  attach();
}

export function stopTranslating() {
  if (!active) return;
  active = false;
  observer?.disconnect();
  observer = null;
  restore(document.body);
}
