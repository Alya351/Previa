import { COMMON } from "./common";
import { PUBLIC } from "./public";
import { ESPACE } from "./espace";
import { ADMIN } from "./admin";
import { PARCOURS } from "./parcours";
import { PATTERNS as EXTRA_PATTERNS } from "./patterns";

const ALL: Record<string, string> = { ...COMMON, ...PUBLIC, ...ESPACE, ...ADMIN, ...PARCOURS };

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Entrées littérales (clé = texte français normalisé, espaces réduits). */
export const EXACT: Record<string, string> = {};

/** Entrées à trous (« Bonjour {0}, … ») converties en motifs, plus les motifs écrits à la main. */
export const PATTERNS: [RegExp, (...m: string[]) => string][] = [];

for (const [fr, en] of Object.entries(ALL)) {
  if (/\{\d+\}/.test(fr)) {
    const parts = fr.split(/\{\d+\}/);
    const order = [...fr.matchAll(/\{(\d+)\}/g)].map((m) => Number(m[1]));
    const re = new RegExp("^" + parts.map(escapeRe).join("(.+?)") + "$");
    PATTERNS.push([re, (...m) => en.replace(/\{(\d+)\}/g, (_, i) => m[order.indexOf(Number(i))] ?? "")]);
  } else {
    EXACT[fr] = en;
  }
}
PATTERNS.push(...EXTRA_PATTERNS);
