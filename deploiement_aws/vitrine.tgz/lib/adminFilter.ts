"use client";

import { useCallback, useSyncExternalStore } from "react";

/**
 * Petit store partagé : le filtre choisi en cliquant sur une carte de chiffres
 * (bandeau du haut) doit être lu par la liste située plus bas, alors que les deux
 * composants sont rendus à des endroits différents de la page.
 */
const values = new Map<string, string>();
const listeners = new Set<() => void>();

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

export const ALL = "tous";

export function useAdminFilter(page: string) {
  const value = useSyncExternalStore(
    subscribe,
    () => values.get(page) ?? ALL,
    () => ALL
  );

  const setValue = useCallback(
    (next: string) => {
      values.set(page, next);
      listeners.forEach((l) => l());
    },
    [page]
  );

  /** Cliquer deux fois sur la même carte retire le filtre. */
  const toggle = useCallback(
    (next: string) => {
      const current = values.get(page) ?? ALL;
      setValue(current === next ? ALL : next);
    },
    [page, setValue]
  );

  return { value, setValue, toggle };
}
