"use client";

import { useEffect, useState } from "react";
import { api, type Compte } from "./api";
import { SUPABASE_ENABLED, clientAuth, freshToken } from "./supabase";

export type AuthUser = {
  id?: string;
  name: string;
  prenom?: string;
  nom?: string;
  email: string;
  role?: "user" | "admin" | string;
  entreprise?: string;
  token?: string;
};

const AUTH_KEY = "previa_auth_user";
const TOKEN_KEY = "previa_auth_token";
const AUTH_EVENT = "previa-auth-change";
const OAUTH_KEY = "previa_oauth_pending";
const OAUTH_MAX_AGE_MS = 10 * 60 * 1000;

export function readStoredToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function readStoredUser(): AuthUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(AUTH_KEY);
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  } catch {
    return null;
  }
}

export function setAuthSession(compte: Compte, token: string) {
  try {
    const user: AuthUser = {
      id: compte.id,
      name: `${compte.prenom} ${compte.nom}`.trim() || compte.email,
      prenom: compte.prenom,
      nom: compte.nom,
      email: compte.email,
      role: compte.role,
      entreprise: compte.entreprise ?? undefined,
      token,
    };
    window.localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    window.localStorage.setItem(TOKEN_KEY, token);
    window.localStorage.removeItem(OAUTH_KEY);
  } catch {}
  window.dispatchEvent(new Event(AUTH_EVENT));
}

/** Efface la session locale sans rien demander au serveur (session déjà fermée côté Supabase). */
function wipeLocalSession() {
  try {
    window.localStorage.removeItem(AUTH_KEY);
    window.localStorage.removeItem(TOKEN_KEY);
  } catch {}
  window.dispatchEvent(new Event(AUTH_EVENT));
}

function storeRefreshedToken(token: string) {
  try {
    window.localStorage.setItem(TOKEN_KEY, token);
    const raw = window.localStorage.getItem(AUTH_KEY);
    if (raw) window.localStorage.setItem(AUTH_KEY, JSON.stringify({ ...JSON.parse(raw), token }));
  } catch {}
}

/** Ouvre la session du site à partir d'une session Supabase (lien de confirmation, retour Google/Apple/Facebook). */
export async function completeClientLogin(token: string): Promise<boolean> {
  try {
    const compte = await api.auth.getMe(token);
    if (compte.role !== "user") throw new Error("role");
    setAuthSession(compte, token);
    return true;
  } catch {
    await clientAuth().auth.signOut();
    return false;
  }
}

let syncBound = false;

/** Garde le jeton stocké aligné sur la session Supabase (rafraîchissement, déconnexion) et finalise un retour OAuth. */
export function bindClientSync() {
  if (!SUPABASE_ENABLED || syncBound || typeof window === "undefined") return;
  syncBound = true;
  clientAuth().auth.onAuthStateChange((event, session) => {
    // Pas d'appel Supabase direct dans ce rappel (risque de blocage) : on sort de la pile.
    setTimeout(async () => {
      if (event === "SIGNED_OUT") {
        if (readStoredToken()) wipeLocalSession();
        return;
      }
      if (!session) return;
      const stored = readStoredToken();
      if (stored) {
        if (stored !== session.access_token) storeRefreshedToken(session.access_token);
        return;
      }
      let since = 0;
      try {
        since = Number(window.localStorage.getItem(OAUTH_KEY)) || 0;
      } catch {}
      if (since && Date.now() - since < OAUTH_MAX_AGE_MS && (await completeClientLogin(session.access_token))) {
        window.location.assign("/code-amorcage");
      }
    }, 0);
  });
}

export function setAuthUser(user: AuthUser) {
  try {
    window.localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    if (user.token) {
      window.localStorage.setItem(TOKEN_KEY, user.token);
    }
  } catch {}
  window.dispatchEvent(new Event(AUTH_EVENT));
}

export function clearAuthUser() {
  const token = readStoredToken();
  try {
    window.localStorage.removeItem(AUTH_KEY);
    window.localStorage.removeItem(TOKEN_KEY);
  } catch {}
  window.dispatchEvent(new Event(AUTH_EVENT));
  // Révocation côté serveur en best-effort : la déconnexion locale ne doit
  // jamais attendre ni échouer à cause de l'appel réseau.
  if (token) {
    api.auth.logout(token).catch(() => {});
  }
}

/** Utilisateur connecté (synchronisé avec l'API Previa). */
export function useAuthUser() {
  const [user, setUser] = useState<AuthUser | null | undefined>(undefined);

  useEffect(() => {
    bindClientSync();
    const sync = async () => {
      const stored = readStoredUser();
      let token = readStoredToken();
      if (SUPABASE_ENABLED && token) {
        // Jeton rafraîchi si expiré ; plus de session Supabase = déconnexion.
        const fresh = await freshToken("client");
        if (!fresh) {
          wipeLocalSession();
          setUser(null);
          return;
        }
        if (fresh !== token) storeRefreshedToken(fresh);
        token = fresh;
      }
      if (!token) {
        setUser(stored ?? null);
        return;
      }

      setUser(stored ?? null);

      // Rafraîchir les informations depuis le backend /moi en arrière-plan
      try {
        const fresh = await api.auth.getMe(token);
        if (fresh) {
          const updated: AuthUser = {
            id: fresh.id,
            name: `${fresh.prenom} ${fresh.nom}`.trim() || fresh.email,
            prenom: fresh.prenom,
            nom: fresh.nom,
            email: fresh.email,
            role: fresh.role,
            entreprise: fresh.entreprise ?? undefined,
            token,
          };
          window.localStorage.setItem(AUTH_KEY, JSON.stringify(updated));
          setUser(updated);
        }
      } catch (err: any) {
        // Si le token est expiré (401), nettoyer la session
        if (err?.status === 401) {
          clearAuthUser();
          setUser(null);
        }
      }
    };

    const onChange = () => setUser(readStoredUser());
    sync();

    window.addEventListener(AUTH_EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(AUTH_EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  return user ?? null;
}

export function initialsOf(name: string) {
  const parts = name.trim().split(/\s+/);
  const first = parts[0]?.[0] ?? "";
  const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
  return (first + last).toUpperCase();
}
