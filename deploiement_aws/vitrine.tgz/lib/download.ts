/**
 * Téléchargement de Previa : un seul bouton, le bon fichier selon l'appareil.
 * Renseigner ici les adresses des installateurs dès qu'ils sont disponibles
 * (laisser vide = le bouton affiche « bientôt disponible »).
 */
export type DownloadPlatform = "windows" | "android" | "ios" | "web";

export const DOWNLOAD_LINKS: Record<DownloadPlatform, string> = {
  web: process.env.NEXT_PUBLIC_APP_URL || "https://app.previa-bf.com",
  windows: "",
  android: "/telechargements/previa-v1.0.0.apk",
  ios: "",
};

/** Appareil du visiteur (par défaut Windows sur ordinateur). */
export function detectPlatform(): DownloadPlatform {
  if (typeof navigator === "undefined") return "windows";
  const ua = navigator.userAgent || "";
  if (/android/i.test(ua)) return "android";
  if (/iphone|ipad|ipod/i.test(ua)) return "ios";
  return "windows";
}

/** Lance le téléchargement ; renvoie false si aucun fichier n'est encore disponible pour cet appareil. */
export function startDownload(platform: DownloadPlatform = detectPlatform()): boolean {
  const url = DOWNLOAD_LINKS[platform];
  if (!url) return false;
  // Application web : on l'ouvre dans un nouvel onglet (ce n'est pas un fichier).
  if (platform === "web") {
    window.open(url, "_blank", "noopener,noreferrer");
    return true;
  }
  const a = document.createElement("a");
  a.href = url;
  a.rel = "noopener";
  a.download = "";
  document.body.appendChild(a);
  a.click();
  a.remove();
  return true;
}
