/**
 * Types et convertisseurs du back-office Superadmin.
 * Les données viennent de l'API (lib/api.ts) ; ces types sont ceux que manipulent les pages.
 */
import type {
  AbonnementApi,
  ClientApi,
  DemandeApi,
  HistoriqueApi,
  MessageApi,
  MessageReplyApi,
  NotificationApi,
  Periode,
  SubStatus,
} from "./api";

export type ClientStatus =
  | "actif"
  | "expire"
  | "suspendu"
  | "supprime"
  | "en_attente"
  | "termine"
  | "sans_abonnement";

export type Client = {
  id: string;
  nom: string;
  prenom: string;
  email: string;
  telephone?: string;
  entreprise?: string;
  dateInscription: string;
  statut: ClientStatus;
};

export type Formule = string;

export type AbonnementStatus = "en_attente_code" | "actif" | "expirant" | "expire" | "suspendu" | "termine";

export type PeriodeView = {
  id: string;
  ordre: number;
  formule: string;
  dureeMois: number;
  debut: string;
  fin: string;
  source: "paiement" | "manuel";
};

export type Abonnement = {
  id: string;
  reference: string;
  clientId: string;
  formule: Formule;
  dateDebut: string;
  dateFin: string;
  statut: AbonnementStatus;
  periodes: PeriodeView[];
};

/** Une demande = un abonnement issu d'un paiement, qui attend (ou a reçu) son code d'activation. */
export type Demande = {
  id: string;
  reference: string;
  clientId: string;
  date: string;
  formule: Formule;
  dureeMois?: number;
  codeGenere: boolean;
  codeEnvoye: boolean;
  codeActif: boolean;
  codeDesactiveManuellement: boolean;
  dateEnvoi?: string;
};

export type NotifAdminKind = "demande" | "abonnement" | "systeme";

export type NotifAdmin = {
  id: string;
  kind: NotifAdminKind;
  title: string;
  text: string;
  date: string;
  read: boolean;
  link?: string;
};

export type HistoriqueCategorie = "clients" | "demandes" | "codes" | "abonnements" | "compte" | "messages";

export type HistoriqueEntry = {
  id: string;
  action: string;
  cible: string;
  auteur: string;
  categorie: HistoriqueCategorie;
  date: string;
};

export type MessageType = "message" | "devis";

export type Message = {
  id: string;
  nom: string;
  email: string;
  telephone?: string;
  texte: string;
  type: MessageType;
  /** Compte client rattaché (devis uniquement) : permet de rejoindre sa fiche. */
  clientId?: string;
  traite: boolean;
  date: string;
};

export type MessageReply = {
  id: string;
  auteur: string;
  objet: string;
  texte: string;
  date: string;
};

// ── Formats ──────────────────────────────────────────────────────────────
export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short", year: "numeric" }).format(new Date(iso));
}

export function fmtDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  const time = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" }).format(d);
  return `${fmtDate(iso)} — ${time}`;
}

// ── Convertisseurs API → interface ───────────────────────────────────────
const STATUT_ABO: Record<SubStatus, AbonnementStatus> = {
  en_attente_code: "en_attente_code",
  actif: "actif",
  expire_bientot: "expirant",
  expire: "expire",
  suspendu: "suspendu",
  termine: "termine",
};

function toPeriode(p: Periode): PeriodeView {
  return {
    id: p.id,
    ordre: p.ordre,
    formule: p.plan,
    dureeMois: p.duree_mois,
    debut: fmtDate(p.debut),
    fin: fmtDate(p.fin),
    source: p.source,
  };
}

export function toAbonnement(a: AbonnementApi): Abonnement {
  return {
    id: a.id,
    reference: a.reference,
    clientId: a.client_id,
    formule: a.plan.nom,
    dateDebut: fmtDate(a.debut),
    dateFin: fmtDate(a.fin),
    statut: STATUT_ABO[a.statut],
    periodes: (a.periodes ?? []).map(toPeriode),
  };
}

export function toClient(c: ClientApi): Client {
  return {
    id: c.id,
    nom: c.nom,
    prenom: c.prenom,
    email: c.email,
    telephone: c.telephone ?? undefined,
    entreprise: c.entreprise ?? undefined,
    dateInscription: fmtDate(c.cree_le),
    statut: (c.statut ?? "sans_abonnement") as ClientStatus,
  };
}

export function toDemande(d: DemandeApi): Demande {
  return {
    id: d.id,
    reference: d.reference,
    clientId: d.client.id,
    date: fmtDate(d.date),
    formule: d.formule,
    dureeMois: d.duree_mois ?? undefined,
    codeGenere: d.code_genere,
    codeEnvoye: d.code_envoye,
    codeActif: d.code_actif,
    codeDesactiveManuellement: d.code_desactive_manuellement,
    dateEnvoi: d.code_envoye_le ? fmtDate(d.code_envoye_le) : undefined,
  };
}

export function toNotif(n: NotificationApi): NotifAdmin {
  const kind: NotifAdminKind =
    n.type === "abonnement" ? "abonnement" : n.type === "demande" || n.type === "rappel" ? "demande" : "systeme";
  return { id: n.id, kind, title: n.titre, text: n.texte, date: fmtDate(n.date), read: n.lue, link: n.lien ?? undefined };
}

export function toHistorique(h: HistoriqueApi): HistoriqueEntry {
  return {
    id: h.id,
    action: h.action,
    cible: h.cible,
    auteur: h.auteur,
    categorie: h.categorie,
    date: fmtDateTime(h.date),
  };
}

export function toMessage(m: MessageApi): Message {
  return {
    id: m.id,
    nom: m.nom,
    email: m.email,
    telephone: m.telephone ?? undefined,
    texte: m.message,
    type: m.type,
    clientId: m.profile_id ?? undefined,
    traite: m.traite,
    date: fmtDateTime(m.date),
  };
}

export function toMessageReply(r: MessageReplyApi): MessageReply {
  return { id: r.id, auteur: r.auteur, objet: r.objet, texte: r.texte, date: fmtDateTime(r.date) };
}

export function fullName(c: Pick<Client, "prenom" | "nom">) {
  return `${c.prenom} ${c.nom}`;
}

export function initialsOfName(prenom: string, nom: string) {
  return (prenom[0] ?? "").toUpperCase() + (nom[0] ?? "").toUpperCase();
}
