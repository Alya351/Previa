/**
 * Client de l'API Previa (backend FastAPI, dossier `backend/`).
 * Règles métier : docs/regles-metier.md.
 *
 * L'URL vient de NEXT_PUBLIC_API_URL (par défaut http://localhost:8000 en local).
 */

import { SUPABASE_ENABLED, adminAuth, authMessage, clientAuth, freshToken, siteUrl } from "./supabase";

export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// ── Types ────────────────────────────────────────────────────────────────
export type Role = "user" | "admin";

export type Compte = {
  id: string;
  prenom: string;
  nom: string;
  email: string;
  telephone?: string | null;
  pays?: string | null;
  entreprise?: string | null;
  type_client?: "particulier" | "entreprise";
  role: Role;
  email_verifie?: boolean;
  cree_le?: string | null;
  /** État déduit de l'abonnement (clients) : actif, expire, suspendu, en_attente, termine, sans_abonnement. */
  statut?: string;
};

export type SessionResponse = { compte: Compte; token: string };

export type PlanApi = {
  id: string;
  nom: string;
  /** Prix tout compris de la 1re année (FCFA), payable en 3 tranches ; null = sur devis. */
  prix_particulier: number | null;
  prix_entreprise: number | null;
  /** Abonnement annuel dès l'année 2. */
  prix_renouvellement: number | null;
  payable_en_ligne: boolean;
  cameras_max: number;
  logiciel_seul: boolean;
  options: string[];
  support: string;
  recommande: boolean;
  actif?: boolean;
};

/** Statut effectif d'un abonnement (les statuts « expire » et « expire_bientot » sont dérivés). */
export type SubStatus = "en_attente_code" | "actif" | "expire_bientot" | "expire" | "suspendu" | "termine";

export type Periode = {
  id: string;
  ordre: number;
  plan_id: string;
  plan: string;
  duree_mois: number;
  debut: string | null;
  fin: string | null;
  source: "paiement" | "manuel";
  payment_id: string | null;
};

export type AbonnementApi = {
  id: string;
  reference: string;
  client_id: string;
  plan: PlanApi;
  statut: SubStatus;
  statut_stocke: string;
  debut: string | null;
  fin: string | null;
  cree_le: string;
  destinataire_nom?: string | null;
  destinataire_email?: string | null;
  /** Prix de la 1re année payé en tranches (null pour un abonnement créé à la main). */
  prix_total?: number | null;
  tranches_payees?: number;
  tranches_total?: number | null;
  prochaine_tranche?: { numero: number; montant: number; echeance: string | null } | null;
  /** Somme des tranches restant à payer sur la 1re année. */
  reliquat?: number;
  /** État de la prochaine tranche : à venir, proche (rappel), échue (délai de grâce) ou impayée (suspension). */
  etat_tranche?: "a_venir" | "proche" | "echue" | "impayee" | null;
  suspendu_impaye?: boolean;
  code_genere: boolean;
  code_envoye: boolean;
  code_actif: boolean;
  code_desactive_manuellement: boolean;
  code_envoye_le: string | null;
  periodes?: Periode[];
  client?: ClientBrief;
};

export type PaiementApi = {
  id: string;
  reference: string;
  plan_id: string;
  duree_mois: number;
  /** 1..3 pour une tranche de la 1re année ; null pour un renouvellement annuel. */
  tranche?: number | null;
  tranches_total?: number | null;
  moyen: "carte" | "mobile_money";
  operateur: string | null;
  carte_marque: string | null;
  carte_last4: string | null;
  montant: number;
  devise: string;
  statut: "reussi" | "echoue";
  date: string;
};

export type PaiementInput = {
  moyen: "carte" | "mobile_money";
  operateur?: string;
  telephone?: string;
  carte_numero?: string;
};

export type NotificationApi = {
  id: string;
  type: string;
  titre: string;
  texte: string;
  lien: string | null;
  lue: boolean;
  date: string;
};

export type ClientBrief = { id: string; nom: string; prenom: string; email: string; telephone?: string | null };

export type ClientApi = Compte & { abonnement?: AbonnementApi | null };

export type DemandeApi = {
  id: string;
  reference: string;
  client: ClientBrief;
  date: string;
  formule: string;
  statut_abonnement: SubStatus;
  code_genere: boolean;
  code_envoye: boolean;
  code_actif: boolean;
  code_desactive_manuellement: boolean;
  code_envoye_le: string | null;
  abonnement?: AbonnementApi;
  duree_mois?: number | null;
  premier_envoi?: boolean;
};

export type Page<T> = { items: T[]; total: number; page: number; limit: number };

export type DashboardApi = {
  total_clients: number;
  clients_actifs: number;
  demandes_sans_code: number;
  abonnements_actifs: number;
  expirent_bientot: number;
  codes_envoyes: number;
  indicateurs: { clients_actifs_pct: number; codes_envoyes_pct: number; abonnements_actifs_pct: number };
  activite_recente: { id: string; client: string; date: string; code_genere: boolean; code_envoye: boolean }[];
};

export type HistoriqueApi = {
  id: string;
  action: string;
  cible: string;
  auteur: string;
  categorie: "clients" | "demandes" | "codes" | "abonnements" | "compte" | "messages";
  date: string;
};

export type MessageApi = {
  id: string;
  nom: string;
  email: string;
  telephone: string | null;
  message: string;
  type: "message" | "devis";
  /** Compte client rattaché (devis uniquement) ; permet de rejoindre sa fiche. */
  profile_id: string | null;
  traite: boolean;
  date: string;
};

export type MessageReplyApi = {
  id: string;
  auteur: string;
  objet: string;
  texte: string;
  date: string;
};

export class ApiError extends Error {
  status: number;
  data?: unknown;
  /** Secondes à attendre avant de réessayer (en-tête Retry-After : verrouillage OTP, limites de débit). */
  retryAfter?: number;

  constructor(message: string, status: number, data?: unknown, retryAfter?: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
    this.retryAfter = retryAfter;
  }
}

// ── Transport ────────────────────────────────────────────────────────────
type Options = {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  token?: string | null;
  body?: unknown;
  headers?: Record<string, string>;
};

async function request<T>(endpoint: string, { method = "GET", token, body, headers }: Options = {}): Promise<T> {
  const h: Record<string, string> = { ...(headers ?? {}) };
  if (body !== undefined) h["Content-Type"] = "application/json";
  let bearer = token;
  if (token && SUPABASE_ENABLED) {
    bearer = (await freshToken(endpoint.startsWith("/api/v1/admin") ? "admin" : "client")) ?? token;
  }
  if (bearer) h["Authorization"] = `Bearer ${bearer}`;

  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}${endpoint}`, {
      method,
      headers: h,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (err) {
    throw new ApiError(
      "Impossible de joindre le serveur. Si le serveur Render était en veille, veuillez patienter quelques secondes et réessayer.",
      0,
      err
    );
  }

  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!res.ok) {
    let msg = "Une erreur est survenue";
    if (data && typeof data === "object" && "detail" in data) {
      const d = (data as { detail: unknown }).detail;
      if (typeof d === "string") msg = d;
      else if (Array.isArray(d) && d[0]?.msg) msg = d[0].msg;
    }
    if (res.status === 404 && msg === "Une erreur est survenue") msg = "Ressource introuvable.";
    const retry = Number(res.headers.get("Retry-After"));
    throw new ApiError(msg, res.status, data, Number.isFinite(retry) && retry > 0 ? retry : undefined);
  }
  return data as T;
}

const qs = (params: Record<string, string | number | undefined | null>) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : "";
};

// Le backend renvoie les rôles « utilisateur » / « superadmin » ; le site utilise « user » / « admin ».
type RawCompte = Omit<Compte, "role"> & { role: string };
const toCompte = (c: RawCompte): Compte => ({ ...c, role: c.role === "superadmin" ? "admin" : "user" });
type RawSession = { user: RawCompte; accessToken: string };
const toSession = (s: RawSession): SessionResponse => ({ compte: toCompte(s.user), token: s.accessToken });

// ── Supabase Auth : connexion et changement de mot de passe ──────────────
async function sbLogin(scope: "client" | "admin", email: string, password: string): Promise<SessionResponse> {
  const sb = scope === "admin" ? adminAuth() : clientAuth();
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw new ApiError(authMessage(error), error.status ?? 401);
  const token = data.session.access_token;
  try {
    const compte = scope === "admin" ? await api.admin.getMe(token) : await api.auth.getMe(token);
    if (compte.role !== (scope === "admin" ? "admin" : "user")) throw new ApiError("Email ou mot de passe incorrect.", 401);
    return { compte, token };
  } catch (err) {
    await sb.auth.signOut(); // rôle incorrect, compte supprimé ou API injoignable : pas de session à moitié ouverte
    if (err instanceof ApiError && err.status === 0) throw err;
    if (err instanceof ApiError && err.status >= 500) throw err;
    throw new ApiError("Email ou mot de passe incorrect.", 401);
  }
}

async function sbChangePassword(scope: "client" | "admin", current: string, next: string) {
  const sb = scope === "admin" ? adminAuth() : clientAuth();
  const { data } = await sb.auth.getSession();
  const email = data.session?.user.email;
  if (!email) throw new ApiError("Session expirée. Veuillez vous reconnecter.", 401);
  const check = await sb.auth.signInWithPassword({ email, password: current });
  if (check.error) throw new ApiError("Mot de passe actuel incorrect.", 400);
  const { error } = await sb.auth.updateUser({ password: next });
  if (error) throw new ApiError(authMessage(error), error.status ?? 400);
  const fresh = (await sb.auth.getSession()).data.session;
  return { ok: true, accessToken: fresh?.access_token ?? "" };
}

// ── API ──────────────────────────────────────────────────────────────────
export const api = {
  plans: () => request<PlanApi[]>("/api/v1/plans"),

  contact: (data: { nom: string; email: string; telephone?: string; message: string }) =>
    request<{ ok: boolean }>("/api/v1/contact", { method: "POST", body: data }),

  auth: {
    async login(email: string, mot_de_passe: string) {
      if (SUPABASE_ENABLED) return sbLogin("client", email, mot_de_passe);
      return toSession(await request<RawSession>("/api/v1/auth/login", { method: "POST", body: { email, mot_de_passe } }));
    },
    async register(p: {
      prenom: string;
      nom: string;
      email: string;
      mot_de_passe: string;
      telephone?: string;
      pays?: string;
      type_client?: "particulier" | "entreprise";
      entreprise?: string;
      consentement: boolean;
    }): Promise<SessionResponse | { pendingEmail: string }> {
      if (SUPABASE_ENABLED) {
        const { data, error } = await clientAuth().auth.signUp({
          email: p.email,
          password: p.mot_de_passe,
          options: {
            emailRedirectTo: `${siteUrl()}/connexion`,
            data: {
              prenom: p.prenom,
              nom: p.nom,
              telephone: p.telephone,
              pays: p.pays,
              type_client: p.type_client,
              entreprise: p.entreprise,
              consentement: p.consentement,
            },
          },
        });
        if (error) throw new ApiError(authMessage(error), error.status ?? 400);
        // Adresse déjà utilisée : Supabase renvoie un utilisateur sans identité.
        if (data.user && (data.user.identities?.length ?? 0) === 0) {
          throw new ApiError("Un compte existe déjà avec cette adresse e-mail.", 409);
        }
        if (!data.session) return { pendingEmail: p.email }; // « Confirm email » actif : lien à ouvrir
        const compte = await api.auth.getMe(data.session.access_token);
        return { compte, token: data.session.access_token };
      }
      return toSession(await request<RawSession>("/api/v1/auth/register", { method: "POST", body: p }));
    },
    /** Connexion via Google : la page est quittée puis retrouvée (cf. lib/auth.ts). */
    async oauth(provider: "google") {
      if (!SUPABASE_ENABLED) throw new ApiError("Cette connexion n'est pas encore disponible.", 501);
      try {
        window.localStorage.setItem("previa_oauth_pending", String(Date.now()));
      } catch {}
      const { error } = await clientAuth().auth.signInWithOAuth({
        provider,
        options: { redirectTo: `${siteUrl()}/connexion` },
      });
      if (error) throw new ApiError(authMessage(error), error.status ?? 400);
    },
    async getMe(token: string) {
      return toCompte(await request<RawCompte>("/api/v1/me", { token }));
    },
    async logout(token: string) {
      if (SUPABASE_ENABLED) {
        await clientAuth().auth.signOut();
        return { ok: true };
      }
      return request<{ ok: boolean }>("/api/v1/auth/logout", { method: "POST", token });
    },
    verifyEmail: (t: string) =>
      request<{ ok: boolean }>("/api/v1/auth/verify-email", { method: "POST", body: { token: t } }),
    async resendVerification(token: string) {
      // La confirmation d'e-mail (exigée au paiement) est gérée par notre API, y compris avec Supabase.
      return request<{ ok: boolean }>("/api/v1/auth/resend-verification", { method: "POST", token });
    },
    async forgotPassword(email: string) {
      if (SUPABASE_ENABLED) {
        // Réponse volontairement identique que l'adresse existe ou non.
        await clientAuth().auth.resetPasswordForEmail(email, { redirectTo: `${siteUrl()}/connexion` });
        return { ok: true };
      }
      return request<{ ok: boolean }>("/api/v1/auth/forgot-password", { method: "POST", body: { email } });
    },
    async resetPassword(t: string, mot_de_passe: string) {
      if (SUPABASE_ENABLED) {
        // La session « récupération » ouverte par le lien e-mail autorise le changement.
        const sb = clientAuth();
        const { error } = await sb.auth.updateUser({ password: mot_de_passe });
        if (error) throw new ApiError(authMessage(error), error.status ?? 400);
        await sb.auth.signOut();
        return { ok: true };
      }
      return request<{ ok: boolean }>("/api/v1/auth/reset-password", { method: "POST", body: { token: t, mot_de_passe } });
    },
  },

  me: {
    async updateProfile(
      token: string,
      data: { prenom?: string; nom?: string; entreprise?: string; telephone?: string }
    ) {
      return toCompte(await request<RawCompte>("/api/v1/me", { method: "PUT", token, body: data }));
    },
    async changePassword(token: string, current_password: string, new_password: string) {
      if (SUPABASE_ENABLED) return sbChangePassword("client", current_password, new_password);
      return request<{ ok: boolean; accessToken: string }>("/api/v1/me/password", {
        method: "PUT",
        token,
        body: { current_password, new_password },
      });
    },
    getSubscription: (token: string) =>
      request<{ abonnement: AbonnementApi | null; peut_souscrire: boolean; peut_renouveler: boolean }>(
        "/api/v1/me/subscription",
        { token }
      ),
    checkout: (
      token: string,
      data: {
        plan_id: string;
        paiement: PaiementInput;
        destinataire_nom?: string;
        destinataire_email?: string;
        type_client?: "particulier" | "entreprise";
        entreprise?: string;
      }
    ) =>
      request<{ abonnement: AbonnementApi; paiement: PaiementApi }>("/api/v1/me/subscription", {
        method: "POST",
        token,
        body: data,
      }),
    payInstallment: (token: string, data: { paiement: PaiementInput; solde?: boolean }) =>
      request<{ abonnement: AbonnementApi; paiement: PaiementApi }>("/api/v1/me/subscription/installment", {
        method: "POST",
        token,
        body: data,
      }),
    renew: (token: string, data: { paiement: PaiementInput; plan_id?: string; solder_reliquat?: boolean }) =>
      request<{ abonnement: AbonnementApi; paiement: PaiementApi }>("/api/v1/me/subscription/renew", {
        method: "POST",
        token,
        body: data,
      }),
    payments: (token: string) => request<PaiementApi[]>("/api/v1/me/payments", { token }),
    sendOtp: (token: string) =>
      request<{ expire_le: string; expire_dans_secondes: number }>("/api/v1/me/code/otp", { method: "POST", token }),
    verifyOtp: (token: string, otp: string) =>
      request<{ read_token: string; expire_le: string }>("/api/v1/me/code/otp/verify", {
        method: "POST",
        token,
        body: { otp },
      }),
    getCode: (token: string, readToken: string) =>
      request<{ code: string; abonnement: AbonnementApi; reference: string; cameras_max: number; expire_le: string | null }>(
        "/api/v1/me/code",
        { token, headers: { "X-Code-Token": readToken } }
      ),
    quote: (token: string, data: { plan_id?: string; message?: string; telephone?: string }) =>
      request<{ ok: boolean }>("/api/v1/me/quote", { method: "POST", token, body: data }),
    notifications: (token: string) =>
      request<{ notifications: NotificationApi[]; non_lues: number }>("/api/v1/me/notifications", { token }),
    readAllNotifications: (token: string) =>
      request<{ ok: boolean }>("/api/v1/me/notifications/read-all", { method: "POST", token }),
    readNotification: (token: string, id: string) =>
      request<{ ok: boolean }>(`/api/v1/me/notifications/${id}/read`, { method: "POST", token }),
  },

  admin: {
    async login(email: string, mot_de_passe: string) {
      if (SUPABASE_ENABLED) return sbLogin("admin", email, mot_de_passe);
      return toSession(
        await request<RawSession>("/api/v1/admin/auth/login", { method: "POST", body: { email, mot_de_passe } })
      );
    },
    async getMe(token: string) {
      return toCompte(await request<RawCompte>("/api/v1/admin/auth/me", { token }));
    },
    async updateMe(token: string, data: { prenom?: string; nom?: string }) {
      return toCompte(await request<RawCompte>("/api/v1/admin/auth/me", { method: "PUT", token, body: data }));
    },
    async changePassword(token: string, current_password: string, new_password: string) {
      if (SUPABASE_ENABLED) return sbChangePassword("admin", current_password, new_password);
      return request<{ ok: boolean; accessToken: string }>("/api/v1/admin/auth/password", {
        method: "PUT",
        token,
        body: { current_password, new_password },
      });
    },
    async comptes(token: string) {
      return (await request<RawCompte[]>("/api/v1/admin/comptes", { token })).map(toCompte);
    },
    async createAdmin(
      token: string,
      data: { prenom: string; nom: string; email: string; mot_de_passe: string }
    ) {
      return toCompte(await request<RawCompte>("/api/v1/admin/comptes", { method: "POST", token, body: data }));
    },
    dashboard: (token: string) => request<DashboardApi>("/api/v1/admin/dashboard", { token }),
    growth: (token: string, range: string, points = 7) =>
      request<{ range: string; points: { date: string; clients: number }[] }>(
        `/api/v1/admin/dashboard/growth${qs({ range, points })}`,
        { token }
      ),

    clients: (token: string, search = "") =>
      request<Page<ClientApi>>(`/api/v1/admin/clients${qs({ search, limit: 500 })}`, { token }),
    client: (token: string, id: string) => request<ClientApi>(`/api/v1/admin/clients/${id}`, { token }),
    updateClient: (
      token: string,
      id: string,
      data: { prenom?: string; nom?: string; email?: string; telephone?: string; entreprise?: string }
    ) => request<ClientApi>(`/api/v1/admin/clients/${id}`, { method: "PUT", token, body: data }),
    deleteClient: (token: string, id: string) =>
      request<{ ok: boolean }>(`/api/v1/admin/clients/${id}`, { method: "DELETE", token }),
    createSubscription: (token: string, clientId: string, data: { plan_id: string; duree_mois: number }) =>
      request<AbonnementApi>(`/api/v1/admin/clients/${clientId}/abonnements`, { method: "POST", token, body: data }),

    demandes: (token: string) => request<Page<DemandeApi>>("/api/v1/admin/demandes?limit=500", { token }),
    demande: (token: string, id: string) => request<DemandeApi>(`/api/v1/admin/demandes/${id}`, { token }),
    generateCode: (token: string, id: string) =>
      request<DemandeApi>(`/api/v1/admin/demandes/${id}/code`, { method: "POST", token }),
    sendCode: (token: string, id: string) =>
      request<DemandeApi>(`/api/v1/admin/demandes/${id}/envoyer`, { method: "POST", token }),
    revealCode: (token: string, id: string) =>
      request<{ code: string; expire_le: string | null }>(`/api/v1/admin/demandes/${id}/code`, { token }),
    toggleCode: (token: string, id: string, active: boolean) =>
      request<DemandeApi>(`/api/v1/admin/demandes/${id}/code/actif`, { method: "POST", token, body: { active } }),

    abonnements: (token: string) => request<Page<AbonnementApi>>("/api/v1/admin/abonnements?limit=500", { token }),
    abonnement: (token: string, id: string) => request<AbonnementApi>(`/api/v1/admin/abonnements/${id}`, { token }),
    prolonger: (token: string, id: string, mois: number) =>
      request<AbonnementApi>(`/api/v1/admin/abonnements/${id}/prolonger`, { method: "POST", token, body: { mois } }),
    suspendre: (token: string, id: string) =>
      request<AbonnementApi>(`/api/v1/admin/abonnements/${id}/suspendre`, { method: "POST", token }),
    reactiver: (token: string, id: string) =>
      request<AbonnementApi>(`/api/v1/admin/abonnements/${id}/reactiver`, { method: "POST", token }),
    terminer: (token: string, id: string) =>
      request<AbonnementApi>(`/api/v1/admin/abonnements/${id}/terminer`, { method: "POST", token }),

    notifications: (token: string) =>
      request<{ notifications: NotificationApi[]; non_lues: number }>("/api/v1/admin/notifications", { token }),
    readAllNotifications: (token: string) =>
      request<{ ok: boolean }>("/api/v1/admin/notifications/read-all", { method: "POST", token }),
    historique: (token: string) =>
      request<Page<HistoriqueApi>>("/api/v1/admin/historique?limit=500", { token }),
    messages: (token: string, traite?: boolean) =>
      request<MessageApi[]>(`/api/v1/admin/messages${qs({ traite: traite === undefined ? undefined : String(traite) })}`, {
        token,
      }),
    setMessageTraite: (token: string, id: string, traite: boolean) =>
      request<MessageApi>(`/api/v1/admin/messages/${id}/traite`, { method: "POST", token, body: { traite } }),
    /** Réponse envoyée par e-mail (pas de messagerie in-app) ; marque le message comme traité. */
    replyMessage: (token: string, id: string, texte: string, objet?: string) =>
      request<MessageApi>(`/api/v1/admin/messages/${id}/repondre`, { method: "POST", token, body: { texte, objet } }),
    messageReplies: (token: string, id: string) =>
      request<MessageReplyApi[]>(`/api/v1/admin/messages/${id}/reponses`, { token }),
    plans: (token: string) => request<PlanApi[]>("/api/v1/admin/plans", { token }),
    updatePlan: (
      token: string,
      id: string,
      data: {
        prix_particulier: number | null;
        prix_entreprise: number | null;
        prix_renouvellement: number | null;
        cameras_max: number;
        payable_en_ligne: boolean;
        actif: boolean;
      }
    ) => request<PlanApi>(`/api/v1/admin/plans/${id}`, { method: "PUT", token, body: data }),
  },
};
