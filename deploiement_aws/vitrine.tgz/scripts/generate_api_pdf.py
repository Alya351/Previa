import os
import sys
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    PageBreak,
    KeepTogether,
    HRFlowable
)
from reportlab.pdfgen import canvas

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, page_count):
        if self._pageNumber == 1:
            return  # Première page (couverture) sans en-tête / pied

        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748B"))

        # En-tête
        self.setStrokeColor(colors.HexColor("#CBD5E1"))
        self.setLineWidth(0.6)
        self.line(36, 805, 559, 805)
        self.drawString(36, 810, "PREVIA • Spécification Technique des APIs REST Backend")
        self.drawRightString(559, 810, "Référentiel Architecture v1.0")

        # Pied de page
        self.line(36, 42, 559, 42)
        self.drawString(36, 31, "Previa — Système Intelligent de Sécurité & Amorçage Client")
        page_str = f"Page {self._pageNumber} sur {page_count}"
        self.drawRightString(559, 31, page_str)

        self.restoreState()


def build_pdf(filename="Previa_Specifications_APIs_Backend.pdf"):
    doc = SimpleDocTemplate(
        filename,
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=50,
        bottomMargin=50
    )

    styles = getSampleStyleSheet()

    # Couleurs
    C_PRIMARY = colors.HexColor("#0F172A")    # Slate 900
    C_SECONDARY = colors.HexColor("#1E293B")  # Slate 800
    C_ACCENT = colors.HexColor("#2563EB")     # Blue 600
    C_TEAL = colors.HexColor("#0D9488")       # Teal 600
    C_TEXT = colors.HexColor("#334155")       # Slate 700
    C_MUTED = colors.HexColor("#64748B")      # Slate 500
    C_LIGHT_BG = colors.HexColor("#F8FAFC")   # Slate 50
    C_BORDER = colors.HexColor("#E2E8F0")     # Slate 200

    # Badges HTTP
    C_GET = colors.HexColor("#0284C7")
    C_POST = colors.HexColor("#16A34A")
    C_PUT = colors.HexColor("#D97706")
    C_PATCH = colors.HexColor("#EA580C")
    C_DELETE = colors.HexColor("#DC2626")

    # Custom styles
    title_style = ParagraphStyle(
        'CoverTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=28,
        leading=34,
        textColor=C_PRIMARY,
        alignment=0
    )

    subtitle_style = ParagraphStyle(
        'CoverSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=13,
        leading=18,
        textColor=C_ACCENT,
        alignment=0
    )

    h1_style = ParagraphStyle(
        'Heading1_Custom',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=16,
        leading=21,
        textColor=C_PRIMARY,
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )

    h2_style = ParagraphStyle(
        'Heading2_Custom',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=C_SECONDARY,
        spaceBefore=10,
        spaceAfter=5,
        keepWithNext=True
    )

    body_style = ParagraphStyle(
        'Body_Custom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12,
        textColor=C_TEXT
    )

    body_bold = ParagraphStyle(
        'Body_Bold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.5,
        leading=12,
        textColor=C_PRIMARY
    )

    code_style = ParagraphStyle(
        'Code_Custom',
        parent=styles['Normal'],
        fontName='Courier',
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor("#0F172A")
    )

    table_header_style = ParagraphStyle(
        'TableHeader',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=colors.white
    )

    meta_key = ParagraphStyle(
        'MetaKey',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9,
        leading=13,
        textColor=C_PRIMARY
    )

    meta_val = ParagraphStyle(
        'MetaVal',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=C_TEXT
    )

    story = []

    # ==========================================
    # PAGE 1 : COUVERTURE PROFESSIONNELLE
    # ==========================================
    story.append(Spacer(1, 35))
    
    # Tag de document
    tag_table = Table([[
        Paragraph('<font color="#2563EB"><b>CAHIER DE SPÉCIFICATIONS TECHNIQUES • BACKEND REST API</b></font>', body_style)
    ]], colWidths=[523])
    tag_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#EFF6FF")),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#BFDBFE")),
        ('PADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(tag_table)
    story.append(Spacer(1, 20))

    story.append(Paragraph("PREVIA PLATFORM", title_style))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Catalogue Exhaustif des Endpoints d'API & Architecture Backend", subtitle_style))
    story.append(Spacer(1, 15))

    story.append(Paragraph(
        "Ce document de référence est destiné à l'équipe de développement backend. Il formalise l'intégralité des routes API nécessaires au fonctionnement optimal du portail web Previa, de l'espace client sécurisé (gestion des abonnements, paiements Mobile Money/Carte et codes d'amorçage) et du tableau de bord d'administration (Superadministrateur).",
        body_style
    ))
    story.append(Spacer(1, 25))

    # Fiche d'identification du projet
    metadata_data = [
        [Paragraph("Application", meta_key), Paragraph("PREVIA — Surveillance Intelligente & Code d'Amorçage", meta_val)],
        [Paragraph("Destinataire", meta_key), Paragraph("Équipe d'ingénierie logicielle Backend (Node.js / Python / Go)", meta_val)],
        [Paragraph("Périmètre fonctionnel", meta_key), Paragraph("1. Visiteurs (Public) • 2. Utilisateurs Connectés (Clients) • 3. Superadministrateur", meta_val)],
        [Paragraph("Protocole standard", meta_key), Paragraph("REST over HTTPS • JSON UTF-8 • Authentification JWT / Bearer", meta_val)],
        [Paragraph("Version du document", meta_key), Paragraph("1.0.0 — Production-Ready", meta_val)],
        [Paragraph("Date de révision", meta_key), Paragraph("Septembre 2026", meta_val)],
        [Paragraph("Statut", meta_key), Paragraph('<font color="#16A34A"><b>VALIDÉ POUR IMPLÉMENTATION</b></font>', meta_val)],
    ]
    meta_table = Table(metadata_data, colWidths=[140, 383])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), C_LIGHT_BG),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 30))

    # Résumé des volumes d'API
    kpi_data = [
        [
            Paragraph('<para align="center"><b>PUBLIC (VISITEUR)</b><br/><font size="16" color="#0284C7"><b>14</b></font><br/>Endpoints</para>', body_style),
            Paragraph('<para align="center"><b>ESPACE CLIENT</b><br/><font size="16" color="#16A34A"><b>22</b></font><br/>Endpoints</para>', body_style),
            Paragraph('<para align="center"><b>SUPERADMINISTRATEUR</b><br/><font size="16" color="#D97706"><b>35</b></font><br/>Endpoints</para>', body_style),
            Paragraph('<para align="center"><b>TOTAL GÉNÉRAL</b><br/><font size="16" color="#2563EB"><b>71</b></font><br/>Routes API</para>', body_style),
        ]
    ]
    kpi_table = Table(kpi_data, colWidths=[130, 131, 131, 131])
    kpi_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.white),
        ('BOX', (0,0), (-1,-1), 1, C_BORDER),
        ('INNERGRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('TOPPADDING', (0,0), (-1,-1), 10),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(kpi_table)

    story.append(PageBreak())

    # ==========================================
    # PAGE 2 : SOMMAIRE & ARCHITECTURE GÉNÉRALE
    # ==========================================
    story.append(Paragraph("1. Principes d'Architecture & Normes Backend", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_ACCENT, spaceAfter=8))
    
    arch_intro = (
        "L'ensemble des APIs est exposé sous le préfixe standard <b><code>/api/v1</code></b>. "
        "Toutes les communications doivent s'effectuer via <b>TLS 1.3</b>. "
        "Les charges utiles (payloads) de requête et de réponse sont strictement encodées en <b>application/json; charset=utf-8</b>."
    )
    story.append(Paragraph(arch_intro, body_style))
    story.append(Spacer(1, 8))

    story.append(Paragraph("1.1. Format Standardisé des Réponses JSON", h2_style))
    
    json_format_text = (
        "Toutes les réponses de l'API doivent respecter une structure enveloppe prévisible, "
        "facilitant la désérialisation côté frontend et la gestion des erreurs réseau :"
    )
    story.append(Paragraph(json_format_text, body_style))
    story.append(Spacer(1, 4))

    code_payload = [
        [
            Paragraph("<b>Format de Succès (HTTP 200/201) :</b>", meta_key),
            Paragraph("<b>Format d'Erreur (HTTP 4xx/5xx) :</b>", meta_key)
        ],
        [
            Paragraph(
                "{\n"
                '  "success": true,\n'
                '  "data": { ... },\n'
                '  "meta": {\n'
                '    "timestamp": "2026-09-14T12:00:00Z",\n'
                '    "pagination": { "page": 1, "limit": 20, "total": 85 }\n'
                '  }\n'
                "}", code_style
            ),
            Paragraph(
                "{\n"
                '  "success": false,\n'
                '  "error": {\n'
                '    "code": "INVALID_CREDENTIALS",\n'
                '    "message": "Identifiants invalides",\n'
                '    "details": [{ "field": "email", "issue": "Format non valide" }]\n'
                '  }\n'
                "}", code_style
            )
        ]
    ]
    code_table = Table(code_payload, colWidths=[260, 263])
    code_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), C_LIGHT_BG),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(code_table)
    story.append(Spacer(1, 10))

    story.append(Paragraph("1.2. Codes de Statut HTTP Utilisés", h2_style))
    http_codes = [
        [Paragraph("Code", table_header_style), Paragraph("Signification", table_header_style), Paragraph("Usage dans Previa", table_header_style)],
        [Paragraph("<b>200 OK</b>", code_style), Paragraph("Succès standard", body_style), Paragraph("Consultation de profil, abonnements, clients, stats", body_style)],
        [Paragraph("<b>201 Created</b>", code_style), Paragraph("Ressource créée", body_style), Paragraph("Inscription, demande d'amorçage, génération de code", body_style)],
        [Paragraph("<b>204 No Content</b>", code_style), Paragraph("Succès sans corps", body_style), Paragraph("Suppression d'un compte, déconnexion", body_style)],
        [Paragraph("<b>400 Bad Request</b>", code_style), Paragraph("Données invalides", body_style), Paragraph("Payload JSON malformé ou champ manquant", body_style)],
        [Paragraph("<b>401 Unauthorized</b>", code_style), Paragraph("Non authentifié", body_style), Paragraph("JWT absent, expiré ou invalide", body_style)],
        [Paragraph("<b>403 Forbidden</b>", code_style), Paragraph("Accès refusé", body_style), Paragraph("Client tentant d'accéder aux routes <code>/admin/</code>", body_style)],
        [Paragraph("<b>404 Not Found</b>", code_style), Paragraph("Non trouvé", body_style), Paragraph("Client, demande ou abonnement inexistant", body_style)],
        [Paragraph("<b>409 Conflict</b>", code_style), Paragraph("Conflit de ressource", body_style), Paragraph("Email déjà enregistré, demande déjà validée", body_style)],
        [Paragraph("<b>422 Unprocessable</b>", code_style), Paragraph("Erreur métier", body_style), Paragraph("Code OTP erroné, montant paiement non concordant", body_style)],
        [Paragraph("<b>500 Internal Error</b>", code_style), Paragraph("Erreur serveur", body_style), Paragraph("Panne passerelle Mobile Money, incident BD", body_style)],
    ]
    t_http = Table(http_codes, colWidths=[80, 110, 333])
    t_http.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_PRIMARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(t_http)
    story.append(Spacer(1, 10))

    story.append(Paragraph("1.3. Matrice des Rôles & Niveaux d'Accès", h2_style))
    matrix_data = [
        [Paragraph("Rôle / Profil", table_header_style), Paragraph("Description", table_header_style), Paragraph("Mode d'Authentification", table_header_style), Paragraph("Permissions Clés", table_header_style)],
        [
            Paragraph("<b>VISITEUR</b><br/>(Public)", body_style),
            Paragraph("Tout internaute consultant le site vitrine Previa.", body_style),
            Paragraph("Aucune authentification requise.", body_style),
            Paragraph("Lecture offres, solution, téléchargement logiciel, contact, inscription, connexion.", body_style)
        ],
        [
            Paragraph("<b>CLIENT</b><br/>(Utilisateur connecté)", body_style),
            Paragraph("Client propriétaire d'un compte validé.", body_style),
            Paragraph("JWT Bearer Token (durée 15min) + Refresh Token HTTP-only (7j).", body_style),
            Paragraph("Achat abonnement, paiement Mobile Money, soumission demande, validation OTP, obtention code d'amorçage.", body_style)
        ],
        [
            Paragraph("<b>SUPERADMIN</b><br/>(Back-office Prevadm)", body_style),
            Paragraph("Administrateur habilité de la plateforme Previa.", body_style),
            Paragraph("JWT strict avec rôle <code>SUPERADMIN</code> + 2FA (TOTP/SMS).", body_style),
            Paragraph("Validation/refus des demandes, génération de code, gestion complète des clients, abonnements, historique d'audit.", body_style)
        ],
    ]
    t_mat = Table(matrix_data, colWidths=[85, 130, 135, 173])
    t_mat.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_SECONDARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(t_mat)

    story.append(PageBreak())

    # ==========================================
    # SECTION 2 : APIS VISITEUR (PUBLIC)
    # ==========================================
    story.append(Paragraph("2. APIs pour le Profil VISITEUR (Public / Non Connecté)", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_GET, spaceAfter=8))
    story.append(Paragraph(
        "Ces endpoints sont accessibles sans jeton d'authentification. Ils alimentent la page d'accueil, la page de présentation de la solution, les pages de téléchargement, le formulaire de contact ainsi que le parcours de création et d'accès au compte.",
        body_style
    ))
    story.append(Spacer(1, 8))

    def make_method_badge(method):
        c = C_GET
        if method == "POST": c = C_POST
        elif method == "PUT": c = C_PUT
        elif method == "PATCH": c = C_PATCH
        elif method == "DELETE": c = C_DELETE
        return f'<font color="{c.hexval()}"><b>{method}</b></font>'

    api_visitor = [
        [Paragraph("Méthode & Route", table_header_style), Paragraph("Description Métier", table_header_style), Paragraph("Paramètres / Body Requête", table_header_style), Paragraph("Réponse attendue", table_header_style)],
        
        # Auth
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/auth/register</code>", body_style),
            Paragraph("Création d'un nouveau compte client depuis le formulaire.", body_style),
            Paragraph("<b>Body:</b> <code>{ nom, email, password, confirmPassword, acceptTerms }</code>", body_style),
            Paragraph("<b>201:</b> <code>{ user, accessToken, refreshToken }</code><br/><b>409:</b> Email déjà existant", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/auth/login</code>", body_style),
            Paragraph("Connexion client avec adresse email et mot de passe.", body_style),
            Paragraph("<b>Body:</b> <code>{ email, password }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ user: { id, nom, email }, accessToken }</code><br/><b>401:</b> Identifiants erronés", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/auth/social-login</code>", body_style),
            Paragraph("Authentification fédérée via fournisseur tiers (Google, Microsoft).", body_style),
            Paragraph("<b>Body:</b> <code>{ provider: 'google'|'microsoft', idToken }</code>", body_style),
            Paragraph("<b>200:</b> Session client ouverte + tokens JWT", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/auth/forgot-password</code>", body_style),
            Paragraph("Demande de lien de réinitialisation de mot de passe par email.", body_style),
            Paragraph("<b>Body:</b> <code>{ email }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ message: 'Email envoyé si le compte existe' }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/auth/reset-password</code>", body_style),
            Paragraph("Application du nouveau mot de passe avec le token reçu par email.", body_style),
            Paragraph("<b>Body:</b> <code>{ token, newPassword, confirmPassword }</code>", body_style),
            Paragraph("<b>200:</b> Mot de passe modifié avec succès<br/><b>400:</b> Token expiré ou invalide", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/auth/refresh-token</code>", body_style),
            Paragraph("Rafraîchissement automatique de l'Access Token JWT expiré.", body_style),
            Paragraph("<b>Cookie/Body:</b> <code>{ refreshToken }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ accessToken: '...' }</code>", body_style)
        ],

        # Catalogue & Solution
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/plans</code>", body_style),
            Paragraph("Retourne le catalogue public des offres d'abonnement Previa.", body_style),
            Paragraph("<i>Aucun paramètre</i>", body_style),
            Paragraph("<b>200:</b> <code>[ { id, name, price, period, cameras, features, support, recommended } ]</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/solution/features</code>", body_style),
            Paragraph("Modules d'intelligence artificielle et fonctionnalités présentées.", body_style),
            Paragraph("<i>Facultatif:</i> <code>?lang=fr|en</code>", body_style),
            Paragraph("<b>200:</b> Liste des modules (détection intrusions, analyse comportementale, vision nocturne)", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/domains</code>", body_style),
            Paragraph("Liste des cas d'usage et secteurs d'activité couverts.", body_style),
            Paragraph("<i>Aucun paramètre</i>", body_style),
            Paragraph("<b>200:</b> Banques, Entrepôts, Boutiques, Domiciles, Chantiers avec métadonnées", body_style)
        ],

        # Téléchargements
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/downloads/latest</code>", body_style),
            Paragraph("Versions officielles disponibles pour chaque système d'exploitation.", body_style),
            Paragraph("<i>Facultatif:</i> <code>?channel=stable|beta</code>", body_style),
            Paragraph("<b>200:</b> <code>{ windows: { version, url, size, sha256 }, android: {...}, ios: {...} }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/downloads/:platform</code>", body_style),
            Paragraph("Téléchargement direct du paquet logiciel ou redirection CDN signée.", body_style),
            Paragraph("<b>Path:</b> <code>platform = 'windows' | 'android' | 'ios'</code>", body_style),
            Paragraph("<b>302 Redirect:</b> URL signée S3/CloudFront ou flux binaire (Content-Disposition)", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/downloads/track</code>", body_style),
            Paragraph("Comptabilisation anonyme des téléchargements réussis.", body_style),
            Paragraph("<b>Body:</b> <code>{ platform, version, userAgent }</code>", body_style),
            Paragraph("<b>204 No Content</b>", body_style)
        ],

        # Contact & FAQ
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/contact</code>", body_style),
            Paragraph("Soumission du formulaire de contact public / demande de devis.", body_style),
            Paragraph("<b>Body:</b> <code>{ name, email, subject, message }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ success: true, ticketNumber: 'TK-8492' }</code><br/>Envoi d'un email d'accusé", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/faq</code>", body_style),
            Paragraph("Base de connaissances et réponses aux questions fréquentes.", body_style),
            Paragraph("<i>Query:</i> <code>?category=amorcage|technique|prix</code>", body_style),
            Paragraph("<b>200:</b> <code>[ { question, answer, category } ]</code>", body_style)
        ],
    ]

    t_vis = Table(api_visitor, colWidths=[110, 130, 145, 138], repeatRows=1)
    t_vis.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_PRIMARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 4),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t_vis)

    story.append(PageBreak())

    # ==========================================
    # SECTION 3 : APIS UTILISATEUR CONNECTÉ (CLIENT)
    # ==========================================
    story.append(Paragraph("3. APIs pour l'UTILISATEUR CONNECTÉ (Espace Client Previa)", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_POST, spaceAfter=8))
    story.append(Paragraph(
        "Tous ces endpoints nécessitent l'en-tête HTTP <b><code>Authorization: Bearer &lt;access_token&gt;</code></b>. "
        "Ils gèrent l'ensemble du cycle de vie client : sélection du forfait, paiement Mobile Money ou Carte, suivi de la demande, vérification OTP à 6 chiffres, génération et activation locale du code d'amorçage.",
        body_style
    ))
    story.append(Spacer(1, 8))

    api_client = [
        [Paragraph("Méthode & Route", table_header_style), Paragraph("Description Métier", table_header_style), Paragraph("Paramètres / Body Requête", table_header_style), Paragraph("Réponse attendue", table_header_style)],
        
        # Profil & Sécurité
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/profile</code>", body_style),
            Paragraph("Récupère les informations complètes du client connecté.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ id, nom, prenom, email, telephone, dateInscription, statut }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PUT')}<br/><code>/user/profile</code>", body_style),
            Paragraph("Mise à jour des coordonnées personnelles du client.", body_style),
            Paragraph("<b>Body:</b> <code>{ nom, prenom, telephone, organisation }</code>", body_style),
            Paragraph("<b>200:</b> Objet utilisateur mis à jour", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PUT')}<br/><code>/user/password</code>", body_style),
            Paragraph("Modification sécurisée du mot de passe de connexion.", body_style),
            Paragraph("<b>Body:</b> <code>{ currentPassword, newPassword, confirmPassword }</code>", body_style),
            Paragraph("<b>200:</b> Mot de passe mis à jour<br/><b>400:</b> Ancien mot de passe incorrect", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/logout</code>", body_style),
            Paragraph("Révocation de la session en cours et invalidation du refresh token.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>204 No Content</b>", body_style)
        ],

        # Forfaits & Abonnements
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/subscription</code>", body_style),
            Paragraph("État de l'abonnement actif ou récent du client.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ id, formule, dateDebut, dateFin, statut: 'actif'|'expirant'|'expire'|'suspendu', camerasMax: 10 }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/subscription/select-plan</code>", body_style),
            Paragraph("Enregistre le choix de la formule choisie par l'utilisateur.", body_style),
            Paragraph("<b>Body:</b> <code>{ planId: 'essentiel'|'professionnel'|'entreprise', billingCycle: 'monthly'|'annual' }</code>", body_style),
            Paragraph("<b>201:</b> <code>{ orderId, plan, amountToPay, currency: 'XOF' }</code>", body_style)
        ],

        # Moyens de Paiement & Transactions
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/payments/methods</code>", body_style),
            Paragraph("Opérateurs disponibles (Orange Money, MTN, Moov, Wave, Carte).", body_style),
            Paragraph("<i>Query:</i> <code>?country=bf|ci|sn|ml</code>", body_style),
            Paragraph("<b>200:</b> Liste des méthodes avec indicatifs téléphoniques, logos et états", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/payments/initiate</code>", body_style),
            Paragraph("Lance la transaction de paiement (push USSD ou redirection web).", body_style),
            Paragraph("<b>Body:</b> <code>{ orderId, method: 'mobile-money'|'carte', network: 'orange'|'mtn'|'moov'|'wave', phoneNumber, countryCode }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ transactionId, status: 'PENDING', paymentUrl, ussdPromptSent: true }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/payments/:txId/status</code>", body_style),
            Paragraph("Interrogation du statut de la transaction (polling frontend).", body_style),
            Paragraph("<b>Path:</b> <code>txId</code> (identifiant de transaction)", body_style),
            Paragraph("<b>200:</b> <code>{ status: 'PAIEMENT_EN_COURS'|'PAIEMENT_VALIDE'|'PAIEMENT_ECHOUE', errorMessage }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/payments/webhook</code>", body_style),
            Paragraph("Endpoint serveur appelé par Wave / Orange / MTN / Moov.", body_style),
            Paragraph("<b>Headers:</b> <code>X-Signature-HMAC-SHA256</code><br/><b>Body:</b> Payload passerelle", body_style),
            Paragraph("<b>200:</b> Acquittement transaction + création automatique de la demande", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/invoices</code>", body_style),
            Paragraph("Historique des reçus de paiement et factures acquittées.", body_style),
            Paragraph("<i>Query:</i> <code>?page=1&limit=10</code>", body_style),
            Paragraph("<b>200:</b> <code>[ { id, reference, date, amount, pdfDownloadUrl } ]</code>", body_style)
        ],

        # Demandes de Code d'Amorçage
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/bootstrap-requests</code>", body_style),
            Paragraph("Création formelle d'une demande de code d'amorçage liée au paiement.", body_style),
            Paragraph("<b>Body:</b> <code>{ planId, transactionId, noteClient }</code>", body_style),
            Paragraph("<b>201:</b> <code>{ requestId, reference: 'PV-2026-XXXX', statut: 'EN_ATTENTE_VALIDATION', date }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/bootstrap-requests/latest</code>", body_style),
            Paragraph("Récupère l'état d'avancement de la demande en cours.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ id, reference, plan, amount, statut, motifRefus, canRequestOtp }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/bootstrap-requests/history</code>", body_style),
            Paragraph("Historique de toutes les demandes passées du client.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> Liste chronologique des demandes", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/bootstrap-requests/:id/retry</code>", body_style),
            Paragraph("Soumission d'une correction suite à un refus par l'administrateur.", body_style),
            Paragraph("<b>Path:</b> <code>id</code><br/><b>Body:</b> <code>{ corrections, justificatifUrl }</code>", body_style),
            Paragraph("<b>200:</b> Demande repassée en <code>EN_ATTENTE_VALIDATION</code>", body_style)
        ],

        # Sécurité OTP & Déblocage du Code
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/bootstrap-requests/:id/send-otp</code>", body_style),
            Paragraph("Envoi d'un code OTP de sécurité (SMS ou Email) une fois validé.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> de la demande validée", body_style),
            Paragraph("<b>200:</b> <code>{ sentTo: '+226 ** ** 01', expiresInSeconds: 300 }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/bootstrap-requests/:id/verify-otp</code>", body_style),
            Paragraph("Vérification du code OTP à 6 chiffres pour débloquer le code.", body_style),
            Paragraph("<b>Body:</b> <code>{ otpCode: '582139' }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ verified: true, accessGranted: true }</code><br/><b>422:</b> Code OTP invalide ou expiré", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/bootstrap-code</code>", body_style),
            Paragraph("Restitue le code d'amorçage actif avec ses modalités d'activation.", body_style),
            Paragraph("<i>Conditionné par validation OTP réussie</i>", body_style),
            Paragraph("<b>200:</b> <code>{ code: '58213947', dateGeneration, dateExpiration, formule, status: 'CODE_DISPONIBLE' }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/bootstrap-code/activate</code>", body_style),
            Paragraph("Activation effective de l'environnement Previa avec le code.", body_style),
            Paragraph("<b>Body:</b> <code>{ code: '58213947', machineFingerprint, localServerName }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ activated: true, activationToken, status: 'ACTIVE', validUntil: '2027-03-22' }</code>", body_style)
        ],

        # Notifications Client
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/user/notifications</code>", body_style),
            Paragraph("Récupère les alertes et messages du compte client.", body_style),
            Paragraph("<i>Query:</i> <code>?unreadOnly=false</code>", body_style),
            Paragraph("<b>200:</b> <code>{ items: [ { id, kind, title, text, date, read } ], unreadCount }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PATCH')}<br/><code>/user/notifications/:id/read</code>", body_style),
            Paragraph("Marque une notification spécifique comme consultée.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> de la notification", body_style),
            Paragraph("<b>200:</b> Notification mise à jour", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/user/notifications/mark-all-read</code>", body_style),
            Paragraph("Marque l'ensemble des notifications du client comme lues.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ unreadCount: 0 }</code>", body_style)
        ],
    ]

    t_cli = Table(api_client, colWidths=[110, 130, 145, 138], repeatRows=1)
    t_cli.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_SECONDARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 3.5),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t_cli)

    story.append(PageBreak())

    # ==========================================
    # SECTION 4 : APIS SUPERADMINISTRATEUR (PREVADM)
    # ==========================================
    story.append(Paragraph("4. APIs pour le SUPERADMINISTRATEUR (Back-office Prevadm)", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_PUT, spaceAfter=8))
    story.append(Paragraph(
        "Ces endpoints sont strictement réservés au personnel habilité sous <b><code>/api/v1/admin/</code></b>. "
        "Ils requièrent un jeton JWT avec signature de privilège <b><code>role: 'SUPERADMIN'</code></b>. "
        "Chaque opération modificatrice alimente obligatoirement le journal d'audit immuable.",
        body_style
    ))
    story.append(Spacer(1, 8))

    api_admin = [
        [Paragraph("Méthode & Route", table_header_style), Paragraph("Description Métier", table_header_style), Paragraph("Paramètres / Body Requête", table_header_style), Paragraph("Réponse attendue & Impact", table_header_style)],
        
        # Auth & Compte Admin
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/auth/login</code>", body_style),
            Paragraph("Connexion au portail d'administration Prevadm.", body_style),
            Paragraph("<b>Body:</b> <code>{ email, password, totpCode }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ adminUser, accessToken, role: 'SUPERADMIN' }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/auth/me</code>", body_style),
            Paragraph("Données de session du Superadmin authentifié.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ nom, prenom, email, role, lastLogin }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PUT')}<br/><code>/admin/profile</code>", body_style),
            Paragraph("Mise à jour des informations du profil superadmin.", body_style),
            Paragraph("<b>Body:</b> <code>{ nom, prenom, email, telephone }</code>", body_style),
            Paragraph("<b>200:</b> Profil admin mis à jour + log d'audit", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PUT')}<br/><code>/admin/password</code>", body_style),
            Paragraph("Changement sécurisé du mot de passe administrateur.", body_style),
            Paragraph("<b>Body:</b> <code>{ currentPassword, newPassword }</code>", body_style),
            Paragraph("<b>200:</b> Mot de passe modifié + log d'audit", body_style)
        ],

        # Dashboard & Analytics
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/dashboard/stats</code>", body_style),
            Paragraph("Statistiques et compteurs globaux du tableau de bord.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ totalClients: 8, clientsActifs: 5, abonnementsExpirants: 2, demandesEnAttente: 4, codesGeneres: 1 }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/dashboard/charts</code>", body_style),
            Paragraph("Données pour le diagramme en barres et l'anneau d'abonnements.", body_style),
            Paragraph("<i>Query:</i> <code>?range=month|year</code>", body_style),
            Paragraph("<b>200:</b> <code>{ monthlyData: [...], distribution: { essentiel: 3, pro: 3, entreprise: 1 } }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/dashboard/quick-actions</code>", body_style),
            Paragraph("Liste prioritaire des demandes nécessitant une intervention.", body_style),
            Paragraph("<i>Query:</i> <code>?limit=5</code>", body_style),
            Paragraph("<b>200:</b> Les 5 demandes en attente les plus anciennes", body_style)
        ],

        # Gestion des Clients
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/clients</code>", body_style),
            Paragraph("Liste paginée des clients avec filtrage et recherche.", body_style),
            Paragraph("<i>Query:</i> <code>?search=moussa&statut=actif|expire|suspendu&page=1&limit=10</code>", body_style),
            Paragraph("<b>200:</b> <code>{ clients: [ { id, nom, prenom, email, telephone, dateInscription, statut } ], total }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/clients/:id</code>", body_style),
            Paragraph("Fiche client détaillée avec abonnements, demandes et codes.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> du client", body_style),
            Paragraph("<b>200:</b> <code>{ client, abonnements: [...], demandes: [...], logsConnexions: [...] }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PUT')}<br/><code>/admin/clients/:id</code>", body_style),
            Paragraph("Modification des informations administratives d'un client.", body_style),
            Paragraph("<b>Body:</b> <code>{ nom, prenom, email, telephone, statut }</code>", body_style),
            Paragraph("<b>200:</b> Client modifié + création log d'audit catégorie <code>clients</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PATCH')}<br/><code>/admin/clients/:id/status</code>", body_style),
            Paragraph("Modification directe du statut (activation, suspension).", body_style),
            Paragraph("<b>Body:</b> <code>{ statut: 'actif'|'suspendu'|'expire', motif }</code>", body_style),
            Paragraph("<b>200:</b> Statut modifié + log d'audit généré", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/clients/:id/reset-password</code>", body_style),
            Paragraph("Émission d'un lien sécurisé de réinitialisation pour le client.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> du client", body_style),
            Paragraph("<b>200:</b> Email envoyé au client + log d'audit", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('DELETE')}<br/><code>/admin/clients/:id</code>", body_style),
            Paragraph("Suppression logique ou anonymisation définitive du compte client.", body_style),
            Paragraph("<b>Path:</b> <code>id</code><br/><b>Body:</b> <code>{ confirmMotif }</code>", body_style),
            Paragraph("<b>200/204:</b> Compte désactivé et archivé", body_style)
        ],

        # Gestion des Demandes de Code d'Amorçage
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/demandes</code>", body_style),
            Paragraph("Liste complète des demandes de code soumises.", body_style),
            Paragraph("<i>Query:</i> <code>?statut=en_attente|validee|refusee&formule=...</code>", body_style),
            Paragraph("<b>200:</b> <code>{ demandes: [ { id, clientId, date, formule, statut, motifRefus, code } ] }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/demandes/:id</code>", body_style),
            Paragraph("Vue détaillée d'une demande avec les preuves de paiement.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> de la demande", body_style),
            Paragraph("<b>200:</b> Détail demande + profil client associé", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/demandes/:id/valider</code>", body_style),
            Paragraph("Validation officielle de la demande d'amorçage par l'admin.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> de la demande", body_style),
            Paragraph("<b>200:</b> Statut <code>validee</code> + notif client + log d'audit catégorie <code>demandes</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/demandes/:id/refuser</code>", body_style),
            Paragraph("Refus argumenté de la demande avec motif obligatoire.", body_style),
            Paragraph("<b>Body:</b> <code>{ motifRefus: 'Paiement non confirmé...' }</code>", body_style),
            Paragraph("<b>200:</b> Statut <code>refusee</code> + envoi email/notif au client + log d'audit", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/demandes/:id/generer-code</code>", body_style),
            Paragraph("Génération du code d'amorçage à 8 chiffres (activation directe).", body_style),
            Paragraph("<b>Body:</b> <code>{ dureeValiditeMois: 6|12 }</code>", body_style),
            Paragraph("<b>201:</b> <code>{ valeur: '58213947', dateGeneration, dateExpiration }</code> + log d'audit catégorie <code>codes</code>", body_style)
        ],

        # Gestion des Abonnements
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/abonnements</code>", body_style),
            Paragraph("Liste globale des abonnements avec filtres d'état.", body_style),
            Paragraph("<i>Query:</i> <code>?statut=actif|expirant|expire|suspendu</code>", body_style),
            Paragraph("<b>200:</b> <code>[ { id, clientId, formule, dateDebut, dateFin, statut } ]</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/abonnements/:id</code>", body_style),
            Paragraph("Détail d'un abonnement et historique des renouvellements.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> de l'abonnement", body_style),
            Paragraph("<b>200:</b> Fiche complète de l'abonnement", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/abonnements/:id/prolonger</code>", body_style),
            Paragraph("Prolongation de validité d'un abonnement existant.", body_style),
            Paragraph("<b>Body:</b> <code>{ mois: 1|3|6|12, nouvelleDateFin }</code>", body_style),
            Paragraph("<b>200:</b> Nouvelle dateFin + statut 'actif' + log d'audit catégorie <code>abonnements</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PATCH')}<br/><code>/admin/abonnements/:id/suspendre</code>", body_style),
            Paragraph("Suspension immédiate des services pour défaut de paiement.", body_style),
            Paragraph("<b>Path:</b> <code>id</code>", body_style),
            Paragraph("<b>200:</b> Statut 'suspendu' + blocage des flux IA + log d'audit", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PATCH')}<br/><code>/admin/abonnements/:id/reactiver</code>", body_style),
            Paragraph("Rétablissement d'un abonnement suspendu suite à régularisation.", body_style),
            Paragraph("<b>Path:</b> <code>id</code>", body_style),
            Paragraph("<b>200:</b> Statut 'actif' + réouverture des droits + log d'audit", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PATCH')}<br/><code>/admin/abonnements/:id/terminer</code>", body_style),
            Paragraph("Résiliation contractuelle anticipée ou clôture d'un abonnement.", body_style),
            Paragraph("<b>Body:</b> <code>{ motifCloture }</code>", body_style),
            Paragraph("<b>200:</b> Statut 'expire' + log d'audit", body_style)
        ],

        # Notifications Administrateur
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/notifications</code>", body_style),
            Paragraph("Flux d'alertes internes (nouvelles demandes, expirations, système).", body_style),
            Paragraph("<i>Query:</i> <code>?kind=demande|abonnement|systeme</code>", body_style),
            Paragraph("<b>200:</b> <code>{ notifications: [ { id, kind, title, text, date, read } ], unreadCount }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('PATCH')}<br/><code>/admin/notifications/:id/read</code>", body_style),
            Paragraph("Marquer une alerte administrative comme lue.", body_style),
            Paragraph("<b>Path:</b> <code>id</code> de la notification", body_style),
            Paragraph("<b>200:</b> Statut <code>read: true</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/notifications/mark-all-read</code>", body_style),
            Paragraph("Acquittement groupé de toutes les alertes reçues.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ unreadCount: 0 }</code>", body_style)
        ],

        # Journal d'Audit & Historique Système
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/historique</code>", body_style),
            Paragraph("Registre d'audit horodaté de toutes les actions sur la plateforme.", body_style),
            Paragraph("<i>Query:</i> <code>?categorie=clients|demandes|codes|abonnements|compte&search=...</code>", body_style),
            Paragraph("<b>200:</b> <code>[ { id, action, cible, auteur, categorie, date } ]</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/historique/export</code>", body_style),
            Paragraph("Téléchargement du registre d'audit pour conformité légale.", body_style),
            Paragraph("<i>Query:</i> <code>?format=csv|xlsx&startDate=...&endDate=...</code>", body_style),
            Paragraph("<b>200:</b> Fichier tabulaire téléchargeable", body_style)
        ],

        # Gestion des Utilisateurs Administrateurs
        [
            Paragraph(f"{make_method_badge('GET')}<br/><code>/admin/users</code>", body_style),
            Paragraph("Liste des comptes administrateurs habilités.", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>[ { id, nom, prenom, email, role, dateCreation, dernierAcces } ]</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/users</code>", body_style),
            Paragraph("Création d'un compte administrateur secondaire.", body_style),
            Paragraph("<b>Body:</b> <code>{ nom, prenom, email, role: 'SUPERADMIN'|'OPERATEUR', password }</code>", body_style),
            Paragraph("<b>201:</b> Compte admin créé + invitation envoyée + log d'audit", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/2fa/setup</code>", body_style),
            Paragraph("Initialisation du double facteur d'authentification (TOTP).", body_style),
            Paragraph("<i>Header Authorization requis</i>", body_style),
            Paragraph("<b>200:</b> <code>{ qrCodeDataUrl, secretKey, backupCodes: [...] }</code>", body_style)
        ],
        [
            Paragraph(f"{make_method_badge('POST')}<br/><code>/admin/2fa/verify</code>", body_style),
            Paragraph("Validation et activation définitive du 2FA après configuration.", body_style),
            Paragraph("<b>Body:</b> <code>{ totpToken: '123456' }</code>", body_style),
            Paragraph("<b>200:</b> <code>{ twoFactorEnabled: true }</code>", body_style)
        ],

        # Maintenance & Réinitialisation
        [
            Paragraph(f"{make_method_badge('DELETE')}<br/><code>/admin/database/reset</code>", body_style),
            Paragraph("Supprime définitivement tous les comptes clients (et leurs abonnements, demandes, codes) pour repartir d'une base vide. Le compte superadmin appelant est conservé.", body_style),
            Paragraph("<i>Header Authorization requis</i><br/><i>Réservé SUPERADMIN, action irréversible</i>", body_style),
            Paragraph("<b>200:</b> <code>{ clientsSupprimes: 8 }</code> + log d'audit catégorie <code>compte</code>", body_style)
        ],
    ]

    t_adm = Table(api_admin, colWidths=[110, 130, 145, 138], repeatRows=1)
    t_adm.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_PRIMARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 3),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t_adm)

    story.append(PageBreak())

    # ==========================================
    # SECTION 5 : MACHINE À ÉTATS DU CODE D'AMORÇAGE
    # ==========================================
    story.append(Paragraph("5. Cycle de Vie & Machine à États du Code d'Amorçage", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_TEAL, spaceAfter=8))
    
    workflow_desc = (
        "Le code d'amorçage constitue la clé de voûte de la sécurité de Previa : il garantit qu'un environnement "
        "logiciel de vidéosurveillance local ne peut démarrer sans une souscription validée par l'administration. "
        "L'équipe backend doit implémenter la machine à états finis suivante :"
    )
    story.append(Paragraph(workflow_desc, body_style))
    story.append(Spacer(1, 8))

    states_table_data = [
        [Paragraph("État (FlowState)", table_header_style), Paragraph("Rôle Déclencheur", table_header_style), Paragraph("Action Système Backend & Transition", table_header_style), Paragraph("Notifications Émises", table_header_style)],
        [
            Paragraph("<b>AUCUNE_DEMANDE</b>", body_style),
            Paragraph("Client", body_style),
            Paragraph("État initial du compte. Consultation des offres via <code>GET /plans</code>.", body_style),
            Paragraph("-", body_style)
        ],
        [
            Paragraph("<b>OFFRE_SELECTIONNEE</b>", body_style),
            Paragraph("Client", body_style),
            Paragraph("Sélection d'une offre (Essentiel, Professionnel ou Entreprise). Création de commande.", body_style),
            Paragraph("-", body_style)
        ],
        [
            Paragraph("<b>PAIEMENT</b>", body_style),
            Paragraph("Client", body_style),
            Paragraph("Choix du moyen de paiement (Orange Money, MTN, Moov, Wave ou Carte).", body_style),
            Paragraph("-", body_style)
        ],
        [
            Paragraph("<b>PAIEMENT_EN_COURS</b>", body_style),
            Paragraph("Client / Passerelle", body_style),
            Paragraph("Envoi du push USSD sur le téléphone ou redirection carte bancaire. Polling actif.", body_style),
            Paragraph("-", body_style)
        ],
        [
            Paragraph("<b>PAIEMENT_ECHOUE</b>", body_style),
            Paragraph("Passerelle", body_style),
            Paragraph("Rejet de transaction (solde insuffisant, timeout USSD). Proposition de nouvel essai.", body_style),
            Paragraph("Alerte client", body_style)
        ],
        [
            Paragraph("<b>EN_ATTENTE_VALIDATION</b>", body_style),
            Paragraph("Passerelle / Client", body_style),
            Paragraph("Paiement validé avec succès. Demande transmise dans la file d'attente admin.", body_style),
            Paragraph("Notification Admin d'une nouvelle demande", body_style)
        ],
        [
            Paragraph("<b>REFUSEE</b>", body_style),
            Paragraph("Superadmin", body_style),
            Paragraph("L'administrateur rejette la demande avec un motif explicatif. Le client peut corriger.", body_style),
            Paragraph("Notification et Email au client avec le motif", body_style)
        ],
        [
            Paragraph("<b>VALIDEE</b>", body_style),
            Paragraph("Superadmin", body_style),
            Paragraph("L'administrateur approuve la demande. Émission d'un code OTP à 6 chiffres par SMS/Email.", body_style),
            Paragraph("Notification client + Envoi code OTP", body_style)
        ],
        [
            Paragraph("<b>CODE_DISPONIBLE</b>", body_style),
            Paragraph("Client (OTP valide)", body_style),
            Paragraph("Le client valide son OTP. Le code d'amorçage unique à 8 chiffres est révélé.", body_style),
            Paragraph("Notification de mise à disposition du code", body_style)
        ],
        [
            Paragraph("<b>ACTIVE</b>", body_style),
            Paragraph("Client / Logiciel", body_style),
            Paragraph("Le code est injecté dans le logiciel local Previa. L'abonnement passe au statut 'actif'.", body_style),
            Paragraph("Confirmation d'activation du service", body_style)
        ],
    ]
    t_states = Table(states_table_data, colWidths=[120, 95, 185, 123], repeatRows=1)
    t_states.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_PRIMARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 4),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t_states)
    story.append(Spacer(1, 14))

    # ==========================================
    # SECTION 6 : MODÈLES DE DONNÉES BACKEND
    # ==========================================
    story.append(Paragraph("6. Schémas des Données Principales (Base de Données)", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_SECONDARY, spaceAfter=8))
    
    data_models = [
        [Paragraph("Entité", table_header_style), Paragraph("Champs Essentiels", table_header_style), Paragraph("Types & Contraintes", table_header_style), Paragraph("Relations / Description", table_header_style)],
        [
            Paragraph("<b>User (Client)</b>", body_style),
            Paragraph("<code>id, nom, prenom, email, passwordHash, telephone, dateInscription, statut, role</code>", body_style),
            Paragraph("email: UNIQUE, statut: enum ('actif', 'expire', 'suspendu'), role: 'CLIENT'", body_style),
            Paragraph("Possède 1..N abonnements et 1..N demandes.", body_style)
        ],
        [
            Paragraph("<b>Abonnement</b>", body_style),
            Paragraph("<code>id, clientId, formule, dateDebut, dateFin, statut, camerasMax</code>", body_style),
            Paragraph("formule: enum ('Essentiel', 'Professionnel', 'Entreprise'), statut: enum ('actif', 'expirant', 'expire', 'suspendu')", body_style),
            Paragraph("Lié à 1 Client et 1 Code d'amorçage.", body_style)
        ],
        [
            Paragraph("<b>Demande</b>", body_style),
            Paragraph("<code>id, clientId, formule, date, statut, motifRefus, transactionId</code>", body_style),
            Paragraph("statut: enum ('en_attente', 'validee', 'refusee'), motifRefus: nullable text", body_style),
            Paragraph("Créée après paiement, validée par Superadmin.", body_style)
        ],
        [
            Paragraph("<b>CodeAmorcage</b>", body_style),
            Paragraph("<code>id, demandeId, valeur, dateGeneration, dateExpiration, machineFingerprint, active</code>", body_style),
            Paragraph("valeur: string 8 chiffres unique, active: boolean, machineFingerprint: nullable string", body_style),
            Paragraph("Généré par le backend lors de la validation finale.", body_style)
        ],
        [
            Paragraph("<b>Transaction</b>", body_style),
            Paragraph("<code>id, clientId, reference, montant, devise, methode, reseau, telephone, statut, date</code>", body_style),
            Paragraph("devise: 'XOF', methode: enum ('mobile-money', 'carte'), statut: enum ('PENDING', 'SUCCESS', 'FAILED')", body_style),
            Paragraph("Traces des paiements Orange, MTN, Moov, Wave, Carte.", body_style)
        ],
        [
            Paragraph("<b>HistoriqueEntry</b>", body_style),
            Paragraph("<code>id, action, cible, auteur, categorie, date, ipAddress, userAgent</code>", body_style),
            Paragraph("categorie: enum ('clients', 'demandes', 'codes', 'abonnements', 'compte'), immuable", body_style),
            Paragraph("Journal d'audit pour le Superadministrateur.", body_style)
        ],
        [
            Paragraph("<b>Notification</b>", body_style),
            Paragraph("<code>id, recipientUserId, recipientRole, kind, title, text, date, read</code>", body_style),
            Paragraph("recipientRole: enum ('CLIENT', 'SUPERADMIN'), kind: enum ('demande', 'abonnement', 'systeme', 'info', 'success', 'danger')", body_style),
            Paragraph("Alertes dans l'interface et par push.", body_style)
        ],
    ]
    t_models = Table(data_models, colWidths=[90, 165, 138, 130], repeatRows=1)
    t_models.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_PRIMARY),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, C_LIGHT_BG]),
        ('PADDING', (0,0), (-1,-1), 4),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t_models)

    story.append(PageBreak())

    # ==========================================
    # SECTION 7 : SÉCURITÉ & RECOMMANDATIONS BACKEND
    # ==========================================
    story.append(Paragraph("7. Recommandations de Sécurité & Intégrations Tiers", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_ACCENT, spaceAfter=8))
    
    recom_text = (
        "Pour assurer la résilience, la conformité et la sécurité de la solution Previa, "
        "l'équipe backend doit appliquer les règles d'ingénierie suivantes :"
    )
    story.append(Paragraph(recom_text, body_style))
    story.append(Spacer(1, 8))

    rules_data = [
        [
            Paragraph("<b>1. Signature Cryptographique des Webhooks Paiement :</b>", meta_key),
            Paragraph(
                "Ne jamais valider une transaction sur simple appel HTTP. Vérifier obligatoirement "
                "la signature <code>X-Signature-HMAC-SHA256</code> avec la clé secrète fournie par Wave, Orange Money ou MTN. "
                "Appliquer une protection contre les attaques par rejeu (vérification d'un nonce et d'un timestamp à +/- 5 minutes).",
                body_style
            )
        ],
        [
            Paragraph("<b>2. Génération Sécurisée des Codes d'Amorçage :</b>", meta_key),
            Paragraph(
                "Le code d'amorçage doit être généré à l'aide d'un générateur pseudo-aléatoire cryptographiquement sûr "
                "(ex: <code>crypto.randomInt</code> en Node.js ou <code>secrets.randbelow</code> en Python). "
                "Le code doit être stocké sous forme hachée ou chiffrée (AES-256-GCM) dans la base de données. "
                "Un code ne peut être associé qu'à une seule machine (via <code>machineFingerprint</code> recueilli à l'activation).",
                body_style
            )
        ],
        [
            Paragraph("<b>3. Gestion des Tokens JWT & Sessions :</b>", meta_key),
            Paragraph(
                "• Access Token : durée de vie courte de <b>15 minutes</b>, transmis en Bearer Header.<br/>"
                "• Refresh Token : durée de vie de <b>7 jours</b>, stocké exclusivement dans un cookie sécurisé <code>HttpOnly; Secure; SameSite=Strict</code>.<br/>"
                "• Les routes d'administration <code>/admin/*</code> doivent valider la claim <code>role === 'SUPERADMIN'</code> côté middleware.",
                body_style
            )
        ],
        [
            Paragraph("<b>4. Limitation de Débit (Rate Limiting) :</b>", meta_key),
            Paragraph(
                "Appliquer des règles strictes de rate limiting basées sur Redis :<br/>"
                "• <code>/auth/login</code> et <code>/admin/auth/login</code> : max 5 tentatives par minute par IP (prévention brute-force).<br/>"
                "• <code>/user/bootstrap-requests/:id/verify-otp</code> : max 3 essais erronés avant verrouillage de 15 minutes.<br/>"
                "• Endpoints publics : max 100 requêtes par minute par IP.",
                body_style
            )
        ],
        [
            Paragraph("<b>5. Journal d'Audit Immuable (Audit Log) :</b>", meta_key),
            Paragraph(
                "Chaque validation, refus, prolongation d'abonnement ou génération de code effectuée par un superadmin "
                "doit enregistrer de manière irrévocable l'auteur (nom + ID admin), l'adresse IP source, l'horodatage UTC "
                "et les valeurs avant/après modification dans la table <code>HistoriqueEntry</code>.",
                body_style
            )
        ],
        [
            Paragraph("<b>6. Politique CORS (Cross-Origin Resource Sharing) :</b>", meta_key),
            Paragraph(
                "Restreindre les origines autorisées aux seuls domaines du frontend Previa en production "
                "(ex: <code>https://previa.app</code> et <code>https://admin.previa.app</code>). Rejeter tout appel provenant d'origines non répertoriées.",
                body_style
            )
        ]
    ]

    t_rules = Table(rules_data, colWidths=[180, 343])
    t_rules.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), C_LIGHT_BG),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('TOPPADDING', (0,0), (-1,-1), 7),
        ('BOTTOMPADDING', (0,0), (-1,-1), 7),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(t_rules)
    story.append(Spacer(1, 20))

    # Bloc de signature / validation
    sign_data = [
        [
            Paragraph("<b>Rédigé & Spécifié par :</b><br/>Lead Frontend & Architecture Previa", body_style),
            Paragraph("<b>Revue & Approbation Backend :</b><br/>Lead Tech Backend & DevOps", body_style),
            Paragraph("<b>Statut de Livraison :</b><br/><font color='#16A34A'><b>Prêt pour Codage des Endpoints</b></font>", body_style),
        ]
    ]
    t_sign = Table(sign_data, colWidths=[174, 174, 175])
    t_sign.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 1, C_BORDER),
        ('INNERGRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('BACKGROUND', (0,0), (-1,-1), colors.white),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(t_sign)

    # Génération
    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"[SUCCESS] PDF généré avec succès : {filename}")

if __name__ == "__main__":
    out_pdf = "Previa_Specifications_APIs_Backend.pdf"
    if len(sys.argv) > 1:
        out_pdf = sys.argv[1]
    build_pdf(out_pdf)
