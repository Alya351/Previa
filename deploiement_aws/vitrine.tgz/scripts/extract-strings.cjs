// Extrait les chaînes d'interface candidates (texte JSX, attributs, littéraux) par dossier.
const ts = require("typescript");
const fs = require("fs");
const path = require("path");

const roots = process.argv.slice(2);
const ATTRS = new Set(["placeholder", "title", "aria-label", "alt", "label", "text", "subtitle", "description", "desc"]);
const out = new Map(); // string -> Set(files)

function add(s, file) {
  s = s.replace(/&apos;/g, "'").replace(/&amp;/g, "&").replace(/&nbsp;/g, " ").replace(/&quot;/g, '"').replace(/\s+/g, " ").trim();
  if (/^(rgba?\(|var\(|url\(|rotate|translate|scale\(|inset\(|use client|currentColor|ease|xMid|noopener|\(m|start |end |mailto:|tel:|is-active)/.test(s)) return;
  if (/@[a-z0-9.-]+\.[a-z]+$/i.test(s)) return;
  if (s.length < 2) return;
  if (!/[A-Za-zÀ-ÿ]{2}/.test(s)) return;
  if (/^(https?:|\/|#|@|[a-z0-9_-]+$)/.test(s) && !/[À-ÿ ]/.test(s)) return;
  if (!out.has(s)) out.set(s, new Set());
  out.get(s).add(path.basename(file));
}

function walkDir(d, list = []) {
  for (const f of fs.readdirSync(d)) {
    const p = path.join(d, f);
    if (fs.statSync(p).isDirectory()) walkDir(p, list);
    else if (/\.(tsx|ts)$/.test(f)) list.push(p);
  }
  return list;
}

for (const r of roots) {
  for (const file of fs.statSync(r).isDirectory() ? walkDir(r) : [r]) {
    const src = fs.readFileSync(file, "utf8");
    const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, file.endsWith("x") ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
    const visit = (n) => {
      if (ts.isImportDeclaration(n)) return;
      if (ts.isJsxText(n)) add(n.getText(), file);
      else if (ts.isJsxAttribute(n)) {
        const name = n.name.getText();
        if (name === "className" || name === "style" || name === "href" || name === "id" || name === "key") return;
      } else if (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n)) {
        const p = n.parent;
        if (ts.isJsxAttribute(p) && (p.name.getText() === "className" || p.name.getText() === "href" || p.name.getText()==="id" || p.name.getText()==="key" || p.name.getText()==="type")) return;
        if (ts.isElementAccessExpression(p)) return;
        add(n.text, file);
      } else if (ts.isTemplateExpression(n)) {
        let s = n.head.text;
        n.templateSpans.forEach((sp, i) => { s += `{${i}}` + sp.literal.text; });
        add(s, file);
      }
      ts.forEachChild(n, visit);
    };
    visit(sf);
  }
}
const arr = [...out.keys()].sort();
for (const s of arr) console.log(s);
