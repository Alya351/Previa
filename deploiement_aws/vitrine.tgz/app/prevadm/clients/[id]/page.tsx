import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import ClientDetailPage from "@/components/admin/ClientDetailPage";

export const metadata: Metadata = { title: "Détail du client — Previa Admin" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <AdminShell title="Fiche client" subtitle="Informations et code d'activation">
      <ClientDetailPage id={id} />
    </AdminShell>
  );
}
