import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import ClientsPage, { ClientsInfoCard } from "@/components/admin/ClientsPage";

export const metadata: Metadata = { title: "Clients — Previa Admin" };

export default function Page() {
  return (
    <AdminShell title="Clients" subtitle="Gérez les comptes et abonnements de vos clients" navInfo={<ClientsInfoCard />}>
      <ClientsPage />
    </AdminShell>
  );
}
