import { Suspense } from "react";
import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import ComptePage from "@/components/admin/ComptePage";

export const metadata: Metadata = { title: "Mon compte — Previa Admin" };

export default function Page() {
  return (
    <AdminShell title="Mon compte" subtitle="Vos informations personnelles et votre activité récente">
      <Suspense>
        <ComptePage mode="compte" initialPanel="profil" />
      </Suspense>
    </AdminShell>
  );
}
