import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import NotificationsPage, { NotificationsInfoCard } from "@/components/admin/NotificationsPage";

export const metadata: Metadata = { title: "Notifications — Previa Admin" };

export default function Page() {
  return (
    <AdminShell
      title="Notifications"
      subtitle="Toute l'activité qui nécessite votre attention"
      navInfo={<NotificationsInfoCard />}
    >
      <NotificationsPage />
    </AdminShell>
  );
}
