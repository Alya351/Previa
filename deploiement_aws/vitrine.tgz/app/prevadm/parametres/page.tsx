import { Suspense } from "react";
import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import ComptePage from "@/components/admin/ComptePage";

export const metadata: Metadata = { title: "Paramètres — Previa Admin" };

export default function Page() {
  return (
    <AdminShell title="Paramètres" subtitle="Sécurité, préférences et gestion de l'équipe">
      <Suspense>
        <ComptePage mode="parametres" />
      </Suspense>
    </AdminShell>
  );
}
