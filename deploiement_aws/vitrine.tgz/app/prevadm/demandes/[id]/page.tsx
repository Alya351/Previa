import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import DemandeDetailPage from "@/components/admin/DemandeDetailPage";

export const metadata: Metadata = { title: "Détail de la demande — Previa Admin" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <AdminShell
      title="Traitement de la demande"
      subtitle="Validez la demande et générez le code d'activation"
    >
      <DemandeDetailPage id={id} />
    </AdminShell>
  );
}
