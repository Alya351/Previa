import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import DemandesPage from "@/components/admin/DemandesPage";

export const metadata: Metadata = { title: "Demandes de codes — Previa Admin" };

export default function Page() {
  return (
    <AdminShell
      title="Demandes de codes"
      subtitle="Liste des demandes de codes d'activation effectuées"
    >
      <DemandesPage />
    </AdminShell>
  );
}
