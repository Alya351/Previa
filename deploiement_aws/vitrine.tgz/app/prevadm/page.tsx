import type { Metadata } from "next";
import AdminRootGate from "@/components/admin/AdminRootGate";

export const metadata: Metadata = {
  title: "Superadministration — Previa",
  description: "Centre de pilotage Superadmin Previa.",
};

export default function Page() {
  return <AdminRootGate />;
}
