import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import AbonnementsPage, { AbonnementsInfoCard } from "@/components/admin/AbonnementsPage";

export const metadata: Metadata = { title: "Abonnements — Previa Admin" };

export default function Page() {
  return (
    <AdminShell title="Abonnements" subtitle="Suivez l'état des abonnements de vos clients" navInfo={<AbonnementsInfoCard />}>
      <AbonnementsPage />
    </AdminShell>
  );
}
