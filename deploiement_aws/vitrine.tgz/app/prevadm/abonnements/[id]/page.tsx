import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import AbonnementDetailPage from "@/components/admin/AbonnementDetailPage";

export const metadata: Metadata = { title: "Détail de l'abonnement — Previa Admin" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <AdminShell title="Abonnement" subtitle="Gérez la durée et le statut de l'abonnement">
      <AbonnementDetailPage id={id} />
    </AdminShell>
  );
}
