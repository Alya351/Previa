import type { ReactNode } from "react";
import { AdminDataProvider } from "@/components/admin/AdminDataContext";
import { ToastProvider } from "@/components/admin/ToastContext";

/** Fournit les données admin (clients, abonnements, demandes...) et les toasts
 *  UNE SEULE FOIS pour tout /prevadm/*, afin que l'état (prolongations,
 *  suspensions, suppressions...) survive à la navigation entre les pages. */
export default function PrevAdmLayout({ children }: { children: ReactNode }) {
  return (
    <AdminDataProvider>
      <ToastProvider>{children}</ToastProvider>
    </AdminDataProvider>
  );
}
