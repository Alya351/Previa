import type { Metadata } from "next";
import AdminShell from "@/components/admin/AdminShell";
import HistoriquePage, { HistoriqueInfoCard } from "@/components/admin/HistoriquePage";

export const metadata: Metadata = { title: "Historique — Previa Admin" };

export default function Page() {
  return (
    <AdminShell
      title="Historique"
      subtitle="Journal complet des actions effectuées"
      navInfo={<HistoriqueInfoCard />}
    >
      <HistoriquePage />
    </AdminShell>
  );
}
