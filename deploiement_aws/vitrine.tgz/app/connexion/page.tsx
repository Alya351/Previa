import type { Metadata } from "next";
import AuthPage from "@/components/auth/AuthPage";

export const metadata: Metadata = {
  title: "Connexion — Previa",
  description: "Connectez-vous ou créez votre compte Previa.",
};

export default function Page() {
  return <AuthPage />;
}
