import type { Metadata } from "next";
import MentionsLegalesPage from "@/components/legal/MentionsLegalesPage";

export const metadata: Metadata = {
  title: "Mentions légales — Previa",
  description: "Mentions légales et conditions d'utilisation de la plateforme Previa.",
};

export default function Page() {
  return <MentionsLegalesPage />;
}
