"use client";

import { motion, useReducedMotion } from "motion/react";

/**
 * App Router remonte ce template à chaque navigation :
 * on obtient donc une animation d'entrée fluide entre les pages.
 * Respecte prefers-reduced-motion.
 */
export default function Template({ children }: { children: React.ReactNode }) {
  const reduce = useReducedMotion();

  if (reduce) return <>{children}</>;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
