import type { Metadata } from "next";
import ConfidentialitePage from "@/components/legal/ConfidentialitePage";

export const metadata: Metadata = {
  title: "Politique de confidentialité — Previa",
  description: "Données collectées, usages, sécurité et droits des utilisateurs de Previa.",
};

export default function Page() {
  return <ConfidentialitePage />;
}
