import type { Metadata } from "next";
import AProposPage from "@/components/a-propos/AProposPage";

export const metadata: Metadata = {
  title: "À propos — Previa",
  description:
    "L'histoire, la vision, l'équipe et les engagements de Previa, et un formulaire pour contacter l'équipe.",
};

export default function Page() {
  return <AProposPage />;
}
