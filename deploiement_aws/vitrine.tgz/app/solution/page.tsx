import type { Metadata } from "next";
import SolutionPage from "@/components/solution/SolutionPage";

export const metadata: Metadata = {
  title: "Solution — Previa",
  description:
    "Previa analyse les comportements vidéo pour détecter les situations inhabituelles et vous permettre d'agir au bon moment.",
};

export default function Page() {
  return <SolutionPage />;
}
