import type { Metadata } from "next";
import AuthPage from "@/components/auth/AuthPage";

export const metadata: Metadata = {
  title: "Inscription — Previa",
  description: "Créez votre compte Previa.",
};

export default function Page() {
  return <AuthPage initialMode="register" />;
}
