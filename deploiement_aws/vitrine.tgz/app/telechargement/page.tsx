import type { Metadata } from "next";
import TelechargementPage from "@/components/telechargement/TelechargementPage";

export const metadata: Metadata = {
  title: "Téléchargement — Previa",
  description:
    "Téléchargez Previa sur Windows, Android ou iOS et commencez à surveiller vos environnements intelligemment.",
};

export default function Page() {
  return <TelechargementPage />;
}
