import type { Metadata } from "next";
import CodeAmorcageGate from "@/components/code-amorcage/CodeAmorcageGate";

export const metadata: Metadata = {
  title: "Code d'activation — Previa",
  description:
    "Comprendre le code d'activation Previa et savoir comment l'obtenir : compte, demande, validation, activation.",
};

export default function Page() {
  return <CodeAmorcageGate />;
}
