import type { Metadata } from "next";
import { Open_Sans } from "next/font/google";
import "./globals.css";
import ThemeProvider from "@/components/theme/ThemeProvider";
import SplashGate from "@/components/splash/SplashGate";
import { LangProvider } from "@/lib/i18n/LangProvider";

const openSans = Open_Sans({
  variable: "--font-open-sans",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Previa — Surveillance intelligente. Anticipation renforcée.",
  description:
    "Previa, solution moderne de surveillance intelligente par analyse comportementale vidéo.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="fr"
      className={`${openSans.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <body className="min-h-full">
        <ThemeProvider>
          <LangProvider>
            <SplashGate>{children}</SplashGate>
          </LangProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
