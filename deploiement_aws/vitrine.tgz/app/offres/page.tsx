import type { Metadata } from "next";
import OffresPage from "@/components/offres/OffresPage";

export const metadata: Metadata = {
  title: "Nos offres — Previa",
  description:
    "Découvrez les formules Previa : prix, nombre de caméras et niveau de support, pour particuliers et entreprises.",
};

export default function Page() {
  return <OffresPage />;
}
